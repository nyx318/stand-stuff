
require("natives-1627063482")
GenerateFeatures = function(pid)
	menu.divider(menu.player_root(pid),"Ren's Weapon Troll Lua")
    player_griefing_tab = menu.list(menu.player_root(pid),"Weapon Trolling",{},"Hit em with shiz!")
	menu.action(player_griefing_tab,"Shoot themselves with Atomizer",{"atomizer"},"",function(on_click)
		local playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
		local weaponhash = util.joaat("weapon_raypistol")
		for times=1,100 do
			playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
			MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(playerpos.x, playerpos.y, playerpos.z+3, playerpos.x, playerpos.y, playerpos.z-2, 0, true, weaponhash, 0, true, false, -20)
			util.yield(5)
		end
	end)
    menu.action(player_griefing_tab,"Shoot themselves once with Atomizer",{"aatomizer"},"",function(on_click)
		local playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
		local weaponhash = util.joaat("weapon_raypistol")
		MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(playerpos.x, playerpos.y, playerpos.z+3, playerpos.x, playerpos.y, playerpos.z-2, 0, true, weaponhash, 0, true, false, -20)
	end)
	menu.action(player_griefing_tab,"Shoot themselves with Molotov",{"molotov"},"",function(on_click)
		local playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
		local weaponhash = util.joaat("weapon_molotov")
		for times=1,100 do
			playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
			MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(playerpos.x, playerpos.y, playerpos.z, playerpos.x, playerpos.y, playerpos.z-2, 0, true, weaponhash, 0, true, false, -20)
			util.yield(10)
		end
	end)
    menu.action(player_griefing_tab,"Shoot themselves once with Molotov",{"amolotov"},"",function(on_click)
		local playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
		local weaponhash = util.joaat("weapon_molotov")
		MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(playerpos.x, playerpos.y, playerpos.z, playerpos.x, playerpos.y, playerpos.z-2, 0, true, weaponhash, 0, true, false, -20)
	end)
	menu.action(player_griefing_tab,"Shoot themselves with Fireworks",{"firework"},"",function(on_click)
		local playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
		local weaponhash = util.joaat("weapon_firework")
		for times=1,100 do
			playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
			MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(playerpos.x, playerpos.y, playerpos.z, playerpos.x, playerpos.y, playerpos.z-2, 0, true, weaponhash, 0, true, false, -20)
			util.yield(30)
		end
	end)
    menu.action(player_griefing_tab,"Shoot themselves once with Fireworks",{"afirework"},"",function(on_click)
		local playerped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local playerpos = ENTITY.GET_ENTITY_COORDS(playerped)
		local weaponhash = util.joaat("weapon_firework")
		MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(playerpos.x, playerpos.y, playerpos.z, playerpos.x, playerpos.y, playerpos.z-2, 0, true, weaponhash, 0, true, false, -20)
	end)
end
players.on_join(GenerateFeatures)
for pid = 0,30 do
	if players.exists(pid) then
		GenerateFeatures(pid)
	end
end
while true do
    util.yield()
end