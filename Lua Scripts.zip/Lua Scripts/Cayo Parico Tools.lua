require("natives-1627063482")

local function teleport_player(x, y ,z)
    if PLAYER.IS_PLAYER_TELEPORT_ACTIVE() then
        PLAYER.STOP_PLAYER_TELEPORT()
    end
    PLAYER.START_PLAYER_TELEPORT(PLAYER.PLAYER_ID, x, y, z, 0, false, true, false)
    util.toast("Teleport successful")
end

zymbid = 3
cymb = 0
cymbhz = false
jjzj = 65535
grwapen = false
grfdy = false
grkzzy = false
wapen = 5
kczdy = false
kcwz = 0
jsid = "MP0_"


local plkd_list = menu.list(menu.my_root(), "Skip Preps & Customize Heist")

menu.toggle(plkd_list,"Character Selection", {} , "Disable this to write desired data to Slot 1, Enable this to write desired data to Slot 2.",  function (swich)
    
    if swich == true then
        jsid = "MP1_"
    else
        jsid = "MP0_"
    end

end)


local plkdys_list = menu.list(plkd_list, "Presets")

menu.action(plkdys_list, "Solo, $2.45Mil", {"solocayopericosetup"}, "100% of the cut | Hard mode | No Elite Challenge | $2.45Mil without wall safe cash | Pink Diamond + 2 Paintings", function()
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_GEN"), 131071, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ENTR"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ABIL"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_APPROACH"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 131055, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TARGET"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), 677045, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_MISSIONS"), 65535, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEAPONS"), 5, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEP_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_ARM_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_HEL_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_GRAPPEL"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_UNIFORM"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BOLTCUT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TROJAN"), 4, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PLAYTHROUGH_STATUS"), 10, true);
    util.toast("Done, please re-enter Kosatka to start the heist.")
end)
menu.action(plkdys_list, "Duo, $2.45Mil each", {"duocayopericosetup"}, "50%-50% | Hard mode | No Elite Challenge | $2.45Mil without wall safe cash | Pink Diamond + 4 Paintings", function()
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_GEN"), 131071, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ENTR"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ABIL"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_APPROACH"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 131055, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TARGET"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), 1034545, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_MISSIONS"), 65535, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEAPONS"), 5, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEP_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_ARM_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_HEL_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_GRAPPEL"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_UNIFORM"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BOLTCUT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TROJAN"), 4, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PLAYTHROUGH_STATUS"), 10, true);
    util.toast("Done, please re-enter Kosatka to start the heist.")
end)
menu.action(plkdys_list, "3 Players, $2.45Mil each", {"3playercayopericosetup"}, "35%-35%-30% | Hard mode | No Elite Challenge | $2.45Mil without wall safe cash | Pink Diamond + 6 Paintings", function()
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_GEN"), 131071, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ENTR"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ABIL"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_APPROACH"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 131055, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TARGET"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), 1087424, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_MISSIONS"), 65535, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEAPONS"), 5, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEP_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_ARM_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_HEL_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_GRAPPEL"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_UNIFORM"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BOLTCUT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TROJAN"), 4, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PLAYTHROUGH_STATUS"), 10, true);
    util.toast("Done, please re-enter Kosatka to start the heist.")
end)
menu.action(plkdys_list, "4 Players, $2.45Mil each", {"4playercayopericosetup"}, "25% each | Hard mode | No Elite Challenge | $2.45Mil without wall safe cash | Pink Diamond + 8 Paintings", function()
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_GEN"), 131071, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ENTR"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ABIL"), 63, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_APPROACH"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 131055, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TARGET"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), 1213295, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_MISSIONS"), 65535, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEAPONS"), 5, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEP_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_ARM_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_HEL_DISRP"), 3, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_GRAPPEL"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_UNIFORM"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BOLTCUT"), -1, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TROJAN"), 4, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PLAYTHROUGH_STATUS"), 10, true);
    util.toast("Done, please re-enter Kosatka to start the heist.")
end)


local plkdzdy_list = menu.list(plkd_list, "Customize your heist")

menu.toggle(plkdzdy_list,"Scope all PoI", {} , "",  function (swich) 
    
    if swich == true then
        jsxdq = true
    else
        jsxdq = false
    end
end)

menu.toggle(plkdzdy_list,"Scope all Infiltration Points", {} , "",  function (swich) 
    
    if swich == true then
        jsrqd = true
    else
        jsrqd = false
    end
end)

menu.toggle(plkdzdy_list,"Purchase all support crews", {} , "",  function (swich) 
    
    if swich == true then
        jstdzc = true
    else
        jstdzc = false
    end
end)

menu.toggle(plkdzdy_list,"Scope all Escape Points", {} , "",  function (swich) 
    
    if swich == true then
        jstld = true
    else
        jstld = false
    end
end)

menu.toggle(plkdzdy_list,"Enable Hardmode", {} , "Enable this to set it to hard mode, otherwise it's normal.",  function (swich) 
    
    if swich == true then
        hardmod = true
    else
        hardmod = false
    end
end)

local plkdzdyzymb_list = menu.list(plkdzdy_list, "Primary Target", {} ,"Will set to Pink Diamond by default.")
menu.action(plkdzdyzymb_list, "Sinsimito Tequila", {}, "Normal Mode: $900,000, Hard mode: $990,000.", function()    

    zymbid = 0
    util.toast("Primary Targets will be changed to: Sinsimito Tequila")

end)

menu.action(plkdzdyzymb_list, "Ruby Necklace", {}, "Normal Mode: $1,000,000, Hard mode: $1,100,000.", function()    

    zymbid = 1
    util.toast("Primary Targets will be changed to: Ruby Necklace")

end)

menu.action(plkdzdyzymb_list, "Bearer Bonds", {}, "Normal Mode: $1,100,000, Hard mode: $1,210,000.", function()    

    zymbid = 2
    util.toast("Primary Targets will be changed to: Bearer Bonds")

end)

menu.action(plkdzdyzymb_list, "Pink Diamond", {}, "Normal Mode: $1,300,000, Hard mode: $1,430,000.", function()    

    zymbid = 3
    util.toast("Primary Targets will be changed to: Pink Diamond")

end)

menu.action(plkdzdyzymb_list, "Panther Statue", {}, "Normal Mode: $1,900,000, Hard mode: $2,090,000.", function()    

    zymbid = 5
    util.toast("Primary Targets will be changed to: Panther Statue")

end)

local plkdzdycymb_list = menu.list(plkdzdy_list, "Secondary Targets", {} ,"Randomize Secondary Targets by default.")

menu.action(plkdzdycymb_list, "Tips", {}, "Choose one of the following: cash, weed, cocaine and gold. Enable paintings if you want to, it's independent from other loots", function()    

    util.toast("Choose one of the following: cash, weed, cocaine and gold. Enable paintings if you want to, it's independent from other loots.")

end)

menu.action(plkdzdycymb_list, "Randomize Secondary Targets", {}, "", function()    

    cymb = 0
    cymbhz = 0
    util.toast("Randomized Secondary Targets")

end)

menu.action(plkdzdycymb_list, "Cash", {}, "", function()    

    cymb = 1
    util.toast("All Secondary Targets will be changed to: Cash")

end)

menu.action(plkdzdycymb_list, "Weed", {}, "", function()    

    cymb = 2
    util.toast("All Secondary Targets will be changed to: Weed")

end)

menu.action(plkdzdycymb_list, "Cocaine", {}, "", function()    

    cymb = 3
    util.toast("All Secondary Targets will be changed to: Cocaine")

end)

menu.action(plkdzdycymb_list, "Gold", {}, "", function()    

    cymb = 4
    util.toast("All Secondary Targets will be changed to: Gold")

end)

menu.toggle(plkdzdycymb_list,"Paintings", {} , "Paintings don't conflict with all other Secondary Targets, enable it at your will.",  function (swich)
    
    if swich == true then
        cymbhz = true
    else
        cymbhz = false
    end
end)

local plkdzdyjjzj_list = menu.list(plkdzdy_list, "Approach Vehicles", {} ,"All available by default.")

menu.action(plkdzdyjjzj_list, "Submarine: Kosatka", {}, "", function()    

    jjzj = 65283
    util.toast("Approach Vehicle will be set to: Kosatka")

end)

menu.action(plkdzdyjjzj_list, "Plane: Alkonost", {}, "", function()    

    jjzj = 65413
    util.toast("Approach Vehicle will be set to: Alkonost")

end)

menu.action(plkdzdyjjzj_list, "Plane: Velum", {}, "", function()    

    jjzj = 65289
    util.toast("Approach Vehicle will be set to: Velum")

end)

menu.action(plkdzdyjjzj_list, "Helicopter: Stealth Annihilator", {}, "", function()    

    jjzj = 65425
    util.toast("Approach Vehicle will be set to: Stealth Annihilator")

end)

menu.action(plkdzdyjjzj_list, "Boat: Patrol Boat", {}, "", function()    

    jjzj = 65313
    util.toast("Approach Vehicle will be set to: Patrol Boat")

end)

menu.action(plkdzdyjjzj_list, "Boat: Longfin", {}, "", function()    

    jjzj = 65345
    util.toast("Approach Vehicle will be set to: Longfin")

end)

menu.action(plkdzdyjjzj_list, "Make all approach vehicles available", {}, "", function()    

    jjzj = 65535
    util.toast("All approach vehicles are now available")

end)

local plkdzdywapen_list = menu.list(plkdzdy_list, "Weapon Loadout", {} ,"Will set to Marksman loadout by default.")

menu.action(plkdzdywapen_list, "Aggressor", {}, "Assault Shotgun, Machine Pistol, Machete, Grenades.", function()    

    wapen = 1
    util.toast("Weapon Loadout will be set to: Aggressor")

end)

menu.action(plkdzdywapen_list, "Conspirator", {}, "Military Rifle, Pistol .50, Knuckle Dusters, Sticky Bombs.", function()    

    wapen = 2
    util.toast("Weapon Loadout will be set to: Conspirator")

end)

menu.action(plkdzdywapen_list, "Crack Shot", {}, "Sniper Rifle, AP Pistol, Knife, Molotov Cocktails.", function()    

    wapen = 3
    util.toast("Weapon Loadout will be set to: Crack Shot")

end)

menu.action(plkdzdywapen_list, "Saboteur", {}, "SMG Mk II, SNS Pistol Mk II, Knife, Pipe Bomb.", function()    

    wapen = 4
    util.toast("Weapon Loadout will be set to: Saboteur")

end)

menu.action(plkdzdywapen_list, "Marksman", {}, "Assault Rifle Mk II, Pistol Mk II, Machete, Pipe Bomb.", function()    

    wapen = 5
    util.toast("Weapon Loadout will be set to: Marksman")

end)

local plkdzdygr_list = menu.list(plkdzdy_list, "Disruptions", {} ,"There won't be any disruption by default")

menu.toggle(plkdzdygr_list,"Weapons", {} , "",  function (swich)
    
    if swich == true then
        grwapen = true
    else
        grwapen = false
    end
end)

menu.toggle(plkdzdygr_list,"Armor", {} , "",  function (swich)
    
    if swich == true then
        grfdy = true
    else
        grfdy = false
    end
end)

menu.toggle(plkdzdygr_list,"Air Support", {} , "",  function (swich)
    
    if swich == true then
        grkzzy = true
    else
        grkzzy = false
    end
end)

local plkdzdyanother_list = menu.list(plkdzdy_list, "Equipments", {} ,"There won't be any additional equipment be default")

menu.toggle(plkdzdyanother_list,"Grappling equipment", {} , "",  function (swich)
    
    if swich == true then
        zhuagou = true
    else
        zhuagou = false
    end
end)

menu.toggle(plkdzdyanother_list,"Guard Clothings", {} , "",  function (swich)
    
    if swich == true then
        zhifu = true
    else
        zhifu = false
    end
end)

menu.toggle(plkdzdyanother_list,"Bolt Cutters", {} , "",  function (swich)
    
    if swich == true then
        lsqiegeqi = true
    else
        lsqiegeqi = false
    end
end)
--xxxyyyfffxxx
local plkdzdykcwz_list = menu.list(plkdzdy_list, "Supply Truck", {} ,"Randomize supply truck location by default")

menu.action(plkdzdykcwz_list, "Random Location", {}, "", function()    

    kczdy = false
    util.toast("Supply Truck will park at: Random Location")

end)

menu.action(plkdzdykcwz_list, "Airstrip", {}, "", function()    

    kczdy = true
    kcwz = 1
    util.toast("Supply Truck will park at: Airstrip")

end)

menu.action(plkdzdykcwz_list, "North Dock", {}, "", function()    

    kczdy = true
    kcwz = 2
    util.toast("Supply Truck will park at: North Dock")

end)

menu.action(plkdzdykcwz_list, "Main Dock East", {}, "", function()    

    kczdy = true
    kcwz = 3
    util.toast("Supply Truck will park at: Main Dock East")

end)

menu.action(plkdzdykcwz_list, "Main Dock West", {}, "", function()    

    kczdy = true
    kcwz = 4
    util.toast("Supply Truck will park at: Main Dock West")

end)

menu.action(plkdzdykcwz_list, "Main Gate", {}, "", function()    

    kczdy = true
    kcwz = 5
    util.toast("Supply Truck will park at: Main Gate")

end)

menu.action(plkdzdy_list, "Apply!", {}, "Apply chosen options above.", function()
   
    if jsxdq == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_GEN"), 131071, true);
    end

    if jsrqd == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ENTR"), 63, true);
    end

    if jstdzc == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ABIL"), 63, true);
    end

    if jstld == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_APPROACH"), -1, true);
    end

    if hardmod == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 131055, true);
    else
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 126823, true);
    end

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TARGET"), zymbid, true);

    if cymb == 1 then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_V"), 90000, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C_SCOPED"), 0, true);
    end

    if cymb == 2 then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_V"), 145000, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C_SCOPED"), 0, true);;
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C_SCOPED"), 0, true);
    end

    if cymb == 3 then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_V"), 90000, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_V"), 220000, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C_SCOPED"), 0, true);
    end

    if cymb == 4 then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_V"), 90000, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C_SCOPED"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_V"), 320000, true);
    end
--xyfx
    if cymbhz == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), -1, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), 180000, true);
    else
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), 0, true);
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), 0, true);
    end
    
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_MISSIONS"), jjzj, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEAPONS"), wapen, true);



    if grwapen == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_WEP_DISRP"), 3, true);
    end

    if grfdy == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_ARM_DISRP"), 3, true);
    end

    if grkzzy == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_HEL_DISRP"), 3, true);
    end



    if zhuagou == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_GRAPPEL"), -1, true);
    end

    if zhifu == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_UNIFORM"), -1, true);
    end

    if lsqiegeqi == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BOLTCUT"), -1, true);
    end

    if kczdy == true then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_TROJAN"), kcwz, true);
    end

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PLAYTHROUGH_STATUS"), 10, true);
    
    util.toast("Done, please re-enter Kosatka to see the effect. Find a new session if nothing has changed.")
end)

local gfh_list = menu.list(menu.my_root(), "Change Secondary Targets' Value")

menu.action(gfh_list, "README", {}, "Please skip the preps before using this function. Sec. targets' values in 4 presets are already modified, they don't need additional modification. Please ensure that you have the matching Sec. target, otherwise no one knows what happens next. The default values are from R*'s default.", function()
    util.toast("Please skip the preps before using this function. Sec. targets' values in 4 presets are already modified, they don't need additional modification. Please ensure that you have the matching Sec. target, otherwise no one knows what happens next. The default values are from R*'s default.")
end)

menu.action(gfh_list, "Tips", {}, "The payout limit for each Cayo Perico Heist is $2.5 Million, additionally, you can't earn more than $4 Million each hour. These numbers are subject to change anytime by R* and accuracy is not guaranteed.", function()
    util.toast("The payout limit for each Cayo Perico Heist is $2.5 Million, additionally, you can't earn more than $4 Million each hour. These numbers are subject to change anytime by R* and accuracy is not guaranteed.")
end)

menu.slider(gfh_list, "A pile of cash is worth...", {"changecashmoney"}, "", 0, 99999999, 90000, 1000, function (moneynumber)

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_V"), moneynumber, true);

    util.toast("A pile of cash now worths " .. moneynumber .. ", please re-enter Kosatka")

end)

menu.slider(gfh_list, "A pile of weed is worth...", {"changeweedmoney"}, "", 0, 99999999, 145000, 1000, function (moneynumber)

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_V"), moneynumber, true);

    util.toast("A pile of weed now worths " .. moneynumber .. ", please re-enter Kosatka")

end)

menu.slider(gfh_list, "A pile of cocaine is worth...", {"changecokemoney"}, "", 0, 99999999, 220000, 1000, function (moneynumber)

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_V"), moneynumber, true);

    util.toast("A pile of cocaine now worths " .. moneynumber .. ", please re-enter Kosatka")

end)

menu.slider(gfh_list, "A pile of gold is worth...", {"changegoldmoney"}, "", 0, 99999999, 320000, 1000, function (moneynumber)

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_V"), moneynumber, true);

    util.toast("A pile of gold now worths " .. moneynumber .. ", please re-enter Kosatka")

end)

menu.slider(gfh_list, "Each painting is worth...", {"changepaintmoney"}, "", 0, 99999999, 180000, 1000, function (moneynumber)

    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), moneynumber, true);

    util.toast("Each painting now worths " .. moneynumber .. ", please re-enter Kosatka")

end)

local rcd_list = menu.list(menu.my_root(), "[HIGH RISK] Remove cooldown")

menu.slider(rcd_list, "[HIGH RISK] Remove cooldown", {"resetcayopericocooldown"}, "Remove the cooldown to start the heist in normal mode. This option has higher chance to resulting in a ban. Type 1234 as the value to proceed.", 0, 9999, 0, 1, function (type)

    util.toast("Type 1234 in command window to proceed with this action")

    if type == 1234 then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_COOLDOWN"), 0, true);
        util.toast("Done, please re-enter Kosatka to see the effect. Find a new session if nothing has changed.")
    else
        util.toast("Action canceled")
    end

end)

menu.slider(rcd_list, "[HIGH RISK] Remove cooldown (Hardmode)", {"resetcayopericohardmodcooldown"}, "Remove the cooldown to start the heist in normal mode. This option has higher chance to resulting in a ban. Type 1234 as the value to proceed.", 0, 9999, 0, 1, function (type)

    util.toast("Type 1234 in command window to proceed with this action")

    if type == 1234 then
        STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_COOLDOWN_HARD"), 0, true);
        util.toast("Done, please re-enter Kosatka to see the effect. Find a new session if nothing has changed.")
    else
        util.toast("Action canceled")
    end

end)

--[[menu.action(plkd_list, "重置次要目标", {}, "重置你的次要目标 (可能会出错 慎用)", function()
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_I_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_C_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_CASH_V"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_I_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_C_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_WEED_V"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_I_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_C_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_COKE_V"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_I_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_C_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_GOLD_V"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_SCOPED"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4LOOT_PAINT_V"), 0, true);
    util.toast("Done, please re-enter Kosatka to start the heist.")
end)]]--

menu.action(plkd_list, "General reset", {}, "Start the heist from Gathering Intels for Madrazo Files, used to clear active Cayo Perico Heist.", function()
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_MISSIONS"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PROGRESS"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4_PLAYTHROUGH_STATUS"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_APPROACH"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_ENTR"), 0, true);
    STATS.STAT_SET_INT(MISC.GET_HASH_KEY(jsid .. "H4CNF_BS_GEN"), 0, true);
    util.toast("Done, please re-enter Kosatka to start the heist.")
end)

local tp_list = menu.list(menu.my_root(), "Teleports")

local into_list = menu.list(tp_list, "Compound Entry Points")
menu.action(into_list, "Main Gate", {}, "Requires guard outfits and truck, or demolition charges", function()
	teleport_player(4974.8145, -5704.486, 19.886944)
end)
menu.action(into_list, "South Gate", {}, "Requires keypad codes", function()
	teleport_player(4953.5913, -5783.9536, 20.873245)
end)
menu.action(into_list, "South Wall", {}, "Requires grappling hooks", function()
	teleport_player(4988.5303, -5813.0806, 20.59947)
end)
menu.action(into_list, "North Gate", {}, "Requires keypad codes", function()
	teleport_player(5086.2466, -5729.823, 15.772765)
end)
menu.action(into_list, "North Wall", {}, "Requires grappling hooks", function()
	teleport_player(5034.7593, -5679.558, 19.707558)
end)
menu.action(into_list, "Drainage Tunnel", {}, "Requires cutting torch", function()
	teleport_player(5049.113, -5820.8745, -11.01531)
end)
local goout_list = menu.list(tp_list, "Exiting the Compound")
menu.action(goout_list, "Main Gate", {}, "", function()
	teleport_player(4991.7773, -5720.2324, 19.880207)
end)
menu.action(goout_list, "South Gate", {}, "", function()
	teleport_player(4967.6333, -5782.961, 20.877867)
end)
menu.action(goout_list, "South Wall", {}, "", function()
	teleport_player(4995.6035, -5801.1294, 20.87761)
end)
menu.action(goout_list, "North Gate", {}, "", function()
	teleport_player(5086.339, -5739.6675, 15.67762)
end)
menu.action(goout_list, "North Wall", {}, "", function()
	teleport_player(5026.248, -5688.2866, 19.877226)
end)
menu.action(goout_list, "The Sea", {}, "Teleport after you've exit the compound", function()
	teleport_player(4037.1016, -5391.5527, -0.0561885)
end)
local compound_list = menu.list(tp_list, "Targets in the Compound")
menu.action(compound_list, "El' Rubio's Office", {}, "", function()
	teleport_player(5010.407227, -5752.104980, 28.840000)
end)
menu.action(compound_list, "Primary Target", {}, "", function()
	teleport_player(5007.501953, -5755.193848, 15.484000)
end)
menu.action(compound_list, "Basement Storage", {}, "", function()
	teleport_player(4999.764160, -5749.863770, 14.840000)
end)
menu.action(compound_list, "North Storage", {}, "To load interior, open the door gently and walk back", function()
	teleport_player(5079.8276, -5757.6455, 15.829647)
end)
menu.action(compound_list, "West Storage", {}, "To load interior, open the door gently and walk back", function()
	teleport_player(5028.2734, -5734.967, 17.865585)
end)
menu.action(compound_list, "South Storage", {}, "To load interior, open the door gently and walk back", function()
	teleport_player(5009.6895, -5785.3022, 17.831696)
end)
local island_list = menu.list(tp_list, "Secondary Targets on the island")
local main_dock_list = menu.list(island_list, "Main Dock")
menu.action(main_dock_list, "Main Dock #1", {}, "", function()
	teleport_player(5193.909668, -5135.642578, 2.045917)
end)
menu.action(main_dock_list, "Main Dock #2", {}, "", function()
	teleport_player(4963.184570, -5108.933105, 1.670808)
end)
menu.action(main_dock_list, "Main Dock #3", {}, "", function()
	teleport_player(4998.709473, -5165.559570, 1.464137)
end)
menu.action(main_dock_list, "Main Dock #4", {}, "", function()
	teleport_player(4924.693359, -5243.244629, 1.223599)
end)
local north_dock_list = menu.list(island_list, "North Dock")
menu.action(north_dock_list, "North Dock #1", {}, "", function()
	teleport_player(5132.558594, -4612.922852, 1.162808)
end)
menu.action(north_dock_list, "North Dock #2", {}, "", function()
	teleport_player(5065.255371, -4591.706543, 1.555012)
end)
menu.action(north_dock_list, "North Dock #3", {}, "", function()
	teleport_player(5090.916016, -4682.670898, 1.107098)
end)
local airstrip_list = menu.list(island_list, "Airstrip")
menu.action(airstrip_list, "Airstrip #1", {}, "", function()
	teleport_player(4503.587402, -4555.740723, 2.854459)
end)
menu.action(airstrip_list, "Airstrip #2 (Hanger)", {}, "", function()
	teleport_player(4437.821777, -4447.841309, 3.028436)
end)
menu.action(airstrip_list, "Airstrip #3 (Hanger)", {}, "", function()
	teleport_player(4447.091797, -4442.184082, 5.936794)
end)
local crop_fields_list = menu.list(island_list, "Crop Fields")
menu.action(crop_fields_list, "Crop Fields #1", {}, "", function()
	teleport_player(5330.527, -5269.7515, 33.18603)
end)

local thanks1_list = menu.list(menu.my_root(), "About")

menu.divider(thanks1_list, "Current Version")

menu.action(thanks1_list, "v2.0", {}, "", function()
    util.toast("currenVersion v2.0")
    util.toast("releaseDate 2021/8/23")
end)

menu.divider(thanks1_list, "Credits")

menu.action(thanks1_list, "Author johnXD#1050", {}, "", function()
    util.toast("Discord johnXD#1050")
    util.toast("QQ 2475833719")
end)

menu.action(thanks1_list, "Translator NingChow#5940", {}, "", function()
    util.toast("Discord NingChow#5940")
end)

menu.divider(thanks1_list, "-")

menu.action(thanks1_list, "Sharing of this script is welcomed, ", {}, "", function()

end)

menu.action(thanks1_list, "just don't add self-promotion stuff.", {}, "", function()

end)

while true do
	util.yield()
end