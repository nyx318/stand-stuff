-- Developed By IceDoomfist.
-- This Lua Script Based 2Take1 Heist Control V2.
-- Special Thanks To jhowkNx!


--- Lua Script Settings 

    local Script = "Heist Control"

    local LuaScriptName = Script
    local LuaScriptVersion = "V 0.3.1"
    local BasedLuaScriptVersion = "V 2.11.0"

    local function Notify(message)
        util.toast(tostring("[ Heist Control ]\n\n"..message..""), TOAST_DEFAULT) 
    end

    if filesystem.exists(filesystem.scripts_dir().."\\lib\\natives-1614644776.lua") then
        require("natives-1614644776")
    else
        Notify('Can`t find "natives-1614644776" file.\nPlease check the file.')
        util.stop_script()
    end

    --- Main Functions 

        local function STAT_SET_INT(Hash, Value)
            STATS.STAT_SET_INT(util.joaat("MP0_" .. Hash), Value, true)
            STATS.STAT_SET_INT(util.joaat("MP1_" .. Hash), Value, true)
        end
        
        local function STAT_SET_FLOAT(Hash, Value)
            STATS.STAT_SET_FLOAT(util.joaat("MP0_" .. Hash), Value, true)
            STATS.STAT_SET_FLOAT(util.joaat("MP1_" .. Hash), Value, true)
        end
        
        local function STAT_SET_BOOL(Hash, Value)
            STATS.STAT_SET_BOOL(util.joaat("MP0_" .. Hash), Value, true)
            STATS.STAT_SET_BOOL(util.joaat("MP1_" .. Hash), Value, true)
        end

    ---

---


--- Tabs Setting

    local Heist_Control = menu.divider(menu.my_root(), LuaScriptName.." "..LuaScriptVersion)

    local PERICO_HEIST = menu.list(menu.my_root(), "Cayo Perico Heist", {}, "", function(); end)
    local TELEPORT = menu.list(PERICO_HEIST, "Custom Teleport", {}, "", function(); end)
    local STANDARD_SET = menu.list(PERICO_HEIST, "Standard Preset", {}, "", function(); end)
    local CAYO_VEHICLES = menu.list(PERICO_HEIST, "Heist Vehicles", {}, "", function(); end)
    local CAYO_PRIMARY = menu.list(PERICO_HEIST, "Primary Target", {}, "", function(); end)
    local CAYO_SECONDARY = menu.list(PERICO_HEIST, "Secondary Target", {}, "", function(); end)
    local CAYO_WEAPONS = menu.list(PERICO_HEIST, "Weapon Loadouts", {}, "", function(); end)
    local CAYO_EQUIPM = menu.list(PERICO_HEIST, "Equipments Spawn Location", {}, "", function(); end)
    local CAYO_TRUCK = menu.list(PERICO_HEIST, "Supply Truck Location", {}, "", function(); end)
    local CAYO_DFFCTY = menu.list(PERICO_HEIST, "Heist Difficulty", {}, "", function(); end)
    local MORE_OPTIONS = menu.list(PERICO_HEIST, "More Options", {}, "", function(); end)
    local CASINO_HEIST = menu.list(menu.my_root(), "Diamond Casino Heist", {}, "", function(); end)
    local CASINO_PRESETS = menu.list(CASINO_HEIST, "Insta-Play [Presets]", {}, "", function(); end)
    local CAH_ADVCED = menu.list(CASINO_HEIST, "Advanced Features", {}, "", function(); end)
    local TELEPORT_CAH = menu.list(CASINO_HEIST, "Custom Teleport", {}, "", function(); end)
    local CASINO_BOARD1 = menu.list(CASINO_HEIST, "Heist Planning [Board 1]", {}, "", function(); end)
    local BOARD1_APPROACH = menu.list(CASINO_BOARD1, "Change Approach and Difficulty", {}, "", function(); end)
    local CASINO_TARGET = menu.list(CASINO_BOARD1, "Change Target", {}, "", function(); end)
    local CASINO_BOARD2 = menu.list(CASINO_HEIST, "Heist Planning [Board 2]", {}, "", function(); end)
    local CASINO_BOARD3 = menu.list(CASINO_HEIST, "Heist Planning [Board 3]", {}, "", function(); end)
    local CASINO_LBOARDS = menu.list(CASINO_HEIST, "Board Loader : Unloader", {}, "", function(); end)
    local CASINO_MORE = menu.list(CASINO_HEIST, "More Options", {}, "", function(); end)
    local DOOMS_HEIST = menu.list(menu.my_root(), "Doomsday Heist", {}, "", function(); end)
    local DOOMS_PRESETS = menu.list(DOOMS_HEIST, "Insta-Play (Presets)", {}, "", function(); end)
    local TELEPORT_DOOMS = menu.list(DOOMS_HEIST, "Custom Teleport", {}, "", function(); end)
    local CLASSIC_HEISTS = menu.list(menu.my_root(), "Classic Heists", {}, "", function(); end)
    local LS_ROBBERY = menu.list(menu.my_root(), "LS Tuners Robbery", {}, "", function(); end)
    local MASTER_UNLOCKR = menu.list(menu.my_root(), "Master Unlocker", {}, "", function(); end)
    local TOOLS = menu.list(menu.my_root(), "Tools",  {}, "", function(); end)
    local Infos = menu.list(menu.my_root(), "About HC", {}, "", function(); end)

---


--- Cayo Teleport

    menu.action(TELEPORT, "Kosatka : Heist Board [Call Kosatka first]", {}, "", function()
        Notify("If you teleport without calling it, you will be bugged.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 1561.224, 386.659, -49.685)
    end)

    menu.action(TELEPORT, "Kosatka : Main Deck [Call Kosatka first]", {}, "", function()
        Notify("If you teleport without calling it, you will be bugged.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 1563.218, 406.030, -49.667)
    end)

    menu.action(TELEPORT, "Drainage Tunnel : Entrance", {}, "", function()
        if PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false) == 0 then
            ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 5044.726, -5816.164, -11.213)
        else
            ENTITY.SET_ENTITY_COORDS(PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false), 5044.726, -5816.164, -11.213)
        end
        Notify("Teleported to Drainage Tunnel : Entrance.")
    end)

    menu.action(TELEPORT, "Drainage Tunnel : 2nd Checkpoint", {}, "", function()
        Notify("Teleported to Drainage Tunnel : 2nd Checkpoint.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 5054.630, -5771.519, -4.807)
    end)

    menu.action(TELEPORT, "Main Target", {}, "", function()
        Notify("Teleported to Main Target.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 5006.896, -5755.963, 15.487)
    end)

    menu.action(TELEPORT, "Secondary Target room", {}, "", function()
        Notify("Teleported to Secondary Target room.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 5003.467, -5749.352, 14.840)
    end)

    menu.action(TELEPORT, "Vault (El Rubio room)", {}, "", function()
        Notify("Teleported to Vault.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 5010.753, -5757.639, 28.845)
    end)

    menu.action(TELEPORT, "Reduct Exit", {}, "", function()
        Notify("Teleported to Exit.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 4992.854, -5718.537, 19.880)
    end)

    menu.action(TELEPORT, "Ocean safe place", {}, "", function()
        if PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false) == 0 then
            ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 4771.792, -6166.055, -40.266)
        else
            ENTITY.SET_ENTITY_COORDS(PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false), 4771.792, -6166.055, -40.266)
        end
        Notify("Teleported to Ocean safe place.")
    end)

---

--- Casino Teleport

    menu.action(TELEPORT_CAH, "Planning Boards", {}, "", function()
        Notify("Teleported sucessfully.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 2711.773, -369.458, -54.781)
    end)

    menu.action(TELEPORT_CAH, "Garagem Exit", {}, "", function()
        Notify("Teleported sucessfully.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 2677.237, -361.494, -55.187)
    end)

---

--- Dooms Teleport

    menu.action(TELEPORT_DOOMS, "Photo screen (Heist board) (ACT II)", {}, "", function()
        Notify("Teleported sucessfully.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 515.528, 4835.353, -62.587)
    end)

    menu.action(TELEPORT_DOOMS, "Prisoner cell (ACT II)", {}, "", function()
        Notify("Teleported sucessfully.")
        ENTITY.SET_ENTITY_COORDS(PLAYER.PLAYER_PED_ID(), 512.888, 4833.033, -68.989)
    end)

---


--- Standard Presets

    menu.action(STANDARD_SET, "Semi-Original Preset (Not calculated)", {}, "- Remember to choose your preset outside the Submarine or in the Main Deck\n\n- Remember to deactivate the preset at the end.", function()
        STAT_SET_INT("H4CNF_BS_GEN", 262143)
        STAT_SET_INT("H4CNF_BS_ENTR", 63)
        STAT_SET_INT("H4CNF_BS_ABIL", 63)
        STAT_SET_INT("H4CNF_WEP_DISRP", 3)
        STAT_SET_INT("H4CNF_ARM_DISRP", 3)
        STAT_SET_INT("H4CNF_HEL_DISRP", 3)
        STAT_SET_INT("H4CNF_BOLTCUT", 4424)
        STAT_SET_INT("H4CNF_UNIFORM", 5256)
        STAT_SET_INT("H4CNF_GRAPPEL", 5156)
        STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_CASH_I", 1089792)
        STAT_SET_INT("H4LOOT_CASH_C", 0)
        STAT_SET_INT("H4LOOT_WEED_I", 9114214)
        STAT_SET_INT("H4LOOT_WEED_C", 37)
        STAT_SET_INT("H4LOOT_COKE_I", 6573209)
        STAT_SET_INT("H4LOOT_COKE_C", 26)
        STAT_SET_INT("H4LOOT_GOLD_I", 0)
        STAT_SET_INT("H4LOOT_GOLD_C", 192)
        STAT_SET_INT("H4LOOT_PAINT", 127)
        STAT_SET_INT("H4_PROGRESS", 124271)
        STAT_SET_INT("H4LOOT_CASH_V", 22500)
        STAT_SET_INT("H4LOOT_COKE_V", 55023)
        STAT_SET_INT("H4LOOT_GOLD_V", 83046)
        STAT_SET_INT("H4LOOT_PAINT_V", 47375)
        STAT_SET_INT("H4LOOT_WEED_V", 36967)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 1089792)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 9114214)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 37)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 6573209)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 26)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 192)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
        STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 5)
        -- INT
        STAT_SET_INT("H4CNF_TARGET", math.random(1, 5))
        STAT_SET_INT("H4CNF_WEAPONS", math.random(1, 5))
        -- INT Random
        Notify("The preset has been set, remember to be on the limit!\n\nHere you can use\n- Advanced Options (no exceptions)\n- Modify primary and secondary targets\n\nRemember that you will only receive the money if you do not exceed the limit of $2,500,000 per player")
    end)

---

--- Cayo Vehicles

    menu.action(CAYO_VEHICLES, "Submarine KOSATKA", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 65283)
        Notify("KOSATKA avaliable.")
    end)

    menu.action(CAYO_VEHICLES, "Plane ALKONOST", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 65413)
        Notify("ALKONOST avaliable.")
    end)

    menu.action(CAYO_VEHICLES, "Plane VELUM", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 65289)
        Notify("VELUM avaliable.")
    end)

    menu.action(CAYO_VEHICLES, "Helicopter STEALTH ANNIHILATOR", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 65425)
        Notify("STEALTH ANNIHILATOR avaliable.")
    end)

    menu.action(CAYO_VEHICLES, "Boat PATROL BOAT", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 65313)
        Notify("PATROL BOAT avaliable.")
    end)

    menu.action(CAYO_VEHICLES, "Boat LONGFIN", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 65345)
        Notify("LONGFIN avaliable.")
    end)

    menu.action(CAYO_VEHICLES, "Unlock All Vehicles", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
        Notify("All Vehicles are avaliable!")
    end)

---

--- Cayo Primary

    menu.action(CAYO_PRIMARY, "Change to Sapphire Panther", {}, "", function()
        STAT_SET_INT("H4CNF_TARGET", 5)
        Notify("Primary Target Modified to Sapphire Panther\n\n- $1.900,000 (Normal)\n- $2.090,000 (Hard)")
    end)

    menu.action(CAYO_PRIMARY, "Change to Madrazo Files", {}, "", function()
        STAT_SET_INT("H4CNF_TARGET", 4)
        Notify("Primary Target Modified to Madrazo Files\n\n- $1.100,000 (Normal)\n- $1.210,000 (Hard)")
    end)

    menu.action(CAYO_PRIMARY, "Change to Pink Diamond", {}, "", function()
        STAT_SET_INT("H4CNF_TARGET", 3)
        Notify("Primary Target Modified to Pink Diamond\n\n- $1.300,000 (Normal)\n- $1.430,000 (Hard)")
    end)

    menu.action(CAYO_PRIMARY, "Change to Bearer Bonds", {}, "", function()
        STAT_SET_INT("H4CNF_TARGET", 2)
        Notify("Primary Target Modified to Bearer Bonds\n\n- $1.100,000 (Normal)\n- $1.210,000 (Hard)")
    end)

    menu.action(CAYO_PRIMARY, "Change to Ruby", {}, "", function()
        STAT_SET_INT("H4CNF_TARGET", 1)
        Notify("Primary Target Modified to Ruby\n\n- $1.000,000 (Normal)\n- $1.100,000 (Hard)")
    end)

    menu.action(CAYO_PRIMARY, "Change to Tequila", {}, "", function()
        STAT_SET_INT("H4CNF_TARGET", 0)
        Notify("Primary Target Modified to Tequila\n\n- $900,000 (Normal)\n- $990,000 (Hard)")
    end)

---

--- Cayo Secondary

    menu.action(CAYO_SECONDARY, "Change to Mixed Loot", {}, "", function()
        STAT_SET_INT("H4LOOT_CASH_I", 1319624)
        STAT_SET_INT("H4LOOT_CASH_C", 18)
        STAT_SET_INT("H4LOOT_CASH_V", 89400)
        STAT_SET_INT("H4LOOT_WEED_I", 2639108)
        STAT_SET_INT("H4LOOT_WEED_C", 36)
        STAT_SET_INT("H4LOOT_WEED_V", 149000)
        STAT_SET_INT("H4LOOT_COKE_I", 4229122)
        STAT_SET_INT("H4LOOT_COKE_C", 72)
        STAT_SET_INT("H4LOOT_COKE_V", 221200)
        STAT_SET_INT("H4LOOT_GOLD_I", 8589313)
        STAT_SET_INT("H4LOOT_GOLD_C", 129)
        STAT_SET_INT("H4LOOT_GOLD_V", 322600)
        STAT_SET_INT("H4LOOT_PAINT", 127)
        STAT_SET_INT("H4LOOT_PAINT_V", 186800)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 1319624)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 18)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 2639108)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 36)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 4229122)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 72)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 8589313)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 129)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        Notify("Secondary Target are now Mixed\n\nWhen using this method, the percentage and final payment is random!")
    end)

    menu.action(CAYO_SECONDARY, "Change to full Cash", {}, "", function()
        STAT_SET_INT("H4LOOT_CASH_I", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_CASH_C", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_CASH_V", 90000)
        STAT_SET_INT("H4LOOT_WEED_I", 0)
        STAT_SET_INT("H4LOOT_WEED_C", 0)
        STAT_SET_INT("H4LOOT_WEED_V", 0)
        STAT_SET_INT("H4LOOT_COKE_I", 0)
        STAT_SET_INT("H4LOOT_COKE_C", 0)
        STAT_SET_INT("H4LOOT_COKE_V", 0)
        STAT_SET_INT("H4LOOT_GOLD_I", 0)
        STAT_SET_INT("H4LOOT_GOLD_C", 0)
        STAT_SET_INT("H4LOOT_GOLD_V", 0)
        STAT_SET_INT("H4LOOT_PAINT", 127)
        STAT_SET_INT("H4LOOT_PAINT_V", 190000)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        Notify("Secondary Target are full Cash (only)\n\nWhen using this method, the percentage and final payment is random!")
    end)

    menu.action(CAYO_SECONDARY, "Change to full Weed", {}, "", function()
        STAT_SET_INT("H4LOOT_CASH_I", 0)
        STAT_SET_INT("H4LOOT_CASH_C", 0)
        STAT_SET_INT("H4LOOT_CASH_V", 0)
        STAT_SET_INT("H4LOOT_WEED_I", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_WEED_C", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_WEED_V", 140000)
        STAT_SET_INT("H4LOOT_COKE_I", 0)
        STAT_SET_INT("H4LOOT_COKE_C", 0)
        STAT_SET_INT("H4LOOT_COKE_V", 0)
        STAT_SET_INT("H4LOOT_GOLD_I", 0)
        STAT_SET_INT("H4LOOT_GOLD_C", 0)
        STAT_SET_INT("H4LOOT_GOLD_V", 0)
        STAT_SET_INT("H4LOOT_PAINT", 127)
        STAT_SET_INT("H4LOOT_PAINT_V", 190000)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        Notify("Secondary Target are full Weed (only)\n\nWhen using this method, the percentage and final payment is random!")
    end)

    menu.action(CAYO_SECONDARY, "Change to full Coke", {}, "", function()
        STAT_SET_INT("H4LOOT_CASH_I", 0)
        STAT_SET_INT("H4LOOT_CASH_C", 0)
        STAT_SET_INT("H4LOOT_CASH_V", 0)
        STAT_SET_INT("H4LOOT_WEED_I", 0)
        STAT_SET_INT("H4LOOT_WEED_C", 0)
        STAT_SET_INT("H4LOOT_WEED_V", 0)
        STAT_SET_INT("H4LOOT_COKE_I", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_COKE_C", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_COKE_V", 210000)
        STAT_SET_INT("H4LOOT_GOLD_I", 0)
        STAT_SET_INT("H4LOOT_GOLD_C", 0)
        STAT_SET_INT("H4LOOT_GOLD_V", 0)
        STAT_SET_INT("H4LOOT_PAINT", 127)
        STAT_SET_INT("H4LOOT_PAINT_V", 190000)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
        Notify("Secondary Target are full Coke (only)\n\nWhen using this method, the percentage and final payment is random!")
    end)

    menu.action(CAYO_SECONDARY, "Change to full Gold", {}, "", function()
        STAT_SET_INT("H4LOOT_CASH_I", 0)
        STAT_SET_INT("H4LOOT_CASH_C", 0)
        STAT_SET_INT("H4LOOT_CASH_V", 0)
        STAT_SET_INT("H4LOOT_WEED_I", 0)
        STAT_SET_INT("H4LOOT_WEED_C", 0)
        STAT_SET_INT("H4LOOT_WEED_V", 0)
        STAT_SET_INT("H4LOOT_COKE_I", 0)
        STAT_SET_INT("H4LOOT_COKE_C", 0)
        STAT_SET_INT("H4LOOT_COKE_V", 0)
        STAT_SET_INT("H4LOOT_GOLD_I", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_GOLD_C", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_GOLD_V", 320000)
        STAT_SET_INT("H4LOOT_PAINT", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_PAINT_V", 190000)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0xFFFFFFF)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0xFFFFFFF)
        Notify("Secondary Target are full Gold (only)\n\nWhen using this method, the percentage and final payment is random!")
    end)

    menu.action(CAYO_SECONDARY, "Remove All", {}, "", function()
        STAT_SET_INT("H4LOOT_CASH_I", 0)
        STAT_SET_INT("H4LOOT_CASH_C", 0)
        STAT_SET_INT("H4LOOT_CASH_V", 0)
        STAT_SET_INT("H4LOOT_WEED_I", 0)
        STAT_SET_INT("H4LOOT_WEED_C", 0)
        STAT_SET_INT("H4LOOT_WEED_V", 0)
        STAT_SET_INT("H4LOOT_COKE_I", 0)
        STAT_SET_INT("H4LOOT_COKE_C", 0)
        STAT_SET_INT("H4LOOT_COKE_V", 0)
        STAT_SET_INT("H4LOOT_GOLD_I", 0)
        STAT_SET_INT("H4LOOT_GOLD_C", 0)
        STAT_SET_INT("H4LOOT_GOLD_V", 0)
        STAT_SET_INT("H4LOOT_PAINT", 0)
        STAT_SET_INT("H4LOOT_PAINT_V", 0)
        STAT_SET_INT("H4LOOT_CASH_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_I_SCOPED", 0)
        STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
        STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0)
        Notify("All Secondary targets has been removed!")
    end)

    local CAYO_COMPOUND = menu.list(CAYO_SECONDARY, "Compound Loot", {}, "", function(); end)

        menu.action(CAYO_COMPOUND, "Change to Mixed Loot", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 2)
            STAT_SET_INT("H4LOOT_CASH_V", 474431)
            STAT_SET_INT("H4LOOT_WEED_C", 17)
            STAT_SET_INT("H4LOOT_WEED_V", 759090)
            STAT_SET_INT("H4LOOT_COKE_C", 132)
            STAT_SET_INT("H4LOOT_COKE_V", 948863)
            STAT_SET_INT("H4LOOT_GOLD_C", 104)
            STAT_SET_INT("H4LOOT_GOLD_V", 1265151)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 948863)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 2)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 17)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 132)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 104)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
            Notify("Compound Loot has been modified!")
        end)

        menu.action(CAYO_COMPOUND, "Change to full Cash", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_CASH_V", 90000)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_V", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
            Notify("Compound Loot modified to Cash!")
        end)

        menu.action(CAYO_COMPOUND, "Change to full Weed", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_WEED_V", 140000)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
            Notify("Compound Loot modified to Weed!")
        end)

        menu.action(CAYO_COMPOUND, "Change to full Coke", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_COKE_V", 210000)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
            Notify("Compound Loot modified to Coke!")
        end)

        menu.action(CAYO_COMPOUND, "Change to full Gold", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_GOLD_V", 320000)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0xFFFFFFF)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
            Notify("Compound Loot modified to Gold!")
        end)

        menu.action(CAYO_COMPOUND, "Change to full Paint", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_CASH_V", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_WEED_V", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_COKE_V", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_V", 0)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT", 127)
            STAT_SET_INT("H4LOOT_PAINT_V", 190000)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 127)
            Notify("Compound Loot modified to Paint!")
        end)

        menu.action(CAYO_COMPOUND, "Remove Paint (only)", {}, "", function()
            STAT_SET_INT("H4LOOT_PAINT", 0)
            STAT_SET_INT("H4LOOT_PAINT_V", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0)
            Notify("Paints has been removed!")
        end)

        menu.action(CAYO_COMPOUND, "Remove all", {}, "", function()
            STAT_SET_INT("H4LOOT_CASH_C", 0)
            STAT_SET_INT("H4LOOT_WEED_C", 0)
            STAT_SET_INT("H4LOOT_COKE_C", 0)
            STAT_SET_INT("H4LOOT_GOLD_C", 0)
            STAT_SET_INT("H4LOOT_CASH_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_WEED_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_COKE_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_GOLD_C_SCOPED", 0)
            STAT_SET_INT("H4LOOT_PAINT", 0)
            STAT_SET_INT("H4LOOT_PAINT_SCOPED", 0)
            Notify("All Compound loots has been removed!")
        end)

    ---

---

--- Cayo Weapon

    menu.action(CAYO_WEAPONS, "Aggressor Loadout", {}, "", function()
        STAT_SET_INT("H4CNF_WEAPONS", 1)
        Notify("Aggressor Loadout\n\nAssault SG + Machine Pistol\nMachete + Grenade")
    end)

    menu.action(CAYO_WEAPONS, "Conspirator Loadout", {}, "", function()
        STAT_SET_INT("H4CNF_WEAPONS", 2)
        Notify("Conspirator Loadout\n\nMilitary Rifle + AP\nKnuckles + Stickies")
    end)

    menu.action(CAYO_WEAPONS, "Crackshot Loadout", {}, "", function()
        STAT_SET_INT("H4CNF_WEAPONS", 3)
        Notify("Crackshot Loadout\n\nSniper + AP\nKnife + Molotov")
    end)

    menu.action(CAYO_WEAPONS, "Saboteur Loadout", {}, "", function()
        STAT_SET_INT("H4CNF_WEAPONS", 4)
        Notify("Saboteur Loadout\n\nSMG Mk2 + SNS Pistol\nKnife + Pipe Bomb")
    end)

    menu.action(CAYO_WEAPONS, "Marksman Loadout", {}, "", function()
        STAT_SET_INT("H4CNF_WEAPONS", 5)
        Notify("Marksman Loadout\n\n- AK-47 + Pistol .50\n- Machete + Pipe Bomb")
    end)

---

--- Cayo Equipment

    menu.action(CAYO_EQUIPM, "Set to Equipments spawn next to Airport", {}, "", function()
        STAT_SET_INT("H4CNF_GRAPPEL", 2022)
        STAT_SET_INT("H4CNF_UNIFORM", 12)
        STAT_SET_INT("H4CNF_BOLTCUT", 4161)
        STAT_SET_INT("H4CNF_TROJAN", 1)
        Notify("Equipments will spawn next to Airport:\n\n- Grappling Hook\n- Guard Clothing\n- Bolt Cutters")
    end)

    menu.action(CAYO_EQUIPM, "Set to Equipments spawn next to Docks", {}, "", function()
        STAT_SET_INT("H4CNF_GRAPPEL", 3671)
        STAT_SET_INT("H4CNF_UNIFORM", 5256)
        STAT_SET_INT("H4CNF_BOLTCUT", 4424)
        STAT_SET_INT("H4CNF_TROJAN", 2)
        Notify("Equipments will spawn next to Docks:\n\n- Grappling Hook\n- Guard Clothing\n- Bolt Cutters")
    end)

    menu.action(CAYO_EQUIPM, "Set to Equipments spawn next to Compound", {}, "", function()
        STAT_SET_INT("H4CNF_GRAPPEL", 85324)
        STAT_SET_INT("H4CNF_UNIFORM", 61034)
        STAT_SET_INT("H4CNF_BOLTCUT", 4612)
        STAT_SET_INT("H4CNF_TROJAN", 5)
        Notify("Equipments will spawn next to Compound:\n\n- Grappling Hook\n- Guard Clothing\n- Bolt Cutters")
    end)

---

--- Cayo Truck 

    menu.action(CAYO_TRUCK, "Modify Supply Truck spawn to Airport", {}, "", function()
        STAT_SET_INT("H4CNF_TROJAN", 1)
        Notify("Supply Truck will now spawn next to Airport.")
    end)

    menu.action(CAYO_TRUCK, "Modify Supply Truck spawn to North Dock", {}, "", function()
        STAT_SET_INT("H4CNF_TROJAN", 2)
        Notify("Supply Truck will now spawn next to North Dock.")
    end)

    menu.action(CAYO_TRUCK, "Modify Supply Truck spawn to Main Dock (East)", {}, "", function()
        STAT_SET_INT("H4CNF_TROJAN", 3)
        Notify("Supply Truck will now spawn next to Main Dock - East.")
    end)

    menu.action(CAYO_TRUCK, "Modify Supply Truck spawn to Main Dock (West)", {}, "", function()
        STAT_SET_INT("H4CNF_TROJAN", 4)
        Notify("Supply Truck will now spawn next to Main Dock - West.")
    end)

    menu.action(CAYO_TRUCK, "Modify Supply Truck spawn next to Compound", {}, "", function()
        STAT_SET_INT("H4CNF_TROJAN", 5)
        Notify("Supply Truck will now spawn next to Compound.")
    end)

---

--- Cayo Difficulty

    menu.action(CAYO_DFFCTY, "Change Difficulty to Normal", {}, "", function()
        STAT_SET_INT("H4_PROGRESS", 126823)
        Notify("Difficulty has been changed to Normal.")
    end)

    menu.action(CAYO_DFFCTY, "Change Difficulty to Hard", {}, "", function()
        STAT_SET_INT("H4_PROGRESS", 131055)
        Notify("Difficulty has been changed to Hard.")
    end)

---

--- More Options

    menu.action(MORE_OPTIONS, "Unlock Cayo Perico Awards", {}, "", function()
        STAT_SET_BOOL("AWD_INTELGATHER", true)
        STAT_SET_BOOL("AWD_COMPOUNDINFILT", true)
        STAT_SET_BOOL("AWD_LOOT_FINDER", true)
        STAT_SET_BOOL("AWD_MAX_DISRUPT", true)
        STAT_SET_BOOL("AWD_THE_ISLAND_HEIST", true)
        STAT_SET_BOOL("AWD_GOING_ALONE", true)
        STAT_SET_BOOL("AWD_TEAM_WORK", true)
        STAT_SET_BOOL("AWD_MIXING_UP", true)
        STAT_SET_BOOL("AWD_PRO_THIEF", true)
        STAT_SET_BOOL("AWD_CAT_BURGLAR", true)
        STAT_SET_BOOL("AWD_ONE_OF_THEM", true)
        STAT_SET_BOOL("AWD_GOLDEN_GUN", true)
        STAT_SET_BOOL("AWD_ELITE_THIEF", true)
        STAT_SET_BOOL("AWD_PROFESSIONAL", true)
        STAT_SET_BOOL("AWD_HELPING_OUT", true)
        STAT_SET_BOOL("AWD_COURIER", true)
        STAT_SET_BOOL("AWD_PARTY_VIBES", true)
        STAT_SET_BOOL("AWD_HELPING_HAND", true)
        STAT_SET_BOOL("AWD_ELEVENELEVEN", true)
        STAT_SET_BOOL("COMPLETE_H4_F_USING_VETIR", true)
        STAT_SET_BOOL("COMPLETE_H4_F_USING_LONGFIN", true)
        STAT_SET_BOOL("COMPLETE_H4_F_USING_ANNIH", true)
        STAT_SET_BOOL("COMPLETE_H4_F_USING_ALKONOS", true)
        STAT_SET_BOOL("COMPLETE_H4_F_USING_PATROLB", true)
        -- BOOL
        STAT_SET_INT("AWD_LOSTANDFOUND", 500000)
        STAT_SET_INT("AWD_SUNSET", 1800000)
        STAT_SET_INT("AWD_TREASURE_HUNTER", 1000000)
        STAT_SET_INT("AWD_WRECK_DIVING", 1000000)
        STAT_SET_INT("AWD_KEINEMUSIK", 1800000)
        STAT_SET_INT("AWD_PALMS_TRAX", 1800000)
        STAT_SET_INT("AWD_MOODYMANN", 1800000)
        STAT_SET_INT("AWD_FILL_YOUR_BAGS", 1000000000)
        STAT_SET_INT("AWD_WELL_PREPARED", 80)
        STAT_SET_INT("H4_H4_DJ_MISSIONS", 0xFFFFFFF)
        -- INT
        Notify("Cayo Perico Awards Unlocked!")
    end)

    menu.action(MORE_OPTIONS, "Complete all Missions only", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 0xFFFFFFF)
        STAT_SET_INT("H4CNF_APPROACH", 0xFFFFFFF)
        STAT_SET_INT("H4CNF_BS_ENTR", 63)
        STAT_SET_INT("H4CNF_BS_GEN", 63)
        STAT_SET_INT("H4CNF_WEP_DISRP", 3)
        STAT_SET_INT("H4CNF_ARM_DISRP", 3)
        STAT_SET_INT("H4CNF_HEL_DISRP", 3)
        Notify("All missions are completed!")
    end)

    menu.action(MORE_OPTIONS, "Force the longest final Cutscene", {}, "", function()
        STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 0)
        Notify("Keep in mind that you must use this option before starting the Heist\n\nDone!")
    end)

    menu.action(MORE_OPTIONS, "Set Heist to Default [Reset]", {}, "", function()
        STAT_SET_INT("H4_MISSIONS", 0)
        STAT_SET_INT("H4_PROGRESS", 0)
        STAT_SET_INT("H4CNF_APPROACH", 0)
        STAT_SET_INT("H4CNF_BS_ENTR", 0)
        STAT_SET_INT("H4CNF_BS_GEN", 0)
        STAT_SET_INT("H4_PLAYTHROUGH_STATUS", 0)
        Notify("Heist has been restored.")
    end)

    -- menu.action(MORE_OPTIONS, "Remove Heist Cooldown", {}, "", function()
    --     STAT_SET_INT("H4_COOLDOWN", 0)
    --     STAT_SET_INT("H4_COOLDOWN_HARD", 0)
    --     STAT_SET_INT("MPPLY_H4_COOLDOWN", 0)
    --     Notify("Alert: This is NOT a bypass for the Server-Side Cooldown (Payout)\n\nPlease wait up to 15 minutes to avoid not receiving the money in the end.")
    -- end)
    
---


--- Casino Presets

    menu.action(CASINO_PRESETS, "Load Random Approach", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        -- INT
        STAT_SET_INT("H3OPT_TARGET", math.random(0, 3))
        STAT_SET_INT("H3_HARD_APPROACH", math.random(1, 3))
        STAT_SET_INT("H3OPT_CREWWEAP", math.random(1, 5))
        STAT_SET_INT("H3OPT_CREWDRIVER", math.random(1, 5))
        STAT_SET_INT("H3OPT_CREWHACKER", math.random(1, 5))
        STAT_SET_INT("H3OPT_WEAPS", math.random(0, 1))
        STAT_SET_INT("H3OPT_VEHS", math.random(0, 3))
        STAT_SET_INT("H3OPT_MASKS", math.random(1, 12))
        STAT_SET_INT("H3OPT_APPROACH", math.random(1, 3))
        -- INT Random
        Notify("Make sure you have paid the heist on the planning screen before using this option\n\nRandom Preset Loaded!")
    end)

    menu.action(CASINO_PRESETS, "Silent & Sneaky Approach [Hard]", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_APPROACH", 1)
        STAT_SET_INT("H3_HARD_APPROACH", 1)
        STAT_SET_INT("H3OPT_TARGET", 3)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_CREWWEAP", 2)
        STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        STAT_SET_INT("H3OPT_CREWHACKER", 4)
        STAT_SET_INT("H3OPT_WEAPS", 0)
        STAT_SET_INT("H3OPT_VEHS", 3)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_MASKS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("Silent & Sneaky Approach Hard Difficulty\n\nTarget: Diamond\nVehicle: Everon\nDriver Crew: Chester McCoy\n\nWeapon: Rifle + Shotgun\nGunman: Gustavo Mota\n\nHacker: Avi Schwartzman\nUndetected: 3 minutes 30s\nDetected: 2 minutes 26s\n\nMask: Hunter Set")
    end)

    menu.action(CASINO_PRESETS, "Silent & Sneaky Approach [Normal]", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_APPROACH", 1)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        STAT_SET_INT("H3OPT_TARGET", 3)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_CREWWEAP", 2)
        STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        STAT_SET_INT("H3OPT_CREWHACKER", 4)
        STAT_SET_INT("H3OPT_WEAPS", 0)
        STAT_SET_INT("H3OPT_VEHS", 3)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_MASKS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("Silent & Sneaky Approach Normal Difficulty\n\nTarget: Diamond\nVehicle: Everon\nDriver Crew: Chester McCoy\n\nWeapon: Rifle + Shotgun\nGunman: Gustavo Mota\n\nHacker: Avi Schwartzman\nUndetected: 3 minutes 30s\nDetected: 2 minutes 26s\n\nMask: Hunter Set")
    end)

    menu.action(CASINO_PRESETS, "BigCon Approach [Hard]", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_APPROACH", 2)
        STAT_SET_INT("H3_HARD_APPROACH", 2)
        STAT_SET_INT("H3OPT_TARGET", 3)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_CREWWEAP", 2)
        STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        STAT_SET_INT("H3OPT_CREWHACKER", 4)
        STAT_SET_INT("H3OPT_WEAPS", 0)
        STAT_SET_INT("H3OPT_VEHS", 3)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_MASKS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("BigCon Approach Hard Difficulty\n\nTarget: Diamond\nVehicle: Everon\nDriver Crew: Chester McCoy\n\nWeapon: Rifle + Shotgun\nGunman: Gustavo Mota\n\nHacker: Avi Schwartzman\nUndetected: 3 minutes 30s\nDetected: 2 minutes 26s\n\nMask: Hunter Set")
    end)

    menu.action(CASINO_PRESETS, "BigCon Approach [Normal]", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_APPROACH", 2)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        STAT_SET_INT("H3OPT_TARGET", 3)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_CREWWEAP", 2)
        STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        STAT_SET_INT("H3OPT_CREWHACKER", 4)
        STAT_SET_INT("H3OPT_WEAPS", 0)
        STAT_SET_INT("H3OPT_VEHS", 3)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_MASKS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("BigCon Approach Normal Difficulty\n\nTarget: Diamond\nVehicle: Everon\nDriver Crew: Chester McCoy\n\nWeapon: Rifle + Shotgun\nGunman: Gustavo Mota\n\nHacker: Avi Schwartzman\nUndetected: 3 minutes 30s\nDetected: 2 minutes 26s\n\nMask: Hunter Set")
    end)

    menu.action(CASINO_PRESETS, "Aggressive Approach [Hard]", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_APPROACH", 3)
        STAT_SET_INT("H3_HARD_APPROACH", 3)
        STAT_SET_INT("H3OPT_TARGET", 3)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_CREWWEAP", 2)
        STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        STAT_SET_INT("H3OPT_CREWHACKER", 4)
        STAT_SET_INT("H3OPT_WEAPS", 1)
        STAT_SET_INT("H3OPT_VEHS", 3)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_MASKS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("Aggressive Approach Hard Difficulty\n\nTarget: Diamond\nVehicle: Everon\nDriver Crew: Chester McCoy\n\nWeapon: Rifle + Shotgun\nGunman: Gustavo Mota\n\nHacker: Avi Schwartzman\nUndetected: 3 minutes 30s\nDetected: 2 minutes 26s\n\nMask: Hunter Set")
    end)

    menu.action(CASINO_PRESETS, "Aggressive Approach [Normal]", {}, "You must pay to start the heist, then go outside the arcade/garage to apply the preset correctly!", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("CAS_HEIST_FLOW", 0xFFFFFFF)
        STAT_SET_INT("H3_LAST_APPROACH", 4)
        STAT_SET_INT("H3OPT_APPROACH", 3)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        STAT_SET_INT("H3OPT_TARGET", 3)
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_CREWWEAP", 2)
        STAT_SET_INT("H3OPT_CREWDRIVER", 5)
        STAT_SET_INT("H3OPT_CREWHACKER", 4)
        STAT_SET_INT("H3OPT_WEAPS", 1)
        STAT_SET_INT("H3OPT_VEHS", 3)
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 3)
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        STAT_SET_INT("H3OPT_MASKS", 2)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("Aggressive Approach Normal Difficulty\n\nTarget: Diamond\nVehicle: Everon\nDriver Crew: Chester McCoy\n\nWeapon: Rifle + Shotgun\nGunman: Gustavo Mota\n\nHacker: Avi Schwartzman\nUndetected: 3 minutes 30s\nDetected: 2 minutes 26s\n\nMask: Hunter Set")
    end)

---

--- Advanced Features

    menu.action(CAH_ADVCED, "Remove IA Crew Payout", {}, "", function()
        STAT_SET_INT("H3OPT_CREWWEAP", 6)
        STAT_SET_INT("H3OPT_CREWDRIVER", 6)
        STAT_SET_INT("H3OPT_CREWHACKER", 6)
        Notify("Use after stealing the target, before leaving the tunnel\n\nCrew removed.")
    end)

---

--- Casino Board 1

    menu.action(CASINO_BOARD1, "Unlock all Points of Interests & Access Points", {}, "", function()
        STAT_SET_INT("H3OPT_POI", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 2047)
        Notify("Unlocked Successfully!")
    end)

---

--- Casino Target

    menu.action(CASINO_TARGET, "Diamond", {}, "", function()
        STAT_SET_INT("H3OPT_TARGET", 3)
        Notify("Target changed to Diamond.")
    end)

    menu.action(CASINO_TARGET, "Gold", {}, "", function()
        STAT_SET_INT("H3OPT_TARGET", 1)
        Notify("Target changed to Gold.")
    end)

    menu.action(CASINO_TARGET, "Artwork", {}, "", function()
        STAT_SET_INT("H3OPT_TARGET", 2)
        Notify("Target changed to Artwork.")
    end)

    menu.action(CASINO_TARGET, "Cash", {}, "", function()
        STAT_SET_INT("H3OPT_TARGET", 0)
        Notify("Target changed to Cash.")
    end)

---

--- Casino Difficulty 
    
    menu.action(BOARD1_APPROACH, "Silent and Sneaky Approach (Hard)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 1)
        STAT_SET_INT("H3_HARD_APPROACH", 1)
        Notify("Approach changed to Silent and Sneaky (Hard)")
    end)

    menu.action(BOARD1_APPROACH, "Silent and Sneaky Approach (Normal)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 1)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        Notify("Approach changed to Silent and Sneaky (Normal)")
    end)

    menu.action(BOARD1_APPROACH, "BigCon Approach (Hard)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 2)
        STAT_SET_INT("H3_HARD_APPROACH", 2)
        Notify("Approach changed to BigCon (Hard)")
    end)

    menu.action(BOARD1_APPROACH, "BigCon Approach (Normal)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 2)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        Notify("Approach changed to BigCon (Normal)")
    end)

    menu.action(BOARD1_APPROACH, "Aggressive Approach (Hard)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 3)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        Notify("Approach changed to Aggressive (Hard)")
    end)

    menu.action(BOARD1_APPROACH, "Aggressive Approach (Normal)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 1)
        STAT_SET_INT("H3_HARD_APPROACH", 1)
        Notify("Approach changed to Aggressive (Normal)")
    end)

---

--- Change Gunman

    local CASINO_GUNMAN = menu.list(CASINO_BOARD2, "Change Gunman", {}, "", function(); end)

        menu.action(CASINO_GUNMAN, "Chester McCoy (10%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", 4)
            Notify("Chester McCoy now as Gunman\nCut 10%")
        end)

        menu.action(CASINO_GUNMAN, "Gustavo Mota (9%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", 2)
            Notify("Gustavo Mota now as Gunman\nCut 9%")
        end)

        menu.action(CASINO_GUNMAN, "Patrick McReary (8%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", 5)
            Notify("Patrick McReary now as Gunman\nCut 8%")
        end)

        menu.action(CASINO_GUNMAN, "Charlie Reed (7%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", 3)
            Notify("Charlie Reed now as Gunman\nCut 7%")
        end)

        menu.action(CASINO_GUNMAN, "Karl Abolaji (5%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", 1)
            Notify("Karl Abolaji now as Gunman\nCut 5%")
        end)

        menu.action(CASINO_GUNMAN, "Random Gunman Member (??%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", math.random(1, 5))
            Notify("Gunman Randomized\nCut ??")
        end)

        menu.action(CASINO_GUNMAN, "Remove Gunman Member (0% Payout)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWWEAP", 6)
            Notify("Gunman Member Removed.")
        end)

    ---

    local CASINO_GUNMAN_var = menu.list(CASINO_GUNMAN, "Weapon Variation", {}, "", function(); end)

        menu.action(CASINO_GUNMAN_var, "Best Variation", {}, "", function()
            STAT_SET_INT("H3OPT_WEAPS", 1)
            Notify("Variation Changed to the Best")
        end)

        menu.action(CASINO_GUNMAN_var, "Worst Variation", {}, "", function()
            STAT_SET_INT("H3OPT_WEAPS", 0)
            Notify("Variation Changed to the Worst")
        end)

    ---

---

--- Change Vehicle

    local CASINO_DRIVER_TEAM = menu.list(CASINO_BOARD2, "Vehicle Variation",  {}, "", function(); end)

        menu.action(CASINO_DRIVER_TEAM, "Chester McCoy (10%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", 5)
            Notify("Vehicle Variation Best\nVehicle: Everon 4 Seats\n\nVehicle Variation Good\nVehicle: Outlaw 2 Seats\n\nVehicle Variation Fine\nVehicle: Vagrant 2 Seats\n\nVehicle Variation Worst\nVehicle: Zhaba 4 Seats", "Chester McCoy Cut 10%")
        end)

        menu.action(CASINO_DRIVER_TEAM, "Eddie Toh (9%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", 3)
            Notify("Vehicle Variation Best\nVehicle: Komoda 4 Seats\n\nVehicle Variation Good\nVehicle: Ellie 2 Seats\n\nVehicle Variation Fine\nVehicle: Gauntlet Classic 2 Seats\n\nVehicle Variation Worst\nVehicle: Sultan Classic 4 Seats", "Eddie Toh Cut 9%")
        end)

        menu.action(CASINO_DRIVER_TEAM, "Taliana Martinez (7%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", 2)
            Notify("Vehicle Variation Best\nVehicle: Jugular 4 Seats\n\nVehicle Variation Good\nVehicle: Sugoi 4 Seats\n\nVehicle Variation: Fine\nVehicle Drift Yosemite 2 Seats\n\nVehicle Variation Worst\nVehicle: Retinue Mk II 2 Seats", "Taliana Martinez Cut 7%")
        end)

        menu.action(CASINO_DRIVER_TEAM, "Zach Nelson (6%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", 4)
            Notify("Vehicle Variation Best\nVehicle: Lectro 2 Seats\n\nVehicle Variation Good\nVehicle: Defiler 1 Seat\n\nVehicle Variation Fine\nVehicle: Stryder 1 Seat\n\nVehicle Variation Worst\nVehicle: Manchez 2 Seats", "Zach Nelson Cut 6%")
        end)

        menu.action(CASINO_DRIVER_TEAM, "Karim Denz (5%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", 1)
            Notify("Vehicle Variation Best\nVehicle: Sentinel Classic 2 Seats\n\nVehicle Variation: Good\nVehicle: Kanjo 2 Seats\n\nVehicle Variation Fine\nVehicle: Asbo 2 Seats\n\nVehicle Variation Worst\nVehicle: Issi Classic 2 Seats", "Karim Denz Cut 5%")
        end)

        menu.action(CASINO_DRIVER_TEAM, "Random Driver Member", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", math.random(1, 5))
            Notify("Crew Driver randomized.")
        end)

        menu.action(CASINO_DRIVER_TEAM, "Remove Driver Member (0% Payout)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWDRIVER", 6)
            Notify("Driver Member Removed.")
        end)

    ---

    local CAH_DRIVER_TEAM_var = menu.list(CASINO_DRIVER_TEAM, "Vehicle Variation", {}, "", function(); end)

        menu.action(CAH_DRIVER_TEAM_var, "Best Variation", {}, "", function()
            STAT_SET_INT("H3OPT_VEHS", 3)
            Notify("Best Variation Selected")
        end)

        menu.action(CAH_DRIVER_TEAM_var, "Good Variation", {}, "", function()
            STAT_SET_INT("H3OPT_VEHS", 2)
            Notify("Good Variation")
        end)

        menu.action(CAH_DRIVER_TEAM_var, "Fine Variation", {}, "", function()
            STAT_SET_INT("H3OPT_VEHS", 1)
            Notify("Fine Variation")
        end)

        menu.action(CAH_DRIVER_TEAM_var, "Worst Variation", {}, "", function()
            STAT_SET_INT("H3OPT_VEHS", 0)
            Notify("Worst Variation")
        end)

        menu.action(CAH_DRIVER_TEAM_var, "Random Car Variation", {}, "", function()
            STAT_SET_INT("H3OPT_VEHS", math.random(0, 3))
            Notify("Car Randomized")
        end)

    ---

---

--- Change Hacker

    local CASINO_HACKERs = menu.list(CASINO_BOARD2, "Change Hacker", {}, "", function(); end)

        menu.action(CASINO_HACKERs, "Avi Schwartzman (10%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 4)
            Notify("Name: Avi Schwartzman\nSkill: Expert\nTime Undetected: 3:30\nTime Detected: 2:26\nCut: 10%")
        end)

        menu.action(CASINO_HACKERs, "Paige Harris (9%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 5)
            Notify("Name: Paige Harris\nSkill: Expert\nTime Undetected: 3:25\nTime Detected: 2:23\nCut: 9%")
        end)

        menu.action(CASINO_HACKERs, "Christian Feltz (7%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 2)
            Notify("Name: Christian Feltz\nSkill: Good\nTime Undetected: 2:59\nTime Detected: 2:05\nCut: 7%")
        end)

        menu.action(CASINO_HACKERs, "Yohan Blair (5%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 3)
            Notify("Name: Yohan Blair\nSkill: Good\nTime Undetected: 2:52\nTime Detected: 2:01\nCut: 5%")
        end)

        menu.action(CASINO_HACKERs, "Rickie Luken (3%)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 1)
            Notify("Name: Rickie Luken\nSkill: Poor\nTime Undetected: 2:26\nTime Detected: 1:42\nCut: 3%")
        end)

        menu.action(CASINO_HACKERs, "Random Hacker Member", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", math.random(1, 5))
            Notify("Hacker member randomized.")
        end)

        menu.action(CASINO_HACKERs, "Remove Hacker Member (0% Payout)", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 6)
            Notify("Hacker member removed.")
        end)

    ---

---

--- Choose Mask 
    
    local CASINO_MASK = menu.list(CASINO_BOARD2, "Choose Mask", {}, "", function(); end)

        menu.action(CASINO_MASK, "Remove Mask", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 0xFFFFFFF)
            Notify("Mask: Removed")
        end)

        menu.action(CASINO_MASK, "Geometric Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 1)
            Notify("Mask: Geometric")
        end)

        menu.action(CASINO_MASK, "Hunter Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 2)
            Notify("Mask: Hunter")
        end)

        menu.action(CASINO_MASK, "Oni Half Mask Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 3)
            Notify("Mask: Oni Half Mask")
        end)

        menu.action(CASINO_MASK, "Emoji Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 4)
            Notify("Mask: Emoji")
        end)

        menu.action(CASINO_MASK, "Ornate Skull Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 5)
            Notify("Mask: Ornate Skull")
        end)

        menu.action(CASINO_MASK, "Lucky Fruit Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 6)
            Notify("Mask: Lucky Fruit")
        end)

        menu.action(CASINO_MASK, "Guerilla Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 7)
            Notify("Mask: Guerilla")
        end)

        menu.action(CASINO_MASK, "Clown Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 8)
            Notify("Mask: Clown")
        end)

        menu.action(CASINO_MASK, "Animal Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 9)
            Notify("Mask: Animal")
        end)

        menu.action(CASINO_MASK, "Riot Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 10)
            Notify("Mask: Riot")
        end)

        menu.action(CASINO_MASK, "Oni Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 11)
            Notify("Mask: Oni Set")
        end)

        menu.action(CASINO_MASK, "Hocket Set", {}, "", function()
            STAT_SET_INT("H3OPT_CREWHACKER", 12)
            Notify("Mask: Hockey Set")
        end)

    ---

---

--- Casino Board 2

    menu.action(CASINO_BOARD2, "Unlock Scan Card LVL 2", {}, "", function()
        STAT_SET_INT("H3OPT_KEYLEVELS", 2)
        Notify("Scan Card LVL 2 Unlocked.")
    end)
   
    menu.action(CASINO_BOARD2, "Weaken Duggan Guards", {}, "", function()
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 3)
        Notify("Duggan Guards Weakened.")
    end)

---

--- Casino Board 3

    menu.action(CASINO_BOARD3, "Remove Drill for Silent and Aggressive Approach", {}, "", function()
        STAT_SET_INT("H3OPT_BITSET0", -8849)
        Notify("Drill removed for Silent and Aggressive Approach.")
    end)

    menu.action(CASINO_BOARD3, "Remove Drill for BigCon Approach only", {}, "", function()
        STAT_SET_INT("H3OPT_BITSET0", -186)
        Notify("Drill removed for BigCon.")
    end)

---

--- Casino Unloader

    menu.action(CASINO_LBOARDS, "Load all Boards", {}, "", function()
        STAT_SET_INT("H3OPT_BITSET1", 0xFFFFFFF)
        STAT_SET_INT("H3OPT_BITSET0", 0xFFFFFFF)
        Notify("All Planning Board Loaded.")
    end)

    menu.action(CASINO_LBOARDS, "Unload all Boards", {}, "", function()
        STAT_SET_INT("H3OPT_BITSET1", 0)
        STAT_SET_INT("H3OPT_BITSET0", 0)
        Notify("All Planning Board Unloaded.")
    end)

---

--- Casino More

    menu.action(CASINO_MORE, "Unlock Casino Awards", {}, "", function()
        STAT_SET_INT("CAS_HEIST_NOTS", 0xFFFFFFF)
        STAT_SET_INT("CH_ARC_CAB_CLAW_TROPHY", 0xFFFFFFF)
        STAT_SET_INT("CH_ARC_CAB_LOVE_TROPHY", 0xFFFFFFF)
        STAT_SET_INT("SIGNAL_JAMMERS_COLLECTED", 50)
        STAT_SET_INT("AWD_ODD_JOBS", 52)
        STAT_SET_INT("AWD_PREPARATION", 40)
        STAT_SET_INT("AWD_ASLEEPONJOB", 20)
        STAT_SET_INT("AWD_DAICASHCRAB", 100000)
        STAT_SET_INT("AWD_BIGBRO", 40)
        STAT_SET_INT("AWD_SHARPSHOOTER", 40)
        STAT_SET_INT("AWD_RACECHAMP", 40)
        STAT_SET_INT("AWD_BATSWORD", 1000000)
        STAT_SET_INT("AWD_COINPURSE", 950000)
        STAT_SET_INT("AWD_ASTROCHIMP", 3000000)
        STAT_SET_INT("AWD_MASTERFUL", 40000)
        STAT_SET_INT("H3_BOARD_DIALOGUE0", 0xFFFFFFF)
        STAT_SET_INT("H3_BOARD_DIALOGUE1", 0xFFFFFFF)
        STAT_SET_INT("H3_BOARD_DIALOGUE2", 0xFFFFFFF)
        STAT_SET_INT("H3_VEHICLESUSED", 0xFFFFFFF)
        -- INT
        STAT_SET_BOOL("AWD_FIRST_TIME1", true)
        STAT_SET_BOOL("AWD_FIRST_TIME2", true)
        STAT_SET_BOOL("AWD_FIRST_TIME3", true)
        STAT_SET_BOOL("AWD_FIRST_TIME4", true)
        STAT_SET_BOOL("AWD_FIRST_TIME5", true)
        STAT_SET_BOOL("AWD_FIRST_TIME6", true)
        STAT_SET_BOOL("AWD_ALL_IN_ORDER", true)
        STAT_SET_BOOL("AWD_SUPPORTING_ROLE", true)
        STAT_SET_BOOL("AWD_LEADER", true)
        STAT_SET_BOOL("AWD_ODD_JOBS", true)
        STAT_SET_BOOL("AWD_SURVIVALIST", true)
        STAT_SET_BOOL("AWD_SCOPEOUT", true)
        STAT_SET_BOOL("AWD_CREWEDUP", true)
        STAT_SET_BOOL("AWD_MOVINGON", true)
        STAT_SET_BOOL("AWD_PROMOCAMP", true)
        STAT_SET_BOOL("AWD_GUNMAN", true)
        STAT_SET_BOOL("AWD_SMASHNGRAB", true)
        STAT_SET_BOOL("AWD_INPLAINSI", true)
        STAT_SET_BOOL("AWD_UNDETECTED", true)
        STAT_SET_BOOL("AWD_ALLROUND", true)
        STAT_SET_BOOL("AWD_ELITETHEIF", true)
        STAT_SET_BOOL("AWD_PRO", true)
        STAT_SET_BOOL("AWD_SUPPORTACT", true)
        STAT_SET_BOOL("AWD_SHAFTED", true)
        STAT_SET_BOOL("AWD_COLLECTOR", true)
        STAT_SET_BOOL("AWD_DEADEYE", true)
        STAT_SET_BOOL("AWD_PISTOLSATDAWN", true)
        STAT_SET_BOOL("AWD_TRAFFICAVOI", true)
        STAT_SET_BOOL("AWD_CANTCATCHBRA", true)
        STAT_SET_BOOL("AWD_WIZHARD", true)
        STAT_SET_BOOL("AWD_APEESCAPE", true)
        STAT_SET_BOOL("AWD_MONKEYKIND", true)
        STAT_SET_BOOL("AWD_AQUAAPE", true)
        STAT_SET_BOOL("AWD_KEEPFAITH", true)
        STAT_SET_BOOL("AWD_TRUELOVE", true)
        STAT_SET_BOOL("AWD_NEMESIS", true)
        STAT_SET_BOOL("AWD_FRIENDZONED", true)
        STAT_SET_BOOL("VCM_FLOW_CS_RSC_SEEN", true)
        STAT_SET_BOOL("VCM_FLOW_CS_BWL_SEEN", true)
        STAT_SET_BOOL("VCM_FLOW_CS_MTG_SEEN", true)
        STAT_SET_BOOL("VCM_FLOW_CS_OIL_SEEN", true)
        STAT_SET_BOOL("VCM_FLOW_CS_DEF_SEEN", true)
        STAT_SET_BOOL("VCM_FLOW_CS_FIN_SEEN", true)
        STAT_SET_BOOL("CAS_VEHICLE_REWARD", false)
        STAT_SET_BOOL("HELP_FURIA", true)
        STAT_SET_BOOL("HELP_MINITAN", true)
        STAT_SET_BOOL("HELP_YOSEMITE2", true)
        STAT_SET_BOOL("HELP_ZHABA", true)
        STAT_SET_BOOL("HELP_IMORGEN", true)
        STAT_SET_BOOL("HELP_SULTAN2", true)
        STAT_SET_BOOL("HELP_VAGRANT", true)
        STAT_SET_BOOL("HELP_VSTR", true)
        STAT_SET_BOOL("HELP_STRYDER", true)
        STAT_SET_BOOL("HELP_SUGOI", true)
        STAT_SET_BOOL("HELP_KANJO", true)
        STAT_SET_BOOL("HELP_FORMULA", true)
        STAT_SET_BOOL("HELP_FORMULA2", true)
        STAT_SET_BOOL("HELP_JB7002", true)
        -- BOOL
        Notify("Casino Heist Awards Unlocked!")
    end)

    menu.action(CASINO_MORE, "Remove Heist Prepare Cooldown", {}, "", function()
        STAT_SET_INT("H3_COMPLETEDPOSIX", 0xFFFFFFF)
        STAT_SET_INT("MPPLY_H3_COOLDOWN", 0xFFFFFFF)
        Notify("This is not a bypass for the server-side cooldown. (payment)")
    end)

    menu.action(CASINO_MORE, "Skip Agatha Baker missions to the last one", {}, "", function()
        STAT_SET_INT("VCM_FLOW_PROGRESS", 0xFFFFFFF)
        STAT_SET_INT("VCM_STORY_PROGRESS", 5)
        -- INT
        STAT_SET_BOOL("AWD_LEADER", true)
        STAT_SET_BOOL("VCM_FLOW_CS_FIN_SEEN", true)
        -- BOOL
        Notify("Your wish was successfully granted.")
    end)

    menu.action(CASINO_MORE, "Set Heist to Default (Reset)", {}, "", function()
        STAT_SET_INT("H3_LAST_APPROACH", 0)
        STAT_SET_INT("H3OPT_APPROACH", 0)
        STAT_SET_INT("H3_HARD_APPROACH", 0)
        STAT_SET_INT("H3OPT_TARGET", 0)
        STAT_SET_INT("H3OPT_POI", 0)
        STAT_SET_INT("H3OPT_ACCESSPOINTS", 0)
        STAT_SET_INT("H3OPT_BITSET1", 0)
        STAT_SET_INT("H3OPT_CREWWEAP", 0)
        STAT_SET_INT("H3OPT_CREWDRIVER", 0)
        STAT_SET_INT("H3OPT_CREWHACKER", 0)
        STAT_SET_INT("H3OPT_WEAPS", 0)
        STAT_SET_INT("H3OPT_VEHS", 0)        
        STAT_SET_INT("H3OPT_DISRUPTSHIP", 0)
        STAT_SET_INT("H3OPT_BODYARMORLVL", 0)
        STAT_SET_INT("H3OPT_KEYLEVELS", 0)
        STAT_SET_INT("H3OPT_MASKS", 0)
        STAT_SET_INT("H3OPT_BITSET0", 0)
        Notify("Now call Lester and try to cancel the Casino Heist.")
    end)

---


--- Dooms Preset

    menu.action(DOOMS_PRESETS, "The Data Breaches ACT I [Final Heist]", {}, "", function()
        STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 503)
        STAT_SET_INT("GANGOPS_HEIST_STATUS", -229383)
        STAT_SET_INT("GANGOPS_FLOW_NotifyS", 1557)
        Notify("The Data Breaches ACT I\nIs ready to play!")
    end)

    menu.action(DOOMS_PRESETS, "The Bogdan Problem ACT II [Final Heist]", {}, "", function()
        STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 240)
        STAT_SET_INT("GANGOPS_HEIST_STATUS", -229378)
        STAT_SET_INT("GANGOPS_FLOW_NotifyS", 1557)
        Notify("The Bogdan Problem ACT II\nIs ready to play!")
    end)

    menu.action(DOOMS_PRESETS, "The Doomsday Scenario ACT III [Final Heist]", {}, "", function()
        STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 16368)
        STAT_SET_INT("GANGOPS_HEIST_STATUS", -229380)
        STAT_SET_INT("GANGOPS_FLOW_NotifyS", 1557)
        Notify("The Doomsday Scenario ACT III\nIs Ready to play!")
    end)

---

--- Dooms Heist

    menu.action(DOOMS_HEIST, "Unlock all Doomsday Heist", {}, "", function()
        STAT_SET_INT("GANGOPS_HEIST_STATUS", 0xFFFFFFF)
        STAT_SET_INT("GANGOPS_HEIST_STATUS", -229384)
        Notify("Call the Lester and ask to cancel the Doomsday Heist (Three Times)\nDo this only once")
    end)

    menu.action(DOOMS_HEIST, "Complete all preparations (Not setups)", {}, "", function()
        STAT_SET_INT("GANGOPS_FM_MISSION_PROG", 0xFFFFFFF)
        Notify("All Preps are completed.")
    end)

    menu.action(DOOMS_HEIST, "Set Heist to Default (Reset)", {}, "", function()
        STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 240)
        STAT_SET_INT("GANGOPS_HEIST_STATUS", 0)
        STAT_SET_INT("GANGOPS_FLOW_NotifyS", 1557)
        Notify("Doomsday restored\nGo to a new session!!!")
    end)

    menu.action(DOOMS_HEIST, "Unlock Doomsday Heist Awards", {}, "", function()
        STAT_SET_INT("GANGOPS_FM_MISSION_PROG", 0xFFFFFFF)
        STAT_SET_INT("GANGOPS_FLOW_MISSION_PROG", 0xFFFFFFF)
        STAT_SET_INT("MPPLY_GANGOPS_ALLINORDER", 100)
        STAT_SET_INT("MPPLY_GANGOPS_LOYALTY", 100)
        STAT_SET_INT("MPPLY_GANGOPS_CRIMMASMD", 100)
        STAT_SET_INT("MPPLY_GANGOPS_LOYALTY2", 100)
        STAT_SET_INT("MPPLY_GANGOPS_LOYALTY3", 100)
        STAT_SET_INT("MPPLY_GANGOPS_CRIMMASMD2", 100)
        STAT_SET_INT("MPPLY_GANGOPS_CRIMMASMD3", 100)
        STAT_SET_INT("MPPLY_GANGOPS_SUPPORT", 100)
        STAT_SET_INT("CR_GANGOP_MORGUE", 10)
        STAT_SET_INT("CR_GANGOP_DELUXO", 10)
        STAT_SET_INT("CR_GANGOP_SERVERFARM", 10)
        STAT_SET_INT("CR_GANGOP_IAABASE_FIN", 10)
        STAT_SET_INT("CR_GANGOP_STEALOSPREY", 10)
        STAT_SET_INT("CR_GANGOP_FOUNDRY", 10)
        STAT_SET_INT("CR_GANGOP_RIOTVAN", 10)
        STAT_SET_INT("CR_GANGOP_SUBMARINECAR", 10)
        STAT_SET_INT("CR_GANGOP_SUBMARINE_FIN", 10)
        STAT_SET_INT("CR_GANGOP_PREDATOR", 10)
        STAT_SET_INT("CR_GANGOP_BMLAUNCHER", 10)
        STAT_SET_INT("CR_GANGOP_BCCUSTOM", 10)
        STAT_SET_INT("CR_GANGOP_STEALTHTANKS", 10)
        STAT_SET_INT("CR_GANGOP_SPYPLANE", 10)
        STAT_SET_INT("CR_GANGOP_FINALE", 10)
        STAT_SET_INT("CR_GANGOP_FINALE_P2", 10)
        STAT_SET_INT("CR_GANGOP_FINALE_P3", 10)
        -- INT
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_IAA", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_SUBMARINE", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_MISSILE", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_ALLINORDER", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_LOYALTY", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_LOYALTY2", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_LOYALTY3", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_CRIMMASMD", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_CRIMMASMD2", true)
        STAT_SET_BOOL("MPPLY_AWD_GANGOPS_CRIMMASMD3", true)
        -- BOOL
        Notify("Doomsday Awards Unlocked!")
    end)

---


--- Apartment

    menu.action(CLASSIC_HEISTS, "Complete all setups", {}, "", function()
        STAT_SET_INT("HEIST_PLANNING_STAGE", 0xFFFFFFF)
        Notify("You need to watch/skip the first cutscene to activate this option.")
    end)

    menu.action(CLASSIC_HEISTS, "Unlock Classic Heist Awards", {}, "", function()
        STAT_SET_INT("AWD_FINISH_HEISTS", 900)
        STAT_SET_INT("MPPLY_WIN_GOLD_MEDAL_HEISTS", 900)
        STAT_SET_INT("AWD_DO_HEIST_AS_MEMBER", 900)
        STAT_SET_INT("AWD_DO_HEIST_AS_THE_LEADER", 900)
        STAT_SET_INT("AWD_FINISH_HEIST_SETUP_JOB", 900)
        STAT_SET_INT("AWD_FINISH_HEIST", 900)
        STAT_SET_INT("HEIST_COMPLETION", 900)
        STAT_SET_INT("HEISTS_ORGANISED", 900)
        STAT_SET_INT("AWD_CONTROL_CROWDS", 900)
        STAT_SET_INT("AWD_WIN_GOLD_MEDAL_HEISTS", 900)
        STAT_SET_INT("AWD_COMPLETE_HEIST_NOT_DIE", 900)
        STAT_SET_INT("HEIST_START", 900)
        STAT_SET_INT("HEIST_END", 900)
        STAT_SET_INT("CUTSCENE_MID_PRISON", 900)
        STAT_SET_INT("CUTSCENE_MID_HUMANE", 900)
        STAT_SET_INT("CUTSCENE_MID_NARC", 900)
        STAT_SET_INT("CUTSCENE_MID_ORNATE", 900)
        STAT_SET_INT("CR_FLEECA_PREP_1", 5000)
        STAT_SET_INT("CR_FLEECA_PREP_2", 5000)
        STAT_SET_INT("CR_FLEECA_FINALE", 5000)
        STAT_SET_INT("CR_PRISON_PLANE", 5000)
        STAT_SET_INT("CR_PRISON_BUS", 5000)
        STAT_SET_INT("CR_PRISON_STATION", 5000)
        STAT_SET_INT("CR_PRISON_UNFINISHED_BIZ", 5000)
        STAT_SET_INT("CR_PRISON_FINALE", 5000)
        STAT_SET_INT("CR_HUMANE_KEY_CODES", 5000)
        STAT_SET_INT("CR_HUMANE_ARMORDILLOS", 5000)
        STAT_SET_INT("CR_HUMANE_EMP", 5000)
        STAT_SET_INT("CR_HUMANE_VALKYRIE", 5000)
        STAT_SET_INT("CR_HUMANE_FINALE", 5000)
        STAT_SET_INT("CR_NARC_COKE", 5000)
        STAT_SET_INT("CR_NARC_TRASH_TRUCK", 5000)
        STAT_SET_INT("CR_NARC_BIKERS", 5000)
        STAT_SET_INT("CR_NARC_WEED", 5000)
        STAT_SET_INT("CR_NARC_STEAL_METH", 5000)
        STAT_SET_INT("CR_NARC_FINALE", 5000)
        STAT_SET_INT("CR_PACIFIC_TRUCKS", 5000)
        STAT_SET_INT("CR_PACIFIC_WITSEC", 5000)
        STAT_SET_INT("CR_PACIFIC_HACK", 5000)
        STAT_SET_INT("CR_PACIFIC_BIKES", 5000)
        STAT_SET_INT("CR_PACIFIC_CONVOY", 5000)
        STAT_SET_INT("CR_PACIFIC_FINALE", 5000)
        STAT_SET_INT("MPPLY_HEIST_ACH_TRACKER", 0xFFFFFFF)
        -- INT
        STAT_SET_BOOL("MPPLY_AWD_COMPLET_HEIST_MEM", true)
        STAT_SET_BOOL("MPPLY_AWD_COMPLET_HEIST_1STPER", true)
        STAT_SET_BOOL("MPPLY_AWD_FLEECA_FIN", true)
        STAT_SET_BOOL("MPPLY_AWD_HST_ORDER", true)
        STAT_SET_BOOL("MPPLY_AWD_HST_SAME_TEAM", true)
        STAT_SET_BOOL("MPPLY_AWD_HST_ULT_CHAL", true)
        STAT_SET_BOOL("MPPLY_AWD_HUMANE_FIN", true)
        STAT_SET_BOOL("MPPLY_AWD_PACIFIC_FIN", true)
        STAT_SET_BOOL("MPPLY_AWD_PRISON_FIN", true)
        STAT_SET_BOOL("MPPLY_AWD_SERIESA_FIN", true)
        STAT_SET_BOOL("AWD_FINISH_HEIST_NO_DAMAGE", true)
        STAT_SET_BOOL("AWD_SPLIT_HEIST_TAKE_EVENLY", true)
        STAT_SET_BOOL("AWD_ALL_ROLES_HEIST", true)
        STAT_SET_BOOL("AWD_MATCHING_OUTFIT_HEIST", true)
        STAT_SET_BOOL("HEIST_PLANNING_DONE_PRINT", true)
        STAT_SET_BOOL("HEIST_PLANNING_DONE_HELP_0", true)
        STAT_SET_BOOL("HEIST_PLANNING_DONE_HELP_1", true)
        STAT_SET_BOOL("HEIST_PRE_PLAN_DONE_HELP_0", true)
        STAT_SET_BOOL("HEIST_CUTS_DONE_FINALE", true)
        STAT_SET_BOOL("HEIST_IS_TUTORIAL", false)
        STAT_SET_BOOL("HEIST_STRAND_INTRO_DONE", true)
        STAT_SET_BOOL("HEIST_CUTS_DONE_ORNATE", true)
        STAT_SET_BOOL("HEIST_CUTS_DONE_PRISON", true)
        STAT_SET_BOOL("HEIST_CUTS_DONE_BIOLAB", true)
        STAT_SET_BOOL("HEIST_CUTS_DONE_NARCOTIC", true)
        STAT_SET_BOOL("HEIST_CUTS_DONE_TUTORIAL", true)
        STAT_SET_BOOL("HEIST_AWARD_DONE_PREP", true)
        STAT_SET_BOOL("HEIST_AWARD_BOUGHT_IN", true)
        -- BOOL
        Notify("Classic Heists Awards unlocked!")
    end)

---


--- LS Robbery

    menu.action(LS_ROBBERY, "Union Depository", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 0)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nUnion Depository Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The Superdollar Deal", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 4351)
        STAT_SET_INT("TUNER_CURRENT", 1)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe Superdollar Deal Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The Bank Contract", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 2)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe Bank Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The ECU Job", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 3)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe ECU Job Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The Prison Contract", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 4)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe Prison Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The Agency Deal", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 5)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe Agency Deal Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The Lost Contract", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 6)
    Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe Lost Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "The Data Contract", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 12543)
        STAT_SET_INT("TUNER_CURRENT", 7)
        Notify("Changes will only happen if you are outside your Auto-Shop!\n\n\nThe Data Contract ready to play.")
    end)

    menu.action(LS_ROBBERY, "Complete missions (only)", {}, "", function()
        STAT_SET_INT("TUNER_GEN_BS", 0xFFFFFFF)
        Notify("Changes will only happen if you are outside your Auto-Shop\n\nMissions completed!")
    end)

---

--- LS More

    local ROBBERY_RESETER = menu.list(LS_ROBBERY, "More", {}, "", function(); end)

        menu.action(ROBBERY_RESETER, "Reset Missions (only)", {}, "", function()
            STAT_SET_INT("TUNER_GEN_BS", 12467)
            Notify("Changes will only happen if you are outside your Auto-Shop\n\nMissions reseted.")
        end)

        menu.action(ROBBERY_RESETER, "Reset Contracts", {}, "", function()
            STAT_SET_INT("TUNER_GEN_BS", 8371)
            STAT_SET_INT("TUNER_CURRENT", 0xFFFFFFF)
            Notify("Changes will only happen if you are outside your Auto-Shop\n\nContract reseted.")
        end)

        menu.action(ROBBERY_RESETER, "Reset Total Gains & Completed Missions", {}, "", function()
            STAT_SET_INT("TUNER_COUNT", 0)
            STAT_SET_INT("TUNER_EARNINGS", 0)
            Notify("It may only update if you are outside your workshop\n\nThe values have been reseted.")
        end)

    ---

---


--- Master Unlocker

    local TUNERS_DLC = menu.list(MASTER_UNLOCKR, "LS Tuners DLC", {}, "", function(); end)

        local TUNERLIFER = menu.list(TUNERS_DLC, "LS Tuners MAX RP Unlocker", {}, "", function(); end)

            menu.action(TUNERLIFER, "Fix my REP (It will reset to 1)", {}, "Instructions:\n\nActivate the option before buying something, racing, etc.\n\nTo increase your REP LV buy any clothes or upgrade your car at Car Meet\n\nAfter you gain some REP > Change session", function()
                STAT_SET_INT("CAR_CLUB_REP", 5)
                Notify("Your REP has been reseted!")
            end)

        ---

        menu.action(TUNERS_DLC, "Unlock Awards", {}, "", function()
            STAT_SET_INT("AWD_CAR_CLUB_MEM", 100)
            STAT_SET_INT("AWD_SPRINTRACER", 50)
            STAT_SET_INT("AWD_STREETRACER", 50)
            STAT_SET_INT("AWD_PURSUITRACER", 50)
            STAT_SET_INT("AWD_TEST_CAR", 240)
            STAT_SET_INT("AWD_AUTO_SHOP", 50)
            STAT_SET_INT("AWD_CAR_EXPORT", 100)
            STAT_SET_INT("AWD_GROUNDWORK", 40)
            STAT_SET_INT("AWD_ROBBERY_CONTRACT", 100)
            STAT_SET_INT("AWD_FACES_OF_DEATH", 100)
            -- INT
            STAT_SET_BOOL("AWD_CAR_CLUB", true)
            STAT_SET_BOOL("AWD_PRO_CAR_EXPORT", true)
            STAT_SET_BOOL("AWD_UNION_DEPOSITORY", true)
            STAT_SET_BOOL("AWD_MILITARY_CONVOY", true)
            STAT_SET_BOOL("AWD_FLEECA_BANK", true)
            STAT_SET_BOOL("AWD_FREIGHT_TRAIN", true)
            STAT_SET_BOOL("AWD_BOLINGBROKE_ASS", true)
            STAT_SET_BOOL("AWD_IAA_RAID", true)
            STAT_SET_BOOL("AWD_METH_JOB", true)
            STAT_SET_BOOL("AWD_BUNKER_RAID", true)
            STAT_SET_BOOL("AWD_STRAIGHT_TO_VIDEO", true)
            STAT_SET_BOOL("AWD_MONKEY_C_MONKEY_DO", true)
            STAT_SET_BOOL("AWD_TRAINED_TO_KILL", true)
            STAT_SET_BOOL("AWD_DIRECTOR", true)
            -- BOOL
            Notify("Tuners Awards Unlocked!")
        end)

        menu.action(TUNERS_DLC, "Unlock Vehicle Prize", {}, "", function()
            STAT_SET_BOOL("CARMEET_PV_CHLLGE_CMPLT", true)
            STAT_SET_BOOL("CARMEET_PV_CLMED", false)
            Notify("Task Completed.")
        end)

    ---

    local XMAS_FEATURES = menu.list(MASTER_UNLOCKR, "XMAS Utilities", {}, "", function(); end)
        
         menu.action(XMAS_FEATURES, "Unlock XMAS Liveries", {}, "", function()
            STAT_SET_INT("MPPLY_XMASLIVERIES0", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES1", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES2", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES3", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES4", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES5", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES6", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES7", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES8", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES9", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES10", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES11", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES12", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES13", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES14", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES15", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES16", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES17", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES18", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES19", 2147483647)
            STAT_SET_INT("MPPLY_XMASLIVERIES20", 2147483647)
            Notify("All Liveries Unlocked.")
        end)

    ---

    menu.action(MASTER_UNLOCKR, "Refill Inventory", {}, "", function()
        STAT_SET_INT("NO_BOUGHT_YUM_SNACKS", 30)
        STAT_SET_INT("NO_BOUGHT_HEALTH_SNACKS", 15)
        STAT_SET_INT("NO_BOUGHT_EPIC_SNACKS", 5)
        STAT_SET_INT("NUMBER_OF_ORANGE_BOUGHT", 10)
        STAT_SET_INT("NUMBER_OF_BOURGE_BOUGHT", 10)
        STAT_SET_INT("NUMBER_OF_CHAMP_BOUGHT", 5)
        STAT_SET_INT("CIGARETTES_BOUGHT", 20)
        STAT_SET_INT("MP_CHAR_ARMOUR_1_COUNT", 10)
        STAT_SET_INT("MP_CHAR_ARMOUR_2_COUNT", 10)
        STAT_SET_INT("MP_CHAR_ARMOUR_3_COUNT", 10)
        STAT_SET_INT("MP_CHAR_ARMOUR_4_COUNT", 10)
        STAT_SET_INT("MP_CHAR_ARMOUR_5_COUNT", 10)
        STAT_SET_INT("BREATHING_APPAR_BOUGHT", 20)
        Notify("Inventory Restored.")
    end)

    local ARENA_TOOL = menu.list(MASTER_UNLOCKR, "Arena Wars DLC", {}, "", function(); end)
        
        menu.action(MASTER_UNLOCKR, "Unlock all Arena Wars Trophy and Toys", {}, "", function()
            STAT_SET_INT("ARN_BS_TRINKET_TICKERS", 0xFFFFFFF)
            STAT_SET_INT("ARN_BS_TRINKET_SAVED", 0xFFFFFFF)
            STAT_SET_INT("AWD_WATCH_YOUR_STEP", 50)
            STAT_SET_INT("AWD_TOWER_OFFENSE", 50)
            STAT_SET_INT("AWD_READY_FOR_WAR", 50)
            STAT_SET_INT("AWD_THROUGH_A_LENS", 50)
            STAT_SET_INT("AWD_SPINNER", 50)
            STAT_SET_INT("AWD_YOUMEANBOOBYTRAPS", 50)
            STAT_SET_INT("AWD_MASTER_BANDITO", 50)
            STAT_SET_INT("AWD_SITTING_DUCK", 50)
            STAT_SET_INT("AWD_CROWDPARTICIPATION", 50)
            STAT_SET_INT("AWD_KILL_OR_BE_KILLED", 50)
            STAT_SET_INT("AWD_MASSIVE_SHUNT", 50)
            STAT_SET_INT("AWD_YOURE_OUTTA_HERE", 200)
            STAT_SET_INT("AWD_WEVE_GOT_ONE", 50)
            STAT_SET_INT("AWD_ARENA_WAGEWORKER", 1000000)
            STAT_SET_INT("AWD_TIME_SERVED", 1000)
            STAT_SET_INT("AWD_TOP_SCORE", 55000)
            STAT_SET_INT("AWD_CAREER_WINNER", 1000)
            STAT_SET_INT("ARENAWARS_SP", 209)
            STAT_SET_INT("ARENAWARS_SKILL_LEVEL", 20)
            STAT_SET_INT("ARENAWARS_SP_LIFETIME", 209)
            STAT_SET_INT("ARENAWARS_AP_TIER", 1000)
            STAT_SET_INT("ARENAWARS_AP_LIFETIME", 47551850)
            STAT_SET_INT("ARENAWARS_CARRER_UNLK", 44)
            STAT_SET_INT("ARN_W_THEME_SCIFI", 1000)
            STAT_SET_INT("ARN_W_THEME_APOC", 1000)
            STAT_SET_INT("ARN_W_THEME_CONS", 1000)
            STAT_SET_INT("ARN_W_PASS_THE_BOMB", 1000)
            STAT_SET_INT("ARN_W_DETONATION", 1000)
            STAT_SET_INT("ARN_W_ARCADE_RACE", 1000)
            STAT_SET_INT("ARN_W_CTF", 1000)
            STAT_SET_INT("ARN_W_TAG_TEAM", 1000)
            STAT_SET_INT("ARN_W_DESTR_DERBY", 1000)
            STAT_SET_INT("ARN_W_CARNAGE", 1000)
            STAT_SET_INT("ARN_W_MONSTER_JAM", 1000)
            STAT_SET_INT("ARN_W_GAMES_MASTERS", 1000)
            STAT_SET_INT("ARN_L_PASS_THE_BOMB", 500)
            STAT_SET_INT("ARN_L_DETONATION", 500)
            STAT_SET_INT("ARN_L_ARCADE_RACE", 500)
            STAT_SET_INT("ARN_L_CTF", 500)
            STAT_SET_INT("ARN_L_TAG_TEAM", 500)
            STAT_SET_INT("ARN_L_DESTR_DERBY", 500)
            STAT_SET_INT("ARN_L_CARNAGE", 500)
            STAT_SET_INT("ARN_L_MONSTER_JAM", 500)
            STAT_SET_INT("ARN_L_GAMES_MASTERS", 500)
            STAT_SET_INT("NUMBER_OF_CHAMP_BOUGHT", 1000)
            STAT_SET_INT("ARN_SPECTATOR_KILLS", 1000)
            STAT_SET_INT("ARN_LIFETIME_KILLS", 1000)
            STAT_SET_INT("ARN_LIFETIME_DEATHS", 500)
            STAT_SET_INT("ARENAWARS_CARRER_WINS", 1000)
            STAT_SET_INT("ARENAWARS_CARRER_WINT", 1000)
            STAT_SET_INT("ARENAWARS_MATCHES_PLYD", 1000)
            STAT_SET_INT("ARENAWARS_MATCHES_PLYDT", 1000)
            STAT_SET_INT("ARN_SPEC_BOX_TIME_MS", 86400000)
            STAT_SET_INT("ARN_SPECTATOR_DRONE", 1000)
            STAT_SET_INT("ARN_SPECTATOR_CAMS", 1000)
            STAT_SET_INT("ARN_SMOKE", 1000)
            STAT_SET_INT("ARN_DRINK", 1000)
            STAT_SET_INT("ARN_VEH_MONSTER", 31000)
            STAT_SET_INT("ARN_VEH_MONSTER", 41000)
            STAT_SET_INT("ARN_VEH_MONSTER", 51000)
            STAT_SET_INT("ARN_VEH_CERBERUS", 1000)
            STAT_SET_INT("ARN_VEH_CERBERUS2", 1000)
            STAT_SET_INT("ARN_VEH_CERBERUS3", 1000)
            STAT_SET_INT("ARN_VEH_BRUISER", 1000)
            STAT_SET_INT("ARN_VEH_BRUISER2", 1000)
            STAT_SET_INT("ARN_VEH_BRUISER3", 1000)
            STAT_SET_INT("ARN_VEH_SLAMVAN4", 1000)
            STAT_SET_INT("ARN_VEH_SLAMVAN5", 1000)
            STAT_SET_INT("ARN_VEH_SLAMVAN6", 1000)
            STAT_SET_INT("ARN_VEH_BRUTUS", 1000)
            STAT_SET_INT("ARN_VEH_BRUTUS2", 1000)
            STAT_SET_INT("ARN_VEH_BRUTUS3", 1000)
            STAT_SET_INT("ARN_VEH_SCARAB", 1000)
            STAT_SET_INT("ARN_VEH_SCARAB2", 1000)
            STAT_SET_INT("ARN_VEH_SCARAB3", 1000)
            STAT_SET_INT("ARN_VEH_DOMINATOR4", 1000)
            STAT_SET_INT("ARN_VEH_DOMINATOR5", 1000)
            STAT_SET_INT("ARN_VEH_DOMINATOR6", 1000)
            STAT_SET_INT("ARN_VEH_IMPALER2", 1000)
            STAT_SET_INT("ARN_VEH_IMPALER3", 1000)
            STAT_SET_INT("ARN_VEH_IMPALER4", 1000)
            STAT_SET_INT("ARN_VEH_ISSI4", 1000)
            STAT_SET_INT("ARN_VEH_ISSI5", 1000)
            STAT_SET_INT("ARN_VEH_ISSI", 61000)
            STAT_SET_INT("ARN_VEH_IMPERATOR", 1000)
            STAT_SET_INT("ARN_VEH_IMPERATOR2", 1000)
            STAT_SET_INT("ARN_VEH_IMPERATOR3", 1000)
            STAT_SET_INT("ARN_VEH_ZR380", 1000)
            STAT_SET_INT("ARN_VEH_ZR3802", 1000)
            STAT_SET_INT("ARN_VEH_ZR3803", 1000)
            STAT_SET_INT("ARN_VEH_DEATHBIKE", 1000)
            STAT_SET_INT("ARN_VEH_DEATHBIKE2", 1000)
            STAT_SET_INT("ARN_VEH_DEATHBIKE3", 1000)
            -- INT
            STAT_SET_BOOL("AWD_BEGINNER", true)
            STAT_SET_BOOL("AWD_FIELD_FILLER", true)
            STAT_SET_BOOL("AWD_ARMCHAIR_RACER", true)
            STAT_SET_BOOL("AWD_LEARNER", true)
            STAT_SET_BOOL("AWD_SUNDAY_DRIVER", true)
            STAT_SET_BOOL("AWD_THE_ROOKIE", true)
            STAT_SET_BOOL("AWD_BUMP_AND_RUN", true)
            STAT_SET_BOOL("AWD_GEAR_HEAD", true)
            STAT_SET_BOOL("AWD_DOOR_SLAMMER", true)
            STAT_SET_BOOL("AWD_HOT_LAP", true)
            STAT_SET_BOOL("AWD_ARENA_AMATEUR", true)
            STAT_SET_BOOL("AWD_PAINT_TRADER", true)
            STAT_SET_BOOL("AWD_SHUNTER", true)
            STAT_SET_BOOL("AWD_JOCK", true)
            STAT_SET_BOOL("AWD_WARRIOR", true)
            STAT_SET_BOOL("AWD_T_BONE", true)
            STAT_SET_BOOL("AWD_MAYHEM", true)
            STAT_SET_BOOL("AWD_WRECKER", true)
            STAT_SET_BOOL("AWD_CRASH_COURSE", true)
            STAT_SET_BOOL("AWD_ARENA_LEGEND", true)
            STAT_SET_BOOL("AWD_PEGASUS", true)
            STAT_SET_BOOL("AWD_UNSTOPPABLE", true)
            STAT_SET_BOOL("AWD_CONTACT_SPORT", true)
            -- BOOL
            Notify("Arena Wars Unlocked!")
        end)

    ---

    local NIGHT_C_UNLCKS = menu.list(MASTER_UNLOCKR, "NightClub", {}, "", function(); end)

        menu.action(NIGHT_C_UNLCKS, "NighClub MAX Popularity", {}, "", function()
            STAT_SET_INT("CLUB_POPULARITY", 1000)
            Notify("Nightclub Popularity Increased.")
        end)

        menu.action(NIGHT_C_UNLCKS, "Unlock NightClub Awards", {}, "", function()
            STAT_SET_INT("AWD_DANCE_TO_SOLOMUN", 120)
            STAT_SET_INT("AWD_DANCE_TO_TALEOFUS", 120)
            STAT_SET_INT("AWD_DANCE_TO_DIXON", 120)
            STAT_SET_INT("AWD_DANCE_TO_BLKMAD", 120)
            STAT_SET_INT("AWD_CLUB_DRUNK", 200)
            STAT_SET_INT("NIGHTCLUB_VIP_APPEAR", 700)
            STAT_SET_INT("NIGHTCLUB_JOBS_DONE", 700)
            STAT_SET_INT("NIGHTCLUB_EARNINGS", 20721002)
            STAT_SET_INT("HUB_SALES_COMPLETED", 1001)
            STAT_SET_INT("HUB_EARNINGS", 320721002)
            STAT_SET_INT("DANCE_COMBO_DURATION_MINS", 3600000)
            STAT_SET_INT("NIGHTCLUB_PLAYER_APPEAR", 9506)
            STAT_SET_INT("LIFETIME_HUB_GOODS_SOLD", 784672)
            STAT_SET_INT("LIFETIME_HUB_GOODS_MADE", 507822)
            STAT_SET_INT("DANCEPERFECTOWNCLUB", 120)
            STAT_SET_INT("NUMUNIQUEPLYSINCLUB", 120)
            STAT_SET_INT("DANCETODIFFDJS", 4)
            STAT_SET_INT("NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
            STAT_SET_INT("NIGHTCLUB_CONT_TOTAL", 20)
            STAT_SET_INT("NIGHTCLUB_CONT_MISSION", 0xFFFFFFF)
            STAT_SET_INT("CLUB_CONTRABAND_MISSION", 1000)
            STAT_SET_INT("HUB_CONTRABAND_MISSION", 1000)
            -- INT
            STAT_SET_BOOL("AWD_CLUB_HOTSPOT", true)
            STAT_SET_BOOL("AWD_CLUB_CLUBBER", true)
            STAT_SET_BOOL("AWD_CLUB_COORD", true)
            -- BOOL
            Notify("NightClub Awards Unlocked!")
        end)

    ---

    local PLAYER_MENTAL_CHECK = menu.list(MASTER_UNLOCKR, "Mental State", {}, "", function(); end)

        menu.action(PLAYER_MENTAL_CHECK, "Maximum", {}, "", function()
            STAT_SET_FLOAT("PLAYER_MENTAL_STATE", 100.0)
            Notify("Mental State modified to the maximum.")
        end)

        menu.action(PLAYER_MENTAL_CHECK, "Half", {}, "", function()
            STAT_SET_FLOAT("PLAYER_MENTAL_STATE", 50.0)
            Notify("Mental State modified to the half.")
        end)
        
        menu.action(PLAYER_MENTAL_CHECK, "Remove", {}, "", function()
            STAT_SET_FLOAT("PLAYER_MENTAL_STATE", 0.0)
            Notify("Mental State has been removed.")
        end)

    ---

    local ARCADE_TOOL = menu.list(MASTER_UNLOCKR, "Arcade Unlockers", {}, "", function(); end)

        menu.action(MASTER_UNLOCKR, "Unlock Arcade Trophys and Toys", {}, "", function()
            STAT_SET_INT("AWD_PREPARATION", 40)
            STAT_SET_INT("AWD_ASLEEPONJOB", 20)
            STAT_SET_INT("AWD_DAICASHCRAB", 100000)
            STAT_SET_INT("AWD_BIGBRO", 40)
            STAT_SET_INT("AWD_SHARPSHOOTER", 40)
            STAT_SET_INT("AWD_RACECHAMP", 40)
            STAT_SET_INT("AWD_BATSWORD", 1000000)
            STAT_SET_INT("AWD_COINPURSE", 950000)
            STAT_SET_INT("AWD_ASTROCHIMP", 3000000)
            STAT_SET_INT("AWD_MASTERFUL", 40000)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_0", 50)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_1", 50)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_2", 50)
            STAT_SET_INT("SCGW_NUM_WINS_GANG_3", 50)
            STAT_SET_INT("CH_ARC_CAB_CLAW_TROPHY", 0xFFFFFFF)
            STAT_SET_INT("CH_ARC_CAB_LOVE_TROPHY", 0xFFFFFFF)
            STAT_SET_INT("IAP_MAX_MOON_DIST", 2147483647)
            STAT_SET_INT("IAP_INITIALS_0", 50)
            STAT_SET_INT("IAP_INITIALS_1", 50)
            STAT_SET_INT("IAP_INITIALS_2", 50)
            STAT_SET_INT("IAP_INITIALS_3", 50)
            STAT_SET_INT("IAP_INITIALS_4", 50)
            STAT_SET_INT("IAP_INITIALS_5", 50)
            STAT_SET_INT("IAP_INITIALS_6", 50)
            STAT_SET_INT("IAP_INITIALS_7", 50)
            STAT_SET_INT("IAP_INITIALS_8", 50)
            STAT_SET_INT("IAP_INITIALS_9", 50)
            STAT_SET_INT("IAP_SCORE_0", 69644)
            STAT_SET_INT("IAP_SCORE_1", 50333)
            STAT_SET_INT("IAP_SCORE_2", 63512)
            STAT_SET_INT("IAP_SCORE_3", 46136)
            STAT_SET_INT("IAP_SCORE_4", 21638)
            STAT_SET_INT("IAP_SCORE_5", 2133)
            STAT_SET_INT("IAP_SCORE_6", 1215)
            STAT_SET_INT("IAP_SCORE_7", 2444)
            STAT_SET_INT("IAP_SCORE_8", 38023)
            STAT_SET_INT("IAP_SCORE_9", 2233)
            STAT_SET_INT("SCGW_SCORE_1", 50)
            STAT_SET_INT("SCGW_SCORE_2", 50)
            STAT_SET_INT("SCGW_SCORE_3", 50)
            STAT_SET_INT("SCGW_SCORE_4", 50)
            STAT_SET_INT("SCGW_SCORE_5", 50)
            STAT_SET_INT("SCGW_SCORE_6", 50)
            STAT_SET_INT("SCGW_SCORE_7", 50)
            STAT_SET_INT("SCGW_SCORE_8", 50)
            STAT_SET_INT("SCGW_SCORE_9", 50)
            STAT_SET_INT("DG_DEFENDER_INITIALS_0", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_1", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_2", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_3", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_4", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_5", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_6", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_7", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_8", 69644)
            STAT_SET_INT("DG_DEFENDER_INITIALS_9", 69644)
            STAT_SET_INT("DG_DEFENDER_SCORE_0", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_1", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_2", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_3", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_4", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_5", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_6", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_7", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_8", 50)
            STAT_SET_INT("DG_DEFENDER_SCORE_9", 50)
            STAT_SET_INT("DG_MONKEY_INITIALS_0", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_1", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_2", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_3", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_4", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_5", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_6", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_7", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_8", 69644)
            STAT_SET_INT("DG_MONKEY_INITIALS_9", 69644)
            STAT_SET_INT("DG_MONKEY_SCORE_0", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_1", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_2", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_3", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_4", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_5", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_6", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_7", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_8", 50)
            STAT_SET_INT("DG_MONKEY_SCORE_9", 50)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_0", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_1", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_2", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_3", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_4", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_5", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_6", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_7", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_8", 69644)
            STAT_SET_INT("DG_PENETRATOR_INITIALS_9", 69644)
            STAT_SET_INT("DG_PENETRATOR_SCORE_0", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_1", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_2", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_3", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_4", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_5", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_6", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_7", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_8", 50)
            STAT_SET_INT("DG_PENETRATOR_SCORE_9", 50)
            STAT_SET_INT("GGSM_INITIALS_0", 69644)
            STAT_SET_INT("GGSM_INITIALS_1", 69644)
            STAT_SET_INT("GGSM_INITIALS_2", 69644)
            STAT_SET_INT("GGSM_INITIALS_3", 69644)
            STAT_SET_INT("GGSM_INITIALS_4", 69644)
            STAT_SET_INT("GGSM_INITIALS_5", 69644)
            STAT_SET_INT("GGSM_INITIALS_6", 69644)
            STAT_SET_INT("GGSM_INITIALS_7", 69644)
            STAT_SET_INT("GGSM_INITIALS_8", 69644)
            STAT_SET_INT("GGSM_INITIALS_9", 69644)
            STAT_SET_INT("GGSM_SCORE_0", 50)
            STAT_SET_INT("GGSM_SCORE_1", 50)
            STAT_SET_INT("GGSM_SCORE_2", 50)
            STAT_SET_INT("GGSM_SCORE_3", 50)
            STAT_SET_INT("GGSM_SCORE_4", 50)
            STAT_SET_INT("GGSM_SCORE_5", 50)
            STAT_SET_INT("GGSM_SCORE_6", 50)
            STAT_SET_INT("GGSM_SCORE_7", 50)
            STAT_SET_INT("GGSM_SCORE_8", 50)
            STAT_SET_INT("GGSM_SCORE_9", 50)
            STAT_SET_INT("TWR_INITIALS_0", 69644)
            STAT_SET_INT("TWR_INITIALS_1", 69644)
            STAT_SET_INT("TWR_INITIALS_2", 69644)
            STAT_SET_INT("TWR_INITIALS_3", 69644)
            STAT_SET_INT("TWR_INITIALS_4", 69644)
            STAT_SET_INT("TWR_INITIALS_5", 69644)
            STAT_SET_INT("TWR_INITIALS_6", 69644)
            STAT_SET_INT("TWR_INITIALS_7", 69644)
            STAT_SET_INT("TWR_INITIALS_8", 69644)
            STAT_SET_INT("TWR_INITIALS_9", 69644)
            STAT_SET_INT("TWR_SCORE_0", 50)
            STAT_SET_INT("TWR_SCORE_1", 50)
            STAT_SET_INT("TWR_SCORE_2", 50)
            STAT_SET_INT("TWR_SCORE_3", 50)
            STAT_SET_INT("TWR_SCORE_4", 50)
            STAT_SET_INT("TWR_SCORE_5", 50)
            STAT_SET_INT("TWR_SCORE_6", 50)
            STAT_SET_INT("TWR_SCORE_7", 50)
            STAT_SET_INT("TWR_SCORE_8", 50)
            STAT_SET_INT("TWR_SCORE_9", 50)
            -- INT
            STAT_SET_BOOL("AWD_SCOPEOUT", true)
            STAT_SET_BOOL("AWD_CREWEDUP", true)
            STAT_SET_BOOL("AWD_MOVINGON", true)
            STAT_SET_BOOL("AWD_PROMOCAMP", true)
            STAT_SET_BOOL("AWD_GUNMAN", true)
            STAT_SET_BOOL("AWD_SMASHNGRAB", true)
            STAT_SET_BOOL("AWD_INPLAINSI", true)
            STAT_SET_BOOL("AWD_UNDETECTED", true)
            STAT_SET_BOOL("AWD_ALLROUND", true)
            STAT_SET_BOOL("AWD_ELITETHEIF", true)
            STAT_SET_BOOL("AWD_PRO", true)
            STAT_SET_BOOL("AWD_SUPPORTACT", true)
            STAT_SET_BOOL("AWD_SHAFTED", true)
            STAT_SET_BOOL("AWD_COLLECTOR", true)
            STAT_SET_BOOL("AWD_DEADEYE", true)
            STAT_SET_BOOL("AWD_PISTOLSATDAWN", true)
            STAT_SET_BOOL("AWD_TRAFFICAVOI", true)
            STAT_SET_BOOL("AWD_CANTCATCHBRA", true)
            STAT_SET_BOOL("AWD_WIZHARD", true)
            STAT_SET_BOOL("AWD_APEESCAP", true)
            STAT_SET_BOOL("AWD_MONKEYKIND", true)
            STAT_SET_BOOL("AWD_AQUAAPE", true)
            STAT_SET_BOOL("AWD_KEEPFAITH", true)
            STAT_SET_BOOL("AWD_TRUELOVE", true)
            STAT_SET_BOOL("AWD_NEMESIS", true)
            STAT_SET_BOOL("AWD_FRIENDZONED", true)
            STAT_SET_BOOL("IAP_CHALLENGE_0", true)
            STAT_SET_BOOL("IAP_CHALLENGE_1", true)
            STAT_SET_BOOL("IAP_CHALLENGE_2", true)
            STAT_SET_BOOL("IAP_CHALLENGE_3", true)
            STAT_SET_BOOL("IAP_CHALLENGE_4", true)
            STAT_SET_BOOL("IAP_GOLD_TANK", true)
            STAT_SET_BOOL("SCGW_WON_NO_DEATHS", true)
            -- BOOL
            Notify("Arcade Trophys Unlocked!")
        end)

    ---

    menu.action(MASTER_UNLOCKR, "Add cosmetics items to the Office/MC", {}, "", function()
        STAT_SET_INT("LIFETIME_BUY_COMPLETE", 1000)
        STAT_SET_INT("LIFETIME_BUY_UNDERTAKEN", 1000)
        STAT_SET_INT("LIFETIME_SELL_COMPLETE", 1000)
        STAT_SET_INT("LIFETIME_SELL_UNDERTAKEN", 1000)
        STAT_SET_INT("LIFETIME_CONTRA_EARNINGS", 20000000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET1", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA1", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET1", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA1", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET2", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA2", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET2", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA2", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET3", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA3", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET3", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA3", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET4", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA4", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET4", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA4", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_COMPLET5", 1000)
        STAT_SET_INT("LIFETIME_BIKER_BUY_UNDERTA5", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_COMPLET5", 1000)
        STAT_SET_INT("LIFETIME_BIKER_SELL_UNDERTA5", 1000)
        STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS0", 20000000)
        STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS1", 20000000)
        STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS2", 20000000)
        STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS3", 20000000)
        STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS4", 20000000)
        STAT_SET_INT("LIFETIME_BKR_SELL_EARNINGS5", 20000000)
        Notify("Please, now sell anything and switch session.")
    end)

    menu.action(MASTER_UNLOCKR, "Bypass LSC daily sell limit (Vehicles)", {}, "", function()
        STAT_SET_INT("MPPLY_VEHICLE_SELL_TIME", 0)
        STAT_SET_INT("MPPLY_NUM_CARS_SOLD_TODAY", 0)
        Notify("Cooldown Removed.")
    end)

    menu.action(MASTER_UNLOCKR, "Unlock Don't Cross the Line Tee", {}, "", function()
        STAT_SET_INT("DCTL_WINS", 500)
        STAT_SET_INT("DCTL_PLAY_COUNT", 750)
        Notify("Unlocked. You can buy it from any Clothing Store.")
    end)

    menu.action(MASTER_UNLOCKR, "Unlock Shotaro", {}, "", function()
        STAT_SET_INT("CRDEADLINE", 0xFFFFFFF)
        Notify("Shotaro is now avaliable to purchase at Legendary Motorsport.")
    end)

    local SUMMER2020 = menu.list(MASTER_UNLOCKR, "Summer 2020 DLC", {}, "", function(); end)
        
        menu.action(SUMMER2020, "Summer 2020 Awards", {}, "", function()
            STAT_SET_BOOL("AWD_KINGOFQUB3D", true)
            STAT_SET_BOOL("AWD_QUBISM", true)
            STAT_SET_BOOL("AWD_QUIBITS", true)
            STAT_SET_BOOL("AWD_GODOFQUB3D", true)
            STAT_SET_BOOL("AWD_GOFOR11TH", true)
            STAT_SET_BOOL("AWD_ELEVENELEVEN", true)
            Notify("Summer 2020 Awards Unlocked!")
        end)

    ---

    menu.action(MASTER_UNLOCKR, "Unlock Yacht Missions", {}, "", function()
        STAT_SET_INT("YACHT_MISSION_PROG", 0)
        STAT_SET_INT("YACHT_MISSION_FLOW", 21845)
        STAT_SET_INT("CASINO_DECORATION_GIFT_1", 0xFFFFFFF)
        Notify("Yacht Missions Unlocked!")
    end)

    local ALN_TT_UNLCK = menu.list(MASTER_UNLOCKR, "Alien Tatto (Illuminati)", {}, "", function(); end)

        menu.action(ALN_TT_UNLCK, "Apply the tatto for my MALE Character", {}, "", function()
            STAT_SET_INT("TATTOO_FM_CURRENT_32", 32768)
            Notify("Tatto applied, please switch session or suicide for it to show up.")
        end)

        menu.action(ALN_TT_UNLCK, "Apply the tatto for my FEMALE Character", {}, "", function()
            STAT_SET_INT("TATTOO_FM_CURRENT_32", 67108864)
            Notify("Tatto applied, please switch session or suicide for it to show up.")
        end)

    ---

    menu.action(MASTER_UNLOCKR, "Skip Lamar Missions to the last one", {}, "", function()
        STAT_SET_BOOL("LOW_FLOW_CS_DRV_SEEN", true)
        STAT_SET_BOOL("LOW_FLOW_CS_TRA_SEEN", true)
        STAT_SET_BOOL("LOW_FLOW_CS_FUN_SEEN", true)
        STAT_SET_BOOL("LOW_FLOW_CS_PHO_SEEN", true)
        STAT_SET_BOOL("LOW_FLOW_CS_FIN_SEEN", true)
        STAT_SET_BOOL("LOW_BEN_INTRO_CS_SEEN", true)
        -- BOOL
        STAT_SET_INT("LOWRIDER_FLOW_COMPLETE", 3)
        STAT_SET_INT("LOW_FLOW_CURRENT_PROG", 9)
        STAT_SET_INT("LOW_FLOW_CURRENT_CALL", 9)
        -- INT
        Notify("Done, please switch session for it to take effect.")
    end)

    menu.action(MASTER_UNLOCKR, "Unlock Flight School Awards", {}, "", function()
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_0", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_1", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_2", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_3", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_4", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_5", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_6", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_7", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_8", false)
        STAT_SET_BOOL("PILOT_ASPASSEDLESSON_9", false)
        -- BOOL
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_0", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_1", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_2", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_3", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_4", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_5", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_6", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_7", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_8", 1)
        STAT_SET_INT("PILOT_SCHOOL_MEDAL_9", 1)
        -- INT
        Notify("Flight School Awards Unlocked!")
    end)

    local FAST_RUN_M = menu.list(MASTER_UNLOCKR, "Fast Run and Reload",  {}, "", function(); end)

        menu.action(FAST_RUN_M, "Set fast run and reload - ON", {}, "", function()
            STAT_SET_INT("CHAR_FM_ABILITY_1_UNLCK", 0xFFFFFFF)
            STAT_SET_INT("CHAR_FM_ABILITY_2_UNLCK", 0xFFFFFFF)
            STAT_SET_INT("CHAR_FM_ABILITY_3_UNLCK", 0xFFFFFFF)        
            STAT_SET_INT("CHAR_ABILITY_1_UNLCK", 0xFFFFFFF)
            STAT_SET_INT("CHAR_ABILITY_2_UNLCK", 0xFFFFFFF)
            STAT_SET_INT("CHAR_ABILITY_3_UNLCK", 0xFFFFFFF)
            Notify("Fast Run/Reload Enabled.")
        end) 

        menu.action(FAST_RUN_M, "Set fast run and reload - OFF", {}, "", function()
            STAT_SET_INT("CHAR_FM_ABILITY_1_UNLCK", 0)
            STAT_SET_INT("CHAR_FM_ABILITY_2_UNLCK", 0)
            STAT_SET_INT("CHAR_FM_ABILITY_3_UNLCK", 0)        
            STAT_SET_INT("CHAR_ABILITY_1_UNLCK", 0)
            STAT_SET_INT("CHAR_ABILITY_2_UNLCK", 0)
            STAT_SET_INT("CHAR_ABILITY_3_UNLCK", 0)
            Notify("Fast Run/Reload Disabled.")
        end)

    ---

    menu.action(MASTER_UNLOCKR, "Unlock some vehicles trade price", {}, "", function()
        STAT_SET_INT("AT_FLOW_IMPEXP_NUM", 0xFFFFFFF)
        STAT_SET_INT("AT_FLOW_VEHICLE_BS", 0xFFFFFFF)
        STAT_SET_INT("GANGOPS_FLOW_BITSET_MISS0", 0xFFFFFFF)
        STAT_SET_INT("WVM_FLOW_VEHICLE_BS", 0xFFFFFFF)
        Notify("Trade Price Unlocked!")
    end)

    menu.action(MASTER_UNLOCKR, "Unlock all Contacts", {}, "", function()
        STAT_SET_INT("FM_ACT_PHN", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH2", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH3", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH4", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH5", 0xFFFFFFF)
        STAT_SET_INT("FM_VEH_TX1", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH6", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH7", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH8", 0xFFFFFFF)
        STAT_SET_INT("FM_ACT_PH9", 0xFFFFFFF)
        STAT_SET_INT("FM_CUT_DONE", 0xFFFFFFF)
        STAT_SET_INT("FM_CUT_DONE_2", 0xFFFFFFF)
        Notify("Contacts Unlocked!")
    end)

    menu.action(MASTER_UNLOCKR, "Unlock Vanilla Unicorn Award", {}, "", function()
        STAT_SET_INT("LAP_DANCED_BOUGHT", 0)
        STAT_SET_INT("LAP_DANCED_BOUGHT", 5)
        STAT_SET_INT("LAP_DANCED_BOUGHT", 10)
        STAT_SET_INT("LAP_DANCED_BOUGHT", 15)
        STAT_SET_INT("LAP_DANCED_BOUGHT", 25)
        STAT_SET_INT("PROSTITUTES_FREQUENTED", 1000)
        Notify("Vanilla Unicorn Awards Unlocked!")
    end)

    local BNKR_AWARDS = menu.list(MASTER_UNLOCKR, "Unlock Bunker Awards",  {}, "", function(); end)
        
        menu.action(BNKR_AWARDS, "Trigger Alien Egg Mission", {}, "", function()
            STAT_SET_INT("LFETIME_BIKER_BUY_COMPLET5", 599)
            STAT_SET_INT("LFETIME_BIKER_BUY_UNDERTA5", 599)
            Notify("It's necessary to change the clock time between 9pm and 11pm.")
        end)

        menu.action(BNKR_AWARDS, "Unlock Shooting Range Rewards", {}, "", function()
            STAT_SET_INT("SR_HIGHSCORE_1", 690)
            STAT_SET_INT("SR_HIGHSCORE_2", 1860)
            STAT_SET_INT("SR_HIGHSCORE_3", 2690)
            STAT_SET_INT("SR_HIGHSCORE_4", 2660)
            STAT_SET_INT("SR_HIGHSCORE_5", 2650)
            STAT_SET_INT("SR_HIGHSCORE_6", 450)
            STAT_SET_INT("SR_TARGETS_HIT", 269)
            STAT_SET_INT("SR_WEAPON_BIT_SET", 0xFFFFFFF)
            -- INT
            STAT_SET_BOOL("SR_TIER_1_REWARD", true)
            STAT_SET_BOOL("SR_TIER_3_REWARD", true)
            STAT_SET_BOOL("SR_INCREASE_THROW_CAP", true)
            -- BOOL
            Notify("Task completed: Unlocked!")
        end)

    ---

    menu.action(MASTER_UNLOCKR, "Unlock All Daily Objectives Awards", {}, "", function()
        STAT_SET_BOOL("AWD_DAILYOBJWEEKBONUS", true)
        STAT_SET_BOOL("AWD_DAILYOBJMONTHBONUS", true)
        -- BOOL
        STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 0)
        STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 10)
        STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 25)
        STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 50)
        STAT_SET_INT("AWD_DAILYOBJCOMPLETED", 100)
        STAT_SET_INT("CONSECUTIVEWEEKCOMPLETED", 0)
        STAT_SET_INT("CONSECUTIVEWEEKCOMPLETED", 7)
        STAT_SET_INT("CONSECUTIVEWEEKCOMPLETED", 28)
        -- INT
        Notify("Daily Objectives Awards Unlocked!")
    end)

    menu.action(MASTER_UNLOCKR, "[!] Remove Orbital Cannon Cooldown [risky]", {}, "", function()
        STAT_SET_INT("ORBITAL_CANNON_COOLDOWN", 0)
        Notify("Abusing this option can lead to a ban!!!")
        Notify("Cooldown Removed!")
    end)

---


--- Cutscene Skipper : Tools

    local SkipCutscenes, CleanNotifications

    SkipCutscenes = false
    menu.toggle(TOOLS, "Skip Cutscenes", {}, "Some cutscenes may fail and end up killing you.", function(Toggle)
        if Toggle then
            SkipCutscenes = true
        else
            SkipCutscenes = false
        end

        while true do
            if SkipCutscenes then
                menu.trigger_commands("skipcutscene")
            end
            util.yield()
        end
    end)

    CleanNotifications = false
    menu.toggle(TOOLS, "Clean Notifications", {}, "", function(Toggle)
        if Toggle then
            CleanNotifications = true
        else
            CleanNotifications = false
        end

        while true do
            if CleanNotifications then
                menu.trigger_commands("clearnotifications")
            end
            util.yield()
        end
    end)

---


--- Cooldown Reminder

local COOLDOWN_REMIND = menu.list(TOOLS, "Heist Cooldown Reminder",  {}, "", function(); end)

    ---

        menu.action(COOLDOWN_REMIND, "Reminder for Cayo Perico Heist", {}, "", function(HCR_Cayo)
            Notify("The timer will be started soon!\n\nRemember to activate only when you finish the Heist")
            util.yield(60000)
            Notify("Cayo Perico Heist\n\n- Counting the next 16 minutes of Cayo Perico Heist\n\n- Activate as soon as you finish the heist or as soon as you are on the map\n\n- Don't waste time, play a different heist in the meantime :)\n\n- The cooldown for each Heist is individual")
            util.yield(300000)
            Notify("Cayo Perico Heist\n\n- 5 minutes have passed\n\n- There are still 10 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(300000)
            Notify("Cayo Perico Heist\n\n- 10 minutes have passed\n\n- There are still 5 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(360000)
            Notify("Cayo Perico Heist\n\n- 16 minutes have passed\n\n- The cooldown is over!!!\n\n- Now you can play and get paid again\nEnjoy!") 
            return
            Notify("Heist Cooldown Reminder has been disabled...")
        end)

        menu.action(COOLDOWN_REMIND, "Reminder for Diamond Casino Heist", {}, "", function(HCR_Casino)
            Notify("The timer will be started soon!\n\nRemember to activate only when you finish the Heist")
            util.yield(60000)
            Notify("Diamond Casino Heist\n\n- Counting the next 16 minutes of Diamond Casino Heist\n\n- Activate as soon as you finish the heist or as soon as you are on the map\n\n- Don't waste time, play a different heist in the meantime :, true)\n\n- The cooldown for each Heist is individual")
            util.yield(300000)
            Notify("Diamond Casino Heist\n\n- 5 minutes have passed\n\n- There are still 10 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(300000)
            Notify("Diamond Casino Heist\n\n- 10 minutes have passed\n\n- There are still 5 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(360000)
            Notify("Diamond Casino Heist\n\n- 16 minutes have passed\n\n- The cooldown is over!!!\n\n- Now you can play and get paid again\nEnjoy!")
            return
            Notify("Heist Cooldown Reminder has been disabled...")
        end)

        menu.action(COOLDOWN_REMIND, "Reminder for Doomsday Heist", {}, "", function(HCR_Dooms)
            Notify("The timer will be started soon!\n\nRemember to activate only when you finish the Heist")
            util.yield(60000)
            Notify("Doomsday Heist\n\n- Counting the next 16 minutes of Doomsday Heist\n\n- Activate as soon as you finish the heist or as soon as you are on the map\n\n- Don't waste time, play a different heist in the meantime :)\n\n- The cooldown for each Heist is individual")
            util.yield(300000)
            Notify("Doomsday Heist\n\n- 5 minutes have passed\n\n- There are still 10 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(300000)
            Notify("Doomsday Heist\n\n- 10 minutes have passed\n\n- There are still 5 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(360000)
            Notify("Doomsday Heist\n\n- 16 minutes have passed\n\n- The cooldown is over!!!\n\nNow you can play and get paid again\nEnjoy!")
            return
            Notify("Heist Cooldown Reminder has been disabled...")
        end)

        menu.action(COOLDOWN_REMIND, "Reminder for Classic Heists", {}, "", function(HCR_Classic)
            Notify("The timer will be started soon!\n\nRemember to activate only when you finish the Heist")
            util.yield(60000)
            Notify("Classic Heists\n\n- Counting the next 16 minutes of Classic Heists\n\n- Activate as soon as you finish the heist or as soon as you are on the map\n\n- Don't waste time, play a different heist in the meantime :)\n\n- The cooldown for each Heist is individual")
            util.yield(300000)
            Notify("Classic Heists\n\n- 5 minutes have passed\n\n- There are still 10 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(300000)
            Notify("Classic Heists\n\n- 10 minutes have passed\n\n- There are still 5 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(360000)
            Notify("Classic Heists\n\n- 16 minutes have passed\n\n- The cooldown is over!!!\n\nNow you can play and get paid again\nEnjoy!")
            return
            Notify("Heist Cooldown Reminder has been disabled...")
        end)

        menu.action(COOLDOWN_REMIND, "Reminder for LS Robbery (Contracts)", {}, "", function(HCR_LS)
            Notify("The timer will be started soon!\n\nRemember to activate only when you finish the Robbery")
            util.yield(60000)
            Notify("LS Robbery - Contracts\n\n- Counting the next 17 minutes of LS Robbery\n\n- Activate as soon as you finish the heist or as soon as you are on the map\n\n- Don't waste time, play a different heist in the meantime :)\n\n- The cooldown for each Heist is individual")
            util.yield(300000)
            Notify("LS Robbery - Contracts\n\n- 5 minutes have passed\n\n- There are still 10 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(300000)
            Notify("LS Robbery - Contracts\n\n- 10 minutes have passed\n\n- There are still 5 minutes left to finish the cooldown.\n\n- You will receive another Notification soon")
            util.yield(420000)
            Notify("LS Robbery - Contracts\n\n- 17 minutes have passed\n\n- The cooldown is over!!!\n\nNow you can play and get paid again\nEnjoy!")
            return
            Notify("Heist Cooldown Reminder has been disabled...")
        end)

    ---

    menu.action(TOOLS, "Leave Session", {}, "", function()
        menu.trigger_commands("bealone")
        Notify("Task completed.")
    end)

---


--- About HC

    menu.action(Infos, "Update Checker", {}, "Will show notification.", function()
        util.async_http_get("pastebin.com", "/raw/suurXWJ6", function(Sucess)
            Notify("Current Version: "..LuaScriptVersion.."\nThe Lastest Version: "..Sucess)
            if LuaScriptVersion == Sucess then
                Notify("You are using the lastest version!")
            else
                Notify("You need to update Lua Script!")
            end
        end,
        function(Fail)
            Notify("Failed to get the lastest version. ;>")
        end)
    end)

    menu.action(Infos, "Lua Script Info", {}, "Will show notification.", function()
        Notify("Developed by IceDoomfist!\n\nThis script based 2Take1 Lua Script: Heist Control V2\n\nMany thanks to jhowkNx.")
        Notify("jhowkNx's GitHub Page: github.com/jhowkNx.")
    end)

    menu.action(Infos, "Lua Script Version", {}, "Will show notification.", function()
        Notify("[ Based 2Take1 Heist Control V2 Version ]\n\n - "..BasedLuaScriptVersion)
        Notify("[ Stand Heist Control Version ]\n\n - "..LuaScriptVersion)
    end)

    menu.action(Infos, "Donate And Other Infos", {}, "Redirected to PasteBin.", function()
        os.execute("start \"\" \"https://pastebin.com/3tqjDJLv\"")
    end)

    menu.action(Infos, "Lua Script Changelog", {}, "Redirected to PasteBin.", function()
        os.execute("start \"\" \"https://pastebin.com/R5yPHA2U\"")
    end)

---


--- Start Lua Script Settings ---

    Notify("Important\n\n- Each heist has a 15 minute cooldown!\nIf you want to repeat then wait this time.\n\n- Inviting people to the Heist using the (auto-invite) option can bring R* employees to your Heist!")
    Notify("Welcome to Heist Control!")

    while true do
        util.yield()
    end

---