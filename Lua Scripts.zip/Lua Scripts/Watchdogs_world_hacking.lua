require("natives-1627063482") -- da natives
----------------------------------------------------------   FUNCTION AREA   --------------------------------------------------------------------------
local crosshair_texture = directx.create_texture(filesystem.scripts_dir().."crosshair.png")

-- the colour for the menu
local menu_colour = {
    ["r"] = 0,
    ["g"] = 0,
    ["b"] = 0,
    ["a"] = 0.5
}
-- the colour for the menu buttons when highlighted
local highlighted_colour = {
    ["r"] = 1.0,
    ["g"] = 0.0,
    ["b"] = 1.0,
    ["a"] = 0.5
}
-- text colour
local text_colour = {
    ["r"] = 1.0,
    ["g"] = 1.0,
    ["b"] = 1.0,
    ["a"] = 1.0
}
--get player ped
function get_player_ped()
    return PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user())
end

--returns the players position
function get_player_pos()
    return ENTITY.GET_ENTITY_COORDS(get_player_ped())
end

-- set a global byte
function write_global_byte(global, value)
    memory.write_byte(memory.script_global(global), value)
end

function get_overlap_with_rect(scale_x, scale_y, rect_x, rect_y)

    local aspect_ratio = get_ascpect_ratio()
    if aspect_ratio >= 1 then
        scale_y = scale_y * aspect_ratio
    else
        scale_x = scale_x * aspect_ratio
    end

    if rect_x + (scale_x * .5) - .5 <= scale_x and rect_x - (scale_x * .5) - .5 >= -scale_x then
        if rect_y + (scale_y * .5) - .5 <= scale_y and rect_y - (scale_y * .5) - .5 >= -scale_y then
            return true
        end
    else
        return false
    end
end

-- draw buttons in a cirlce
function draw_circle_menu(options, menu_pos, title_text)
    local segment = 360 / #options
    local selected_button = -1
    for i, v in pairs(options) do
        local pos_x, pos_y = get_circle_pos(0.05, segment * (i - 1), menu_pos.x, menu_pos.y)

        if get_overlap_with_rect(.03, .03, pos_x, pos_y) then
            draw_rect(pos_x, pos_y - 0.0125, .03, .03, highlighted_colour)
            selected_button = i
        else
            draw_rect(pos_x, pos_y - 0.0125, .03, .03, menu_colour)
        end


        directx.draw_text(pos_x, pos_y - 0.0125, next(v), ALIGN_CENTRE, .5, text_colour, false)
       
    end
    directx.draw_text(menu_pos.x, menu_pos.y - 0.13, title_text, ALIGN_CENTRE, .5, highlighted_colour, false)
    return selected_button
end

-- turn degrees to radians
function deg_to_rad(angle)
    return angle * math.pi / 180
end

-- get the position screen postion of a point laying on edge the circle with the given radius
function get_circle_pos(radius, angle, pos_x, pos_y)

    angle = deg_to_rad(angle - 90)

    local aspect_ratio = get_ascpect_ratio()

    local x
    local y

    if aspect_ratio >= 1 then
        x = radius * math.cos(angle) + pos_x
        y = radius * math.sin(angle) * aspect_ratio + pos_y
    else
        x = radius * math.cos(angle) * aspect_ratio + pos_x
        y = radius * math.sin(angle) + pos_y
    end

    return x, y
end

-- returns the aspect ratio
function get_ascpect_ratio()
    local screen_x, screen_y = directx.get_client_size()

    return screen_x / screen_y
end

-- draws a rect with the x and y at the center
function draw_rect(pos_x, pos_y, scale_x, scale_y, color)
    pos_x = pos_x - scale_x * 0.5
    pos_y = pos_y - scale_y * 0.5

    local aspect_ratio = get_ascpect_ratio()
    if aspect_ratio >= 1 then
        scale_y = scale_y * aspect_ratio
    else
        scale_x = scale_x * aspect_ratio
    end
    directx.draw_rect(pos_x, pos_y, scale_x, scale_y, color)
end

-- multiply a vecter by a number
function vec_multiply(vec, num)
    local result = {}
    for i, v in pairs(vec) do
        result[i] = v * num
    end
    return result
end

-- add two vectors together
function vec_add(vec_a, vec_b)
    local result = {}
    for i, v in pairs(vec_a) do
        result[i] = v + vec_b[i]
    end
    return result
end

function get_player_name_from_ped(player_ped)
    return PLAYER.GET_PLAYER_NAME(NETWORK.NETWORK_GET_PLAYER_INDEX_FROM_PED(player_ped))
end

-- subract vec a from vec b
function vec_subtract(vec_a, vec_b)
    local result = {}
    for i, v in pairs(vec_a) do
        result[i] = v - vec_b[i]
    end
    return result
end

-- get the magnitude of a vector2
function vec2_magnitude(vec2)
    return math.sqrt(vec2.x * vec2.x + vec2.y * vec2.y)
end
--returns if the phone is active by checking if its scaleform is loaded
function is_phone_active()
    return GRAPHICS.HAS_SCALEFORM_MOVIE_LOADED(memory.read_int(memory.script_global(19779)))
end

-- get control of entity
function get_control_request(ent)
    if not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent) then
        NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(ent)
        local tick = 0
        while not NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent) and tick <= 100 do
            tick = tick + 1
            util.yield()
            NETWORK.NETWORK_REQUEST_CONTROL_OF_ENTITY(ent)
        end
    end
    return NETWORK.NETWORK_HAS_CONTROL_OF_ENTITY(ent)
end
-- kicks the driver and puts you in the driver seat
function take_control_of_vehicle(vehicle)
    kick_ped_from_vehicle(vehicle, -1)
    local tick = 0
    local player = get_player_ped()
    while tick < 50 and VEHICLE.GET_PED_IN_VEHICLE_SEAT(vehicle, -1, false) ~= player do
        PED.SET_PED_INTO_VEHICLE( player, vehicle, -1)
        tick = tick + 1
        util.yield()
    end
end

function kick_ped_from_vehicle(vehicle, seat)
    local ped = VEHICLE.GET_PED_IN_VEHICLE_SEAT(vehicle, seat, false)
    if ped ~= 0 then
        if PED.IS_PED_A_PLAYER() then
            menu.trigger_commands("freeze "..PLAYER.GET_PLAYER_NAME(NETWORK.NETWORK_GET_PLAYER_INDEX_FROM_PED(ped)))
            util.yield()
            menu.trigger_commands("freeze "..PLAYER.GET_PLAYER_NAME(NETWORK.NETWORK_GET_PLAYER_INDEX_FROM_PED(ped)))
        else
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
        end
    end
end

function get_seat_count(vehicle)
local hash = ENTITY.GET_ENTITY_MODEL(vehicle)
return VEHICLE.GET_VEHICLE_MODEL_NUMBER_OF_SEATS(hash)
end

-------------------------------------------------------   FEATURES   -----------------------------------------------------------------------
GenerateSelfFeatures = function() -- load all features;
    menu.toggle(menu.my_root(), "watch dogs world hacking lua", {"dedsecmodelua"}, "worky",function(state) -- watchdogs-like world hacking
            dedsecmode = state --is dedsecmode on
            local current_targeted_entity -- the vehicle that is currently targeted
            local last_tick_entity -- the entity from last tick
            local menu_pos = {} -- the screen space position of the menu
            local was_menu_open_last_tick = false -- pretty self explanitory
            local cam_rot_on_target_select = {} -- that position of the player in the previous tick
            local last_offset = {} -- the offset on the previous tick
            local last_cam_rot = {} -- the cam rotation on the previous tick
            local current_func -- the function currently selected by the player
            while dedsecmode do
                directx.draw_texture(crosshair_texture, 0.002, 0.002, .5, .5, .5, .5, 0, highlighted_colour) -- draw a crosshair so its easy to so what you are selecting

                if not menu.is_open() and not is_phone_active() then -- only look for entities while the menu and phone or closed
                    local vehicles_table = util.get_all_vehicles() -- get all vehicles
                    local ped_table = util.get_all_peds()

                    local entiy_tables = {
                        vehicles_table,
                        ped_table
                    }

                    local player = PLAYER.GET_PLAYER_PED_SCRIPT_INDEX(players.user()) -- get the player ped index

                    if not PAD.IS_CONTROL_PRESSED(2, 27) then -- only loop of we are not targeting a vehicle already

                        local pointerx = memory.alloc() -- alocate memory for the coords (i know i have a function that does this for me but this way i can use the this memory for the entire loop and not realocate it for every vehicle)
                        local pointery = memory.alloc()

                        local current_lowest_magnitude = 2 -- set the lowest magnitude to 2 for reasons

                        current_targeted_entity = nil -- reset current vehicle

                    for n, t in pairs(entiy_tables) do
                        for i, v in pairs(t) do -- loop go BRRRRRRRRRR
                            if t[i] ~= player and t[i] ~= PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false) then
                                if ENTITY.HAS_ENTITY_CLEAR_LOS_TO_ENTITY(player, v, 17) then -- check if we have line of site else dont bother with this one

                                    local entity_pos = ENTITY.GET_ENTITY_COORDS(v) -- get the entity pos

                                    GRAPHICS.GET_SCREEN_COORD_FROM_WORLD_COORD(entity_pos.x, entity_pos.y, entity_pos.z,
                                        pointerx, pointery) -- get the screen position of the entity

                                    local screen_x = memory.read_float(pointerx) -- assing the position to a variable so we dont have to read memory every time
                                    local screen_y = memory.read_float(pointery)

                                    if screen_x ~= -1 and screen_y ~= -1 then -- if screen_x and screen_y are both negative one the enity is not on our screen

                                        screen_x = screen_x - 0.5 -- set 0,0 to the center of the screen
                                        screen_y = screen_y - 0.5

                                        local magnitude = math.sqrt(((screen_x * screen_x) + (screen_y * screen_y))) -- calculate the magnitude

                                        if magnitude < current_lowest_magnitude and magnitude < 0.2 then -- check if magnitude is lower then current one
                                            current_lowest_magnitude = magnitude -- set the current lowest magnitude
                                            current_targeted_entity = t[i] -- set the current entity
                                        end
                                    end
                                end
                            end
                        end
                    end
                        memory.free(pointerx) -- be free my love
                        memory.free(pointery)
                    end
                end
                    if current_targeted_entity ~= nil and ENTITY.DOES_ENTITY_EXIST(current_targeted_entity) then -- check if we are targeting a vehicle
                        local veh_pos = ENTITY.GET_ENTITY_COORDS(current_targeted_entity) -- get the postition of the vehicle

                        local player_pos = get_player_pos() -- get the player position

                        GRAPHICS.DRAW_LINE(player_pos.x, player_pos.y, player_pos.z, veh_pos.x, veh_pos.y, veh_pos.z,
                            255, 0, 255, 255) -- draw a fancy line

                        write_global_byte(19781, 1) -- disable the phone

                        if PAD.IS_CONTROL_PRESSED(2, 27) then -- if we press middle mouse or up then we want that menu to pop up
                            local cam_rot = CAM.GET_GAMEPLAY_CAM_ROT(0) -- get the camera rotation in euler angle

                            if not was_menu_open_last_tick then -- if the menu was not open last frame set the menu pos and last player pos
                                cam_rot_on_target_select = cam_rot
                                last_cam_rot = cam_rot
                                menu_pos = {x = 0.5, y = 0.5}
                                last_offset = {x = 0, y = 0}
                            end

                            local cam_offset = { x = ((cam_rot.z- cam_rot_on_target_select.z) / 160) , y = ((cam_rot.x - cam_rot_on_target_select.x) / 90)}

                            local movement = vec_subtract(cam_offset, last_offset)

                            last_offset = cam_offset

                            if math.abs(cam_rot.z - last_cam_rot.z) < 200 then

                                menu_pos = vec_add(menu_pos, movement)

                                local center_offset = vec_subtract({x = 0.5, y = 0.5}, menu_pos)
                                local magnitude = vec2_magnitude(center_offset)

                                if magnitude > 0.1 then

                                    menu_pos = vec_add(menu_pos,vec_multiply(center_offset, magnitude - 0.1))
                                end
                            end
                            last_cam_rot = cam_rot
                            
                            if ENTITY.GET_ENTITY_TYPE(current_targeted_entity) == 1 then
                                if PED.IS_PED_A_PLAYER(current_targeted_entity) then
                                    current_func = draw_player_menu(menu_pos, get_player_name_from_ped(current_targeted_entity), current_targeted_entity)
                                    else
                                   current_func = draw_ped_menu(menu_pos, "a ped", current_targeted_entity)
                                end
                            else
                                local hash = ENTITY.GET_ENTITY_MODEL(current_targeted_entity)
                                local display_name = VEHICLE.GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(hash)
                                current_func = draw_car_menu(menu_pos, HUD._GET_LABEL_TEXT(display_name), current_targeted_entity)
                            end
                            was_menu_open_last_tick = true -- the menu was open this tick so update the bool
                        else
                            if was_menu_open_last_tick and current_func ~= nil then
                                current_func(last_tick_entity)
                            end
                            last_tick_entity = current_targeted_entity
                            was_menu_open_last_tick = false -- the menu was closed this tick so update the bool
                        end
                    end
                util.yield() -- yield that bad boi
            end
        end)
    local settings_list = menu.list(0, "Settings")
    menu.colour(settings_list, "button colour", {"DSM button"}, "", menu_colour, true, function(colour)
        menu_colour = colour
        end)
    menu.colour(settings_list, "highlighted colour", {"DSM highlight"}, "", highlighted_colour, true, function(colour)
        highlighted_colour = colour
    end)
    menu.colour(settings_list, "text colour", {"DSM text"}, "", text_colour, true, function(colour)
        text_colour = colour
    end)
end
-- a table of all frozen entities
local frozen_entities ={}
-- function for drawing the car menu
function draw_car_menu(menu_pos, title_text, entity)
    local options = {}
    if frozen_entities[entity] == nil then
        options[#options+1] = {["freeze"] = function (entity) -- done
                if not get_control_request(entity) then return end
                    ENTITY.FREEZE_ENTITY_POSITION(entity, true)
                    frozen_entities[entity] = 1
            end
        }
    else
        options[#options+1] = {["unfreeze"] = function (entity) -- done
            if not get_control_request(entity) then return end
                ENTITY.FREEZE_ENTITY_POSITION(entity, false)
                frozen_entities[entity] = nil
        end
    }
    end
        options[#options+1] = {["delete"] = function (entity) -- done
            util.delete_entity(entity)
        end
    }
    if PED.IS_PED_A_PLAYER(VEHICLE.GET_PED_IN_VEHICLE_SEAT(entity, -1, false))then
        options[#options+1] = {["in stand"] = function (entity)
            menu.trigger_commands(get_player_name_from_ped(VEHICLE.GET_PED_IN_VEHICLE_SEAT(entity, -1, false)))
        end
    }
    end
        options[#options+1] = {["empty"] = function (entity)
            for i = -1, get_seat_count(entity) - 1, 1 do
                if not VEHICLE.IS_VEHICLE_SEAT_FREE(entity, i) then
                 kick_ped_from_vehicle(entity, i)
                end
             end 
        end
    }
        options[#options+1] = {["enter"] = function (entity) -- done
            for i = 0, get_seat_count(entity) - 2, 1 do
               if VEHICLE.IS_VEHICLE_SEAT_FREE(entity, i) then
                PED.SET_PED_INTO_VEHICLE(get_player_ped(), entity, i)
                break
               end
            end 
        end
    }
    options[#options+1] = {["drive"] = function (entity) -- done
                if not get_control_request(entity) then return end
                take_control_of_vehicle(entity)
        end
    }
    if not ENTITY.IS_ENTITY_DEAD(entity) then
        options[#options+1] = {["destroy"] = function (entity) -- done
                    local tick = 0
                    
                    while tick < 200 and not ENTITY.IS_ENTITY_DEAD(entity) do
                        local coords = ENTITY.GET_ENTITY_COORDS(entity)
                        FIRE.ADD_EXPLOSION(coords.x, coords.y, coords.z, 2, 1, true, false, 1, false)
                        tick = tick + 1
                        util.yield()
                    end
            end
        }
    else
        options[#options+1] = {["repair"] = function (entity) -- done
            if not get_control_request(entity) then return end
            VEHICLE.SET_VEHICLE_FIXED(entity)
        end
        }
    end
local selected_option = draw_circle_menu(options, menu_pos, title_text)
if selected_option ~= -1 then
return options[selected_option][next(options[selected_option])]
end
end

-- function for drawing the player menu
function draw_player_menu(menu_pos, title_text, entity)
    local options = {}
    if frozen_entities[entity] == nil then
        options[#options+1] = {["freeze"] = function (entity) -- done
                    menu.trigger_commands("freeze "..get_player_name_from_ped(entity))
                    frozen_entities[entity] = 1
            end
        }
    else
        options[#options+1] = {["unfreeze"] = function (entity) -- done
                menu.trigger_commands("freeze "..get_player_name_from_ped(entity))
                frozen_entities[entity] = nil
        end
    }
    end
    options[#options+1] = {["in stand"] = function (entity) -- done
        menu.trigger_commands(get_player_name_from_ped(entity))
    end}
    options[#options+1] = {["kick"] = function (entity) -- done
        menu.trigger_commands("kick "..get_player_name_from_ped(entity))
    end}
    options[#options+1] = {["disarm"] = function (entity) -- done
        menu.trigger_commands("disarm "..get_player_name_from_ped(entity))
        local tick = 0
        while tick < 50 do
            tick = tick + 1
            util.yield()
        end
        menu.trigger_commands("disarm "..get_player_name_from_ped(entity))
    end}
    options[#options+1] = {["explode"] = function (entity) -- done
        local coords = ENTITY.GET_ENTITY_COORDS(entity)
        FIRE.ADD_EXPLOSION(coords.x, coords.y, coords.z, 2, 1, true, false, 1, false)
    end}
    local selected_option = draw_circle_menu(options, menu_pos, title_text)
    if selected_option ~= -1 then
        return options[selected_option][next(options[selected_option])]
    end
end

-- function for drawing the ped menu
function draw_ped_menu(menu_pos, title_text, entity)
    local options = {}

    if frozen_entities[entity] == nil then
       options[#options+1] =  {["freeze"] = function (entity) -- done
            if not get_control_request(entity) then return end
                ENTITY.FREEZE_ENTITY_POSITION(entity, true)
                frozen_entities[entity] = 1
         end}
        else
            options[#options+1] =  {["unfreeze"] = function (entity) -- done
                if not get_control_request(entity) then return end
                    ENTITY.FREEZE_ENTITY_POSITION(entity, false)
                    frozen_entities[entity] = nil
        end}
    end

         options[#options+1] =  {["delete"] = function (entity) -- done
            util.delete_entity(entity)
        end}
        options[#options+1] = {["flee"] = function (entity) -- done
            if not get_control_request(entity) then return end
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(entity)
                TASK.TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(entity, true)
                TASK.TASK_REACT_AND_FLEE_PED(entity, get_player_ped())
                
        end}
        options[#options+1] =  {["cower"] = function (entity) -- done
            if not get_control_request(entity) then return end
                TASK.CLEAR_PED_TASKS_IMMEDIATELY(entity)
                TASK.TASK_SET_BLOCKING_OF_NON_TEMPORARY_EVENTS(entity, true)
                TASK.TASK_COWER(entity, -1)

        end}

    if not ENTITY.IS_ENTITY_DEAD(entity) then
        options[#options+1] = {["burn"] = function (entity) -- done
            if not get_control_request(entity) then return end
                FIRE.START_ENTITY_FIRE(entity)
        end}
    else
        options[#options+1] = {["revive"] = function (entity)
            if not get_control_request(entity) then return end
            PED.RESURRECT_PED(entity)
            ENTITY.SET_ENTITY_HEALTH(entity, ENTITY.GET_ENTITY_MAX_HEALTH(entity))
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(entity)
            local pos = ENTITY.GET_ENTITY_COORDS(entity)
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(entity, pos.x, pos.y, pos.z + .2, false, false, false)
        end}
    end
        options[#options+1] = {["disarm"] = function (entity) -- done
            if not get_control_request(entity) then return end
                WEAPON.REMOVE_ALL_PED_WEAPONS(entity, true)
        end}
        options[#options+1] = {["explode"] = function (entity) -- done
            local coords = ENTITY.GET_ENTITY_COORDS(entity)
            FIRE.ADD_EXPLOSION(coords.x, coords.y, coords.z, 2, 1, true, false, 1, false)
        end}
    local selected_option = draw_circle_menu(options, menu_pos, title_text)
    if selected_option ~= -1 then
        return options[selected_option][next(options[selected_option])]
    end
end

---------------------------------------------------   FINISHING TOUCHES   ---------------------------------------------------------------------------- 
GenerateSelfFeatures() -- generate the features

while true do
    util.yield() -- keeps the script running at all times.
end

--[[
    CREDIT:
    Ren#5219: helped me a lot with the natives and stand api
    ICYPhoenix#0727: helped me with some natives
    Sainan#2020: big credit here because i stole the entire feature idea and she send me a code snippet
]]
