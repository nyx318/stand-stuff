-- Simple Vehicle Flight
-- By AlienX
require("natives-1627063482")

local flyingVehicle = false
local flyingVehicleSpeed = 50
local flyingVehicleLastPosition = nil
local flyingVehicleLastCameraRotation = nil

function setupMenus()
	menu.toggle(menu.my_root(), "Toggle Vehicle Fly", {"ax_togvehfly"}, "Toggles vehicle flight", function(on)
		flyingVehicle = on
		
		if on then
			util.toast("Flying vehicle enabled!")
		else
			util.toast("Flying vehicle disabled!")
			flyingVehicleLastPosition = nil
			flyingVehicle = nil
			flyingVehicleLastCameraRotation = nil
		end
    end, false)
	
	menu.slider(menu.my_root(), "Flying Speed", {"ax_flyvehspeed"}, "", 50, 500, flyingVehicleSpeed, 5.0, function(value, prev)
		flyingVehicleSpeed = value
	end)
	
end

function flyVehicle()
	if flyingVehicle then
		local veh = getCurrentVehicle()
		if veh then
			local vehNeedsRepair = ENTITY.IS_ENTITY_DEAD(veh) or VEHICLE._IS_VEHICLE_DAMAGED(veh)
			local vehCoords = ENTITY.GET_ENTITY_COORDS(veh)
			local cameraRotation = CAM.GET_GAMEPLAY_CAM_ROT()
			
			-- Keyboard States
			local kbStateW = 		PAD.IS_DISABLED_CONTROL_PRESSED(0, 32)
			local kbStateS = 		PAD.IS_DISABLED_CONTROL_PRESSED(0, 33)
			local kbStateA = 		PAD.IS_DISABLED_CONTROL_PRESSED(0, 34)
			local kbStateD = 		PAD.IS_DISABLED_CONTROL_PRESSED(0, 35)
			local kbStateSpace = 	PAD.IS_DISABLED_CONTROL_PRESSED(0, 143)
			local kbStateShift =	PAD.IS_DISABLED_CONTROL_PRESSED(0, 21)
			
			if ( vehNeedsRepair ) then
				VEHICLE.SET_VEHICLE_FIXED(veh)
			end
			
			ENTITY.SET_ENTITY_MAX_SPEED(veh, 50000)
			ENTITY.SET_ENTITY_ROTATION(veh, cameraRotation.x, cameraRotation.y, cameraRotation.z)
						
			-- If no keys are pressed, stop the car
			if not kbStateW and not kbStateS and not kbStateA and not kbStateD and not kbStateShift and not kbStateSpace then
				if not flyingVehicleLastPosition then
					flyingVehicleLastPosition = vehCoords
				end
				ENTITY.SET_ENTITY_COORDS(veh, flyingVehicleLastPosition.x, flyingVehicleLastPosition.y, flyingVehicleLastPosition.z)
			else
				flyingVehicleLastPosition = vehCoords
				TASK._CLEAR_VEHICLE_TASKS(veh)
				local flyingVehicleSpeedVector = {["x"] = 0, ["y"] = 0, ["z"] = 0}
				local zModifier = cameraRotation.x

				if kbStateW then
					local velocityModifier = coordsFromEntityAndHeading(veh, 0, flyingVehicleSpeed)
					flyingVehicleSpeedVector.x = flyingVehicleSpeedVector.x + velocityModifier.x
					flyingVehicleSpeedVector.y = flyingVehicleSpeedVector.y + velocityModifier.y
					flyingVehicleSpeedVector.z = flyingVehicleSpeedVector.z + velocityModifier.z
				end
				if kbStateS then
					local velocityModifier = coordsFromEntityAndHeading(veh, 180, flyingVehicleSpeed)
					flyingVehicleSpeedVector.x = flyingVehicleSpeedVector.x + velocityModifier.x
					flyingVehicleSpeedVector.y = flyingVehicleSpeedVector.y + velocityModifier.y
					flyingVehicleSpeedVector.z = flyingVehicleSpeedVector.z + velocityModifier.z
					zModifier = zModifier * -1
				end
				if kbStateD then
					local velocityModifier = coordsFromEntityAndHeading(veh, 270, flyingVehicleSpeed)
					flyingVehicleSpeedVector.x = flyingVehicleSpeedVector.x + velocityModifier.x
					flyingVehicleSpeedVector.y = flyingVehicleSpeedVector.y + velocityModifier.y
					flyingVehicleSpeedVector.z = flyingVehicleSpeedVector.z + velocityModifier.z
					zModifier = 0
				end
				if kbStateA then
					local velocityModifier = coordsFromEntityAndHeading(veh, 90, flyingVehicleSpeed)
					flyingVehicleSpeedVector.x = flyingVehicleSpeedVector.x + velocityModifier.x
					flyingVehicleSpeedVector.y = flyingVehicleSpeedVector.y + velocityModifier.y
					flyingVehicleSpeedVector.z = flyingVehicleSpeedVector.z + velocityModifier.z
					zModifier = 0
				end
				
				if kbStateSpace then
					zModifier = zModifier + flyingVehicleSpeed
				end
				if kbStateShift then
					zModifier = zModifier + -flyingVehicleSpeed
				end
				
				ENTITY.SET_ENTITY_VELOCITY(veh, flyingVehicleSpeedVector.x, flyingVehicleSpeedVector.y, zModifier)
			end
		end
	end
end

function coordsFromEntityAndHeading(entity, heading, distance)
    local coords = { ["x"] = 0, ["y"] = 0, ["z"] = 0 }

    local newHeading = math.fmod(ENTITY.GET_ENTITY_HEADING(entity) + heading, 360.0)    

    coords["x"] = coords["x"] + distance * math.sin(math.rad(newHeading)) * -1;
    coords["y"] = coords["y"] + distance * math.cos(math.rad(newHeading))

    return coords
end

function getCurrentVehicle()
	local veh = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
	if ENTITY.IS_ENTITY_A_VEHICLE(veh) then
		return veh
	end
	
	return nil
end

setupMenus()

while true do
	flyVehicle()
    util.yield()
end