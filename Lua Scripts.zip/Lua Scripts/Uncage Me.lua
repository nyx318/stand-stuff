require("natives-1627063482")
script = {}
uncageMe = false
deleteMissionEnts = false
notification = false

function dist(pos1, pos2)
	return math.sqrt((pos1.x - pos2.x)*(pos1.x - pos2.x)+(pos1.y - pos2.y)*(pos1.y - pos2.y)+(pos1.z - pos2.z)*(pos1.z - pos2.z))
end

function uncage(entity)
	objects = util.get_all_objects()
	for key,value in pairs(objects) do
		if deleteMissionEnts or not ENTITY.IS_ENTITY_A_MISSION_ENTITY(entity) then
			if (dist(ENTITY.GET_ENTITY_COORDS(value),ENTITY.GET_ENTITY_COORDS(entity)) < 0.15)
			or (ENTITY.IS_ENTITY_TOUCHING_ENTITY(entity,value)
			 and ENTITY.GET_ENTITY_POPULATION_TYPE(value) == 7 
			 and not ENTITY.IS_ENTITY_ATTACHED_TO_ENTITY(value,entity)) then
				if notification then util.toast("Deleting cage with model(s) " .. ENTITY.GET_ENTITY_MODEL(value)) end
				for key2, value2 in pairs(objects) do
					if (ENTITY.GET_ENTITY_MODEL(value2) == ENTITY.GET_ENTITY_MODEL(value)) then util.delete_entity(value2) end
				end
			end
		end
	end
end

menu.toggle(menu.my_root(), "Delete Mission Entities?", {"uncagemissionents"}, "Allows cage checks to delete mission entities (will turn off automatic uncaging)", function(toggle)
	if toggle then 
		menu.trigger_commands("autouncage off")
	end
	deleteMissionEnts = toggle
end)

menu.toggle(menu.my_root(), "Automatic uncage", {"autouncage"}, "Automatically deletes cages you are in", function(toggle)
	uncageMe = toggle
end)

menu.action(menu.my_root(), "Manual uncage", {"manualuncage"}, "Manually deletes cages you are in", function()
	ped = PLAYER.GET_PLAYER_PED(pid)
	uncage(ped)
end)

menu.toggle(menu.my_root(), "Cage notifications?", {"cagenotifs"}, "Show notification when a cage is removed", function(toggle)
	notification = toggle
end)

util.toast("\"Uncage Me!\" script by Gpax971 has been loaded. Be warned that this script can interfere with missions, so turn it off if you are worried")

while true do
	if uncageMe then
		ped = PLAYER.PLAYER_PED_ID()
		uncage(ped)
	end
	util.yield()
end