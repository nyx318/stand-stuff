require("natives-1627063482")
menu.toggle(menu.my_root(),"Toggle Ghost All Players",{"ghostall"},"This enables you to be 'passive' to all players\nbut without being passive",function(on)
	if on then
		for pid = 0,30 do
			if players.exists(pid) then
				NETWORK._SET_RELATIONSHIP_TO_PLAYER(pid,true)
			end
		end
	else
		for pid = 0,30 do
			if players.exists(pid) then
				NETWORK._SET_RELATIONSHIP_TO_PLAYER(pid,false)
			end
		end
	end 
end)
GenerateFeatures = function(pid)
menu.toggle(menu.player_root(pid),"Toggle Ghosting",{"ghost"},"This enables you to be 'passive' to the player\nbut without being passive",function(on)
    if on then
    NETWORK._SET_RELATIONSHIP_TO_PLAYER(pid,true)
    else
    NETWORK._SET_RELATIONSHIP_TO_PLAYER(pid,false)
    end 
end)
end

for pid = 0, 32 do
    if players.exists(pid) then
        GenerateFeatures(pid)
    end
end

while true do
    util.yield()
end