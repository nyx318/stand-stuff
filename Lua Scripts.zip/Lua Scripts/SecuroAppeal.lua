require("natives")

STATS.STAT_SET_INT(util.joaat("MPPLY_VIPGAMEPLAYDISABLEDTIMER"), 0, true)
