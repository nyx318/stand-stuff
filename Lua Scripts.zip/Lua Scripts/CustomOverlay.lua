--An other new lua theme for Stand menu CocoW#6264 V TEST | Stripped down by Ayrapheyr#8141

require("natives-1606100775")

menu.toggle(menu.my_root(),"Custom Overlay", {"ctoverlay"}, "Adds Custom Overlay. | Originally made by CocoW#6264",function(poglay)	
	overlay = poglay --overlay toggle
end)

while true do 
		if overlay then ---------------------------------OVERLAY------------------
		local aspect_ratio = GRAPHICS._GET_ASPECT_RATIO()
		directx.draw_rect(			----- background black rect
		0,				-- X
		0,				-- Y
		0.12,				-- width
		0.238,				-- height
		{					-- colour
			["r"] = 0.01,
			["g"] = 0.01,
			["b"] = 0.01,
			["a"] = 0.7
		}
	)
		
			else
			--no textures :(
	
		end
		util.yield() 
	end

while true do  
	util.yield()
end


