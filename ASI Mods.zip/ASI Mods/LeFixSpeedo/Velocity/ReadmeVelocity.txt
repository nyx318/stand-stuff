This pictures are used:

_____________________

Use high speedo [OFF]

Boats: LinSlow
Bicycle: LinSlow
Plane/Heli: Max

Sedan, Coupe, Muscle, SportClassic, Sport, Super, Motorcycle:
CarSlow

Other:
LinFast
_____________________

Use high speedo [ON]

Boats: LinFast
Bicycle: LinSlow
Plane/Heli: Max

Sport, Super:
CarFast

Compact, Sedan, SUV, Coupe, Muscle, SportClasic, Motorcycle, Emergency:
CarSlow

Other:
LinFast